# Run TekSchool on AWS (Node.js)

This zip contains a **prebuilt** Node server bundle. No npm install, no build needed.

## Run it
```bash
unzip tekschool-aws.zip && cd tekschool-aws
PORT=3000 HOST=0.0.0.0 npm start
```
Requires **Node.js 22+** (`node -v`). Open http://localhost:3000

Before replacing the live app, verify that both the server and browser assets
were extracted:

```bash
test -f .output/server/index.mjs
test -n "$(find .output/public/assets -type f -print -quit)"
test -f .output/public/__l5e/assets-v1/8f58e2c4-07b8-49de-87bb-cae22a2fd9ed/tek-school-v2.mp4
```

Both commands must succeed. Upload/copy the entire `.output` directory—not
only `.output/server`. Missing `.output/public/assets` causes an unstyled page
and HTTP 500 responses for `/assets/*.js` and `/assets/*.css`.

## AWS options
- **EC2 / Lightsail**: copy the folder, run the command above under systemd,
  reverse-proxy 80/443 -> 3000 with nginx.
- **ECS Fargate / App Runner**: use the included `Dockerfile.prebuilt`
  (`docker build -f Dockerfile.prebuilt -t tekschool .`), container port 3000,
  health check path `/`.
- **Elastic Beanstalk (Node platform)**: upload this zip; it runs `npm start`.
  Set the Node.js version to 22 and do not run a build command—the bundle is prebuilt.

## Optional environment variables (only for AI chat / forms)
`LOVABLE_API_KEY`, `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `SLACK_WEBHOOK_URL`,
`RESEND_API_KEY`, `RESEND_FROM_EMAIL`. The site renders fine without them.

## Rebuild from source (optional)
```bash
npm ci
npm run build:node
node .output/server/index.mjs
```
