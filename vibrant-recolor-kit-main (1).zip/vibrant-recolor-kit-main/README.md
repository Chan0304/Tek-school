# Remix of Remix of Tekschool

"Build the complete TekSchool website using this exact design system, recolored to match our brand:

Brand colors (replace all references to green/lime with these): Primary navy (#1E1B4B), gradient accent from sky blue (#5BA4E8) to deep blue (#2D5FA8) — used exactly like the logo's droplet — plus one warm accent (coral #F4A261) and one soft accent (lavender #D4C4E8) for tags/cards. Base backgrounds stay white and off-white (#F0F0F0). Never mix in green or lime.

Global system (applies to every page): Everything sits inside a large white rounded-corner container floating on light gray. Pill-shaped nav bar: TekSchool logo (mark + wordmark) top-left, segmented pill nav center, search + notification icons, solid-navy 'Get Started' pill button right. Bold geometric sans headlines in black, 15-16px gray-black body copy, tilted sticker-pill tags, thin hand-drawn sky-blue squiggle/loop doodles filling empty space, flat colors only — no gradients except the logo-matching blue gradient used sparingly as an accent (hero blob, button hover, section dividers), no drop shadows beyond soft card elevation.

Pages to build:

Home — hero with navy rounded-photo card (angled corner, real students, tilted sticker tags), headline + stat cards, 'Directions of Education' 3-card course row, 'Make Together' collaboration section with floating name-tag callouts, testimonials, footer.

Courses/Catalog — filterable grid of course cards (same flat-color card style as home, one accent color per category), sidebar or top filter pills for category/level/duration, search bar styled to match nav.

Course Detail — hero with course title, instructor avatar + name tag pill, navy photo banner; below: syllabus as a stepped/timeline layout (echoing the 'How it works' scroll pattern), price/duration card, sticky 'Enroll' CTA, related-courses row at bottom.

About — mission statement as a bold two-line headline with icon punctuation, team grid using the same tilted-tag photo-card treatment, timeline of school milestones using the hand-drawn squiggle line as a literal connecting path.

Instructors/Faculty — grid of instructor cards, each a flat-color rounded card with photo bleeding into one corner and a 'name tag' pill (name + specialty) matching the collaborator-tag style from Make Together.

Contact/Enroll — split layout: left a form in a soft rounded card (name, email, course interest as pill-select buttons, message), right a navy card with contact details, map or illustration, and social icons as small circular buttons.

404 / empty states — reuse the big asterisk/flower icon motif at large scale with a short, human-voiced headline ('Looks like this page wandered off') and a Get Started pill CTA back home.

Keep typography, spacing, card radii, tag rotation angles, and doodle style identical across all pages so it reads as one cohesive system — only the accent color per section (navy/blue/coral/lavender) and content change."

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://tekhaven-design-system.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/29e4055c-614d-4e4a-85c2-81e3d5670fc1).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
