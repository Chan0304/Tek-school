// Realistic seed data for the TekSchool admin dashboard.
export type Track = "AI Engineering" | "Cloud Engineering" | "Software Engineering";
export const TRACKS: Track[] = ["AI Engineering", "Cloud Engineering", "Software Engineering"];

export type Student = {
  id: string;
  name: string;
  email: string;
  track: Track;
  cohort: string;
  enrolledAt: string; // ISO date
  attendance: number; // %
  completion: number; // %
  placement: "Not started" | "Preparing" | "Interviewing" | "Offer" | "Placed";
  atRisk: boolean;
  phone: string;
  city: string;
};

const NAMES = [
  "Aarav Sharma","Ananya Rao","Rohit Menon","Priya Iyer","Karan Verma","Meera Suresh","Divya Pillai","Arjun Nair","Rhea Mehta","Faisal Khan",
  "Vikram Reddy","Sneha Kapoor","Ishaan Bose","Aditi Deshmukh","Nikhil Joshi","Kavya Krishnan","Rahul Patil","Tara Menon","Yash Agarwal","Neha Bhat",
  "Sanjay Chawla","Isha Malhotra","Aakash Rao","Pooja Shetty","Devansh Gupta","Riya Saxena","Harsh Patel","Anika Balaji","Kabir Singh","Zara Ali",
  "Sameer Kulkarni","Aditya Menon","Nisha Rao","Varun Bhaskar","Diya Prabhu","Om Prakash","Shivani Rao","Aryan Mishra","Lavanya Rao","Kunal Jain",
];

function pick<T>(arr: T[], i: number): T { return arr[i % arr.length]; }

export const COHORTS = [
  { id: "AI-01", name: "AI-01 · Jan '26", track: "AI Engineering" as Track, start: "2026-01-06", end: "2026-12-15", capacity: 30, mentor: "Ananya Rao" },
  { id: "AI-02", name: "AI-02 · Mar '26", track: "AI Engineering" as Track, start: "2026-03-03", end: "2027-02-10", capacity: 30, mentor: "Rohit Menon" },
  { id: "CE-01", name: "CE-01 · Feb '26", track: "Cloud Engineering" as Track, start: "2026-02-04", end: "2026-11-20", capacity: 28, mentor: "Priya Iyer" },
  { id: "CE-02", name: "CE-02 · Apr '26", track: "Cloud Engineering" as Track, start: "2026-04-07", end: "2027-01-15", capacity: 28, mentor: "Sameer Kulkarni" },
  { id: "SE-01", name: "SE-01 · Jan '26", track: "Software Engineering" as Track, start: "2026-01-13", end: "2026-12-05", capacity: 32, mentor: "Vikram Reddy" },
  { id: "SE-02", name: "SE-02 · May '26", track: "Software Engineering" as Track, start: "2026-05-05", end: "2027-02-25", capacity: 32, mentor: "Kavya Krishnan" },
];

export const STUDENTS: Student[] = NAMES.map((name, i) => {
  const cohort = pick(COHORTS, i);
  const attendance = 60 + ((i * 7) % 40);
  const completion = 45 + ((i * 11) % 55);
  const placementStages: Student["placement"][] = ["Not started", "Preparing", "Interviewing", "Offer", "Placed"];
  return {
    id: `stu_${i + 1}`,
    name,
    email: name.toLowerCase().replace(/\s+/g, ".") + "@student.tek.school",
    track: cohort.track,
    cohort: cohort.name,
    enrolledAt: new Date(2026, (i % 6), 5 + (i % 20)).toISOString().slice(0, 10),
    attendance,
    completion,
    placement: pick(placementStages, i + 2),
    atRisk: attendance < 70 || completion < 55,
    phone: `+91 9${String(100000000 + i * 1234567).slice(0, 9)}`,
    city: pick(["Bengaluru","Hyderabad","Chennai","Mumbai","Pune","Kochi","Delhi"], i),
  };
});

export type EnquiryStage = "New" | "Contacted" | "Demo Booked" | "Enrolled" | "Lost";
export type Enquiry = {
  id: string; name: string; phone: string; email: string; track: Track; source: "Website" | "WhatsApp" | "Instagram" | "Referral"; createdAt: string; stage: EnquiryStage; counselor: string; notes: string;
};
export const ENQUIRIES: Enquiry[] = Array.from({ length: 24 }).map((_, i) => {
  const stages: EnquiryStage[] = ["New","Contacted","Demo Booked","Enrolled","Lost"];
  const nm = pick(NAMES, i + 3);
  return {
    id: `enq_${i+1}`, name: nm,
    phone: `+91 98${String(10000000 + i * 971).slice(0, 8)}`,
    email: nm.split(" ")[0].toLowerCase() + i + "@gmail.com",
    track: pick(TRACKS, i),
    source: pick(["Website","WhatsApp","Instagram","Referral"] as const, i),
    createdAt: new Date(2026, 6, 1 + (i % 28)).toISOString().slice(0, 10),
    stage: pick(stages, i),
    counselor: pick(["Neha","Rahul","Isha"], i),
    notes: pick(["Wants weekend batch.","Family reviewing fees.","Booked demo for Fri.","Enrolled — payment pending.","Went with competitor."], i),
  };
});

export type JobPost = { id: string; role: string; company: string; track: Track; location: string; salary: string; postedDays: number; applicants: number; status: "Open" | "Closed" };
export const JOB_POSTS: JobPost[] = [
  { id: "job_1", role: "AI Engineer — LLM Products", company: "Razorpay", track: "AI Engineering", location: "Bengaluru · Hybrid", salary: "₹18–24 LPA", postedDays: 2, applicants: 14, status: "Open" },
  { id: "job_2", role: "ML Engineer, Search", company: "Meesho", track: "AI Engineering", location: "Bengaluru", salary: "₹16–22 LPA", postedDays: 4, applicants: 22, status: "Open" },
  { id: "job_3", role: "Cloud SRE", company: "Zerodha", track: "Cloud Engineering", location: "Bengaluru", salary: "₹15–20 LPA", postedDays: 5, applicants: 11, status: "Open" },
  { id: "job_4", role: "Backend Engineer", company: "Cred", track: "Software Engineering", location: "Bengaluru", salary: "₹18–26 LPA", postedDays: 6, applicants: 30, status: "Open" },
  { id: "job_5", role: "DevOps Engineer", company: "Freshworks", track: "Cloud Engineering", location: "Chennai", salary: "₹14–18 LPA", postedDays: 8, applicants: 9, status: "Closed" },
  { id: "job_6", role: "Full-stack Engineer", company: "Postman", track: "Software Engineering", location: "Remote", salary: "₹16–22 LPA", postedDays: 10, applicants: 17, status: "Open" },
];

export type Placement = { id: string; student: string; company: string; role: string; stage: "Applied" | "Screening" | "Interview" | "Offer" | "Placed"; updatedDays: number };
export const PLACEMENTS: Placement[] = STUDENTS.slice(0, 22).map((s, i) => ({
  id: `plc_${i+1}`, student: s.name, company: pick(["Razorpay","Meesho","Cred","Zerodha","Freshworks","Postman","Swiggy","Zomato"], i),
  role: pick(["AI Engineer","ML Engineer","Backend Engineer","SRE","DevOps","Cloud Engineer","Data Engineer"], i),
  stage: pick(["Applied","Screening","Interview","Offer","Placed"] as const, i),
  updatedDays: (i % 10) + 1,
}));

export type HiringPartner = { id: string; company: string; contact: string; email: string; activeRoles: number; hires: number; track: Track };
export const HIRING_PARTNERS: HiringPartner[] = [
  { id: "hp_1", company: "Razorpay", contact: "Priyank Nair", email: "priyank@razorpay.com", activeRoles: 2, hires: 7, track: "AI Engineering" },
  { id: "hp_2", company: "Meesho", contact: "Anjali Rao", email: "anjali@meesho.com", activeRoles: 1, hires: 4, track: "AI Engineering" },
  { id: "hp_3", company: "Cred", contact: "Vishal Iyer", email: "vishal@cred.club", activeRoles: 3, hires: 6, track: "Software Engineering" },
  { id: "hp_4", company: "Zerodha", contact: "Kailash R.", email: "kailash@zerodha.com", activeRoles: 1, hires: 3, track: "Cloud Engineering" },
  { id: "hp_5", company: "Freshworks", contact: "Divya M.", email: "divya@freshworks.com", activeRoles: 0, hires: 5, track: "Cloud Engineering" },
  { id: "hp_6", company: "Postman", contact: "Rahul Bansal", email: "rahul@postman.com", activeRoles: 2, hires: 4, track: "Software Engineering" },
];

export type Instructor = { id: string; name: string; track: Track; cohorts: string[]; upcomingSessions: number; rating: number; bio: string };
export const INSTRUCTORS: Instructor[] = [
  { id: "ins_1", name: "Ananya Rao", track: "AI Engineering", cohorts: ["AI-01","AI-02"], upcomingSessions: 4, rating: 4.8, bio: "Ex-Google Brain. Leads applied AI." },
  { id: "ins_2", name: "Rohit Menon", track: "AI Engineering", cohorts: ["AI-02"], upcomingSessions: 3, rating: 4.7, bio: "MLOps at scale — ex-Flipkart." },
  { id: "ins_3", name: "Priya Iyer", track: "Cloud Engineering", cohorts: ["CE-01"], upcomingSessions: 5, rating: 4.9, bio: "AWS Hero. Ex-Amazon SDE-III." },
  { id: "ins_4", name: "Sameer Kulkarni", track: "Cloud Engineering", cohorts: ["CE-02"], upcomingSessions: 3, rating: 4.6, bio: "Kubernetes contributor." },
  { id: "ins_5", name: "Vikram Reddy", track: "Software Engineering", cohorts: ["SE-01"], upcomingSessions: 4, rating: 4.8, bio: "Staff engineer at Cred." },
  { id: "ins_6", name: "Kavya Krishnan", track: "Software Engineering", cohorts: ["SE-02"], upcomingSessions: 5, rating: 4.9, bio: "System design specialist." },
];

export type Assignment = { id: string; title: string; module: string; cohort: string; dueDate: string; submitted: number; pending: number; graded: number };
export const ADMIN_ASSIGNMENTS: Assignment[] = [
  { id: "asg_1", title: "Mini RAG over arXiv abstracts", module: "Applied AI · Week 5", cohort: "AI-02", dueDate: "2026-07-22", submitted: 18, pending: 6, graded: 12 },
  { id: "asg_2", title: "LoRA fine-tune write-up", module: "Applied AI · Week 6", cohort: "AI-02", dueDate: "2026-07-29", submitted: 4, pending: 20, graded: 0 },
  { id: "asg_3", title: "Kubernetes HPA lab", module: "Cloud · Week 4", cohort: "CE-01", dueDate: "2026-07-21", submitted: 22, pending: 6, graded: 15 },
  { id: "asg_4", title: "Distributed cache design doc", module: "Systems · Week 8", cohort: "SE-01", dueDate: "2026-07-30", submitted: 10, pending: 22, graded: 0 },
];

export type FinanceRow = { student: string; track: Track; plan: "Upfront" | "EMI 3" | "EMI 6" | "EMI 12"; paid: number; total: number; dueIn: number };
export const FINANCE: FinanceRow[] = STUDENTS.slice(0, 24).map((s, i) => ({
  student: s.name, track: s.track,
  plan: pick(["Upfront","EMI 3","EMI 6","EMI 12"] as const, i),
  total: 240000, paid: 240000 - ((i * 13) % 100000),
  dueIn: (i % 30),
}));

export type AuditEntry = { id: string; when: string; who: string; role: string; action: string };
export const AUDIT: AuditEntry[] = [
  { id: "a1", when: "2m ago", who: "Neha (Admissions)", role: "admissions", action: "Moved Aarav Sharma from Contacted → Demo Booked" },
  { id: "a2", when: "18m ago", who: "Ananya (Instructor)", role: "instructor", action: "Graded submissions for RAG Week 5 (12)" },
  { id: "a3", when: "1h ago", who: "Rahul (Admissions)", role: "admissions", action: "Enrolled Meera Suresh — AI-02" },
  { id: "a4", when: "3h ago", who: "Kavya (Finance)", role: "finance", action: "Marked refund complete — Kabir Singh" },
  { id: "a5", when: "yesterday", who: "Super admin", role: "super", action: "Activated Monsoon campaign (MONSOON26)" },
];

export type Role = "super" | "admissions" | "instructor" | "finance";
export const ROLE_ACCESS: Record<Role, string[]> = {
  super: ["overview","students","cohorts","assignments","placements","content","enquiries","instructors","finance","marketing","settings","pages","canvas","outreach"],
  admissions: ["overview","enquiries","students","cohorts","marketing","outreach","canvas"],
  instructor: ["overview","cohorts","assignments","students","content","canvas"],
  finance: ["overview","finance","students","settings"],
};

// Simple trend helper (mock deltas per KPI).
export const KPIS = {
  activeStudents: { value: 168, delta: +6 },
  newEnquiriesMonth: { value: 84, delta: +12 },
  conversionRate: { value: 34, delta: -2 }, // %
  placementRate: { value: 87, delta: +3 }, // %
  revenueMonth: { value: 4820000, delta: +8 }, // INR
};

export const ATTENTION = [
  { icon: "grade", label: "12 submissions awaiting grading > 48h", cta: "Grading queue", to: "/admin/assignments" },
  { icon: "enquiry", label: "5 enquiries older than 24h with no reply", cta: "Open enquiries", to: "/admin/enquiries" },
  { icon: "exam", label: "AI-02 mid-term proctoring not scheduled", cta: "Set up exam", to: "/admin/assignments" },
  { icon: "risk", label: "3 students flagged low attendance (<60%)", cta: "See students", to: "/admin/students" },
];

export const ENROLLMENT_TREND = [12, 18, 22, 26, 24, 30, 35, 32, 38, 42, 46, 52];
export const TRACK_POPULARITY = [
  { track: "AI Engineering", count: 62 },
  { track: "Cloud Engineering", count: 48 },
  { track: "Software Engineering", count: 58 },
];
export const ENQUIRY_FUNNEL = [
  { stage: "Visited", count: 12400 },
  { stage: "Enquired", count: 840 },
  { stage: "Demo booked", count: 320 },
  { stage: "Enrolled", count: 108 },
];

export function toCSV<T extends Record<string, unknown>>(rows: T[], columns: (keyof T)[]): string {
  const header = columns.map(String).join(",");
  const body = rows.map((r) => columns.map((c) => {
    const v = r[c];
    const s = v == null ? "" : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  }).join(",")).join("\n");
  return header + "\n" + body;
}

export function downloadCSV(filename: string, csv: string) {
  if (typeof window === "undefined") return;
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}
