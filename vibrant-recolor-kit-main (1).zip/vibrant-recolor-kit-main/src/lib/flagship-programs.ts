// Flagship program tracks — first-class pages with real stats, pricing, curriculum.
export type FlagshipTrack = {
  slug: "ai-engineering" | "cloud-engineering" | "software-engineering" | "future-engineering";
  title: string;
  eyebrow: string;
  tagline: string;
  signaturePromise: string;
  duration: string;
  format: string;
  nextCohort: string;
  seatsLeft: number;
  seatsTotal: number;
  color: "coral" | "lavender" | "blue" | "navy";
  price: { total: number; emi: number; emiMonths: number; original: number; discountPct: number; offerEnds: string };
  stats: { placement: string; salary: string; partners: string };
  highlights: string[];
  perfectFor: string[];
  notForYou: string[];
  weekTransformation: { before: string; after: string };
  sampleProjects: { title: string; desc: string; stack: string }[];
  outcomeCompanies: string[];
  signatureQuote: { text: string; author: string; role: string };
  curriculum: { phase: string; weeks: string; topics: string[] }[];
  mentors: { name: string; role: string; bio: string }[];
  tools: string[];
  faqs: { q: string; a: string }[];
  /** Optional copy overrides for non-placement tracks (e.g. the school track). */
  statLabels?: { placement: string; salary: string; partners: string };
  proofSticker?: { label: string; value: string };
  partners?: { eyebrow: string; heading: string; note: string };
};


export const FLAGSHIP_TRACKS: FlagshipTrack[] = [
  {
    slug: "ai-engineering",
    title: "AI Engineering",
    eyebrow: "Flagship track",
    tagline: "Build, fine-tune, and ship real AI systems — from RAG pipelines to production models.",
    signaturePromise: "In 12 months you'll have shipped a live LLM product to real users — not just finished a notebook.",
    duration: "9-month program + 3-month internship",
    format: "Hybrid · 20 hrs/week live + labs",
    nextCohort: "March 3, 2026",
    seatsLeft: 8,
    seatsTotal: 30,
    color: "coral",
    price: { total: 149999, emi: 6250, emiMonths: 24, original: 300000, discountPct: 50, offerEnds: "31 August" },
    stats: { placement: "94%", salary: "₹12–22 LPA", partners: "2,500+" },
    highlights: [
      "Guaranteed 5+ interviews on graduation",
      "1:1 mentor for 12 months",
      "Real capstone deployed to production",
      "GPU credits + full lab access",
    ],
    perfectFor: [
      "Engineers who can already write clean Python and want to move into AI product work.",
      "Analysts and researchers ready to trade notebooks for shipped systems.",
      "Career switchers who've done a bootcamp and want depth, not another sampler.",
    ],
    notForYou: [
      "You want a 6-week AI overview — this program assumes you'll work 20 hrs/week for 12 months.",
      "You're looking for a purely theoretical ML degree with papers as the final output.",
    ],
    weekTransformation: {
      before: "Week 1 — you can call an LLM API and print the response.",
      after: "Week 48 — you've shipped a RAG-backed product, fine-tuned a model, and been on-call for it.",
    },
    sampleProjects: [
      { title: "Legal-doc RAG assistant", desc: "Ingests 10k+ contracts, answers with citations, streaming UI.", stack: "LangChain · Pinecone · FastAPI" },
      { title: "Fine-tuned support agent", desc: "LoRA-tuned Mistral for a fintech's ticket triage — 3× faster resolutions.", stack: "PyTorch · HF · vLLM" },
      { title: "Multi-agent research crew", desc: "Planner + browser + coder agents that draft market briefs unattended.", stack: "LangGraph · OpenAI · Redis" },
    ],
    outcomeCompanies: ["Razorpay", "Swiggy", "Freshworks", "Meesho", "Cred", "Postman", "Zerodha", "PhonePe"],
    signatureQuote: {
      text: "The internship didn't feel like an internship. Week two I was on-call for a RAG system serving 40k users. That's when the training clicked.",
      author: "Meera S.",
      role: "AI Engineer, fintech · Cohort '25",
    },
    curriculum: [
      { phase: "Foundations", weeks: "Weeks 1–6", topics: ["Python for ML", "Linear algebra refresher", "Data engineering with pandas", "Modern PyTorch"] },
      { phase: "Core ML", weeks: "Weeks 7–16", topics: ["Classical models end-to-end", "Deep learning fundamentals", "Model evaluation & MLOps", "Weights & Biases workflows"] },
      { phase: "Applied AI", weeks: "Weeks 17–28", topics: ["Transformers from scratch", "RAG pipelines with vector DBs", "Fine-tuning LLMs (LoRA/QLoRA)", "Agentic systems & tools"] },
      { phase: "Capstone + Internship", weeks: "Weeks 29–48", topics: ["3-month paid internship", "Production deployment", "Portfolio review", "Interview prep sprints"] },
    ],
    mentors: [
      { name: "Dr. Ananya Iyer", role: "Lead — Applied AI", bio: "Ex-Google Brain. Ships production LLM systems for fintech and healthcare." },
      { name: "Rohan Bhatt", role: "MLOps Mentor", bio: "8 years scaling ML platforms at Flipkart and Swiggy. Talks about latency, budgets, and pager duty." },
    ],
    tools: ["PyTorch", "Hugging Face", "LangChain", "LangGraph", "OpenAI", "vLLM", "FastAPI", "AWS SageMaker", "Pinecone", "Chroma", "Weights & Biases", "Redis"],
    faqs: [
      { q: "Do I need a CS degree?", a: "No. A strong quant background and 6 months of Python are the real prerequisites. We assess in the interview." },
      { q: "Is the internship guaranteed?", a: "Yes — every graduate is placed into a 3-month paid internship with a partner company before certification." },
      { q: "What if I miss placement?", a: "You keep access to placement support for 12 months, plus a refresher cohort at no cost." },
    ],
  },
  {
    slug: "cloud-engineering",
    title: "Cloud Engineering",
    eyebrow: "Flagship track",
    tagline: "Design, deploy, and operate cloud-native systems that scale to millions.",
    signaturePromise: "You'll graduate with a Kubernetes cluster you actually run — and the pager scars to prove it.",
    duration: "6-month program + 3-month internship",
    format: "Hybrid · 18 hrs/week live + labs",
    nextCohort: "March 10, 2026",
    seatsLeft: 11,
    seatsTotal: 30,
    color: "blue",
    price: { total: 89999, emi: 3750, emiMonths: 24, original: 150000, discountPct: 50, offerEnds: "31 August" },
    stats: { placement: "94%", salary: "₹10–18 LPA", partners: "120+" },
    highlights: [
      "AWS + Kubernetes certification prep included",
      "Multi-cloud labs on AWS, GCP, Azure",
      "Real on-call incident simulation weeks",
      "Direct interviews with hiring partners",
    ],
    perfectFor: [
      "Developers tired of the app layer who want to own the infra it runs on.",
      "Sysadmins and support engineers ready to move into SRE and platform roles.",
      "Ops folks who want to trade tickets for Terraform.",
    ],
    notForYou: [
      "You want to avoid the command line — this track lives in your terminal.",
      "You're only looking for AWS certification cram, not real system design and on-call practice.",
    ],
    weekTransformation: {
      before: "Week 1 — you can SSH into a VM and deploy a container.",
      after: "Week 48 — you own a multi-region Kubernetes cluster and its SLOs.",
    },
    sampleProjects: [
      { title: "Multi-region blue-green rollout", desc: "Zero-downtime deploys across 3 AWS regions with automated rollback.", stack: "Terraform · EKS · Argo Rollouts" },
      { title: "SLO-driven observability stack", desc: "Full metrics, logs, traces with burn-rate alerts wired to PagerDuty.", stack: "Prometheus · Grafana · Loki · Tempo" },
      { title: "FinOps cost-cutting sprint", desc: "Real reduction: 42% AWS bill drop for a live SaaS with no perf loss.", stack: "AWS · Karpenter · Vantage" },
    ],
    outcomeCompanies: ["Flipkart", "Zomato", "Razorpay", "Postman", "Hotstar", "Ola", "Grofers", "Dream11"],
    signatureQuote: {
      text: "The on-call simulation weeks were brutal in the best way. My first real incident at work, I already knew the muscle memory — because I'd been paged at 2am in the sim.",
      author: "Aditya K.",
      role: "SRE, streaming platform · Cohort '25",
    },
    curriculum: [
      { phase: "Foundations", weeks: "Weeks 1–6", topics: ["Linux & networking essentials", "Git & CI/CD basics", "Cloud primitives (compute, storage, IAM)", "Bash + Python for ops"] },
      { phase: "Core Cloud", weeks: "Weeks 7–18", topics: ["AWS deep dive (VPC, EC2, RDS, S3)", "Infrastructure-as-Code with Terraform", "Docker & container internals", "Observability: logs, metrics, traces"] },
      { phase: "Production Systems", weeks: "Weeks 19–30", topics: ["Kubernetes end-to-end", "Service mesh & networking", "SRE practices & SLOs", "Cost optimization & FinOps"] },
      { phase: "Capstone + Internship", weeks: "Weeks 31–48", topics: ["3-month paid internship", "Production migration project", "Certification exams", "System design interview prep"] },
    ],
    mentors: [
      { name: "Priya Nair", role: "Lead — Cloud Architecture", bio: "Principal engineer at a unicorn. Migrated four monoliths to Kubernetes without downtime." },
      { name: "Vikram Shetty", role: "SRE Mentor", bio: "10 years of SRE at scale. Believes runbooks are love letters to your future self." },
    ],
    tools: ["AWS", "Azure", "GCP", "Terraform", "Kubernetes", "Docker", "Helm", "ArgoCD", "Prometheus", "Grafana", "Datadog", "PagerDuty"],
    faqs: [
      { q: "Which certifications are covered?", a: "AWS Solutions Architect Associate and Certified Kubernetes Administrator (CKA). Exam vouchers included in tuition." },
      { q: "Do you cover Azure and GCP?", a: "AWS is primary. GCP and Azure appear in the labs so you can translate the concepts across clouds." },
      { q: "Is there hands-on infra work?", a: "Every week has a lab. By month four you're managing a live cluster with real traffic patterns." },
    ],
  },
  {
    slug: "software-engineering",
    title: "Software Engineering",
    eyebrow: "Flagship track",
    tagline: "Become a full-stack engineer who ships product — not just tutorials.",
    signaturePromise: "Four shipped products. Five guaranteed interviews. Twelve months of placement support after graduation.",
    duration: "6-month program + 3-month internship",
    format: "Hybrid · 20 hrs/week live + projects",
    nextCohort: "March 17, 2026",
    seatsLeft: 6,
    seatsTotal: 30,
    color: "navy",
    price: { total: 89999, emi: 3750, emiMonths: 24, original: 150000, discountPct: 50, offerEnds: "31 August" },
    stats: { placement: "100% job assistance", salary: "₹8–16 LPA", partners: "5+ guaranteed interviews" },
    highlights: [
      "5+ guaranteed interviews with hiring partners",
      "12-month extended placement support",
      "Ship 4 real portfolio projects",
      "1:1 mock interviews and CV reviews",
    ],
    perfectFor: [
      "Career switchers with 20 hrs/week and the patience to learn deeply.",
      "CS graduates whose degree gave them theory but no shipped code.",
      "Self-taught devs who want structured mentorship and a real portfolio.",
    ],
    notForYou: [
      "You want a 12-week bootcamp fast-track — depth here takes 6 + 3 months.",
      "You're only interested in one stack forever — we'll teach the whole picture.",
    ],
    weekTransformation: {
      before: "Week 1 — you can build a to-do app with a tutorial open.",
      after: "Week 48 — you've shipped four production apps and can explain every layer.",
    },
    sampleProjects: [
      { title: "Real-time collab editor", desc: "Multi-user text editor with CRDTs, presence, and conflict-free sync.", stack: "React · Yjs · WebSockets · Postgres" },
      { title: "Payments-grade booking system", desc: "Idempotent bookings, retries, refunds, and a full admin dashboard.", stack: "Node.js · Postgres · Redis · Stripe" },
      { title: "Open-source portfolio ship", desc: "One PR merged in a well-known OSS repo — reviewed, shipped, listed.", stack: "TypeScript · GitHub Actions" },
    ],
    outcomeCompanies: ["Razorpay", "Postman", "Zomato", "Freshworks", "Cred", "Meesho", "Groww", "Zeta"],
    signatureQuote: {
      text: "I switched from a non-tech role. Nine months in I was reviewing pull requests. Twelve months in I was shipping to prod. The mentors don't let you skip the hard parts.",
      author: "Nikhil R.",
      role: "SDE, payments · Cohort '25",
    },
    curriculum: [
      { phase: "Foundations", weeks: "Weeks 1–8", topics: ["JavaScript & TypeScript deeply", "Data structures & algorithms", "Git workflows for teams", "Testing mindset"] },
      { phase: "Frontend", weeks: "Weeks 9–18", topics: ["React & modern hooks", "State, routing, forms", "Design systems in practice", "Accessibility & performance"] },
      { phase: "Backend & Systems", weeks: "Weeks 19–30", topics: ["Node.js + PostgreSQL", "Auth, sessions, security", "API design (REST + GraphQL)", "System design fundamentals"] },
      { phase: "Capstone + Internship", weeks: "Weeks 31–48", topics: ["3-month paid internship", "Portfolio polish", "Interview drills", "Long-tail placement support"] },
    ],
    mentors: [
      { name: "Karthik Menon", role: "Lead — Product Engineering", bio: "Shipped consumer products at Zomato and Razorpay. Cares more about your third project than your first." },
      { name: "Aisha Rao", role: "Frontend Mentor", bio: "Ex-Airbnb design systems. Runs weekly critique — brutal, kind, and useful." },
    ],
    tools: ["TypeScript", "React", "Next.js", "Node.js", "PostgreSQL", "Prisma", "MongoDB", "Redis", "GraphQL", "Docker", "GitHub Actions", "Tailwind CSS"],
    faqs: [
      { q: "I'm a career switcher — is this for me?", a: "Yes. About 40% of every cohort is switching from non-tech. You need commitment and 20 hrs/week." },
      { q: "What does '5+ guaranteed interviews' mean?", a: "On graduation, we secure at least 5 interview loops with hiring partners. You keep placement support for 12 months." },
      { q: "Do you offer EMI?", a: "Yes — EMI up to 24 months or income-share options. Full breakdown on the enrollment call." },
    ],
  },
  {
    slug: "future-engineering",
    title: "Future Engineering",
    eyebrow: "School track · Ages 6–15",
    tagline: "A K–10 engineering curriculum that takes children from block coding to robotics, AI and a shipped capstone.",
    signaturePromise: "By age 15 your child won't just use technology — they'll have designed, built and demoed their own.",
    duration: "Academic year · 3 age bands",
    format: "In-school or after-school · 2 hrs/week",
    nextCohort: "April 6, 2026",
    seatsLeft: 14,
    seatsTotal: 24,
    color: "lavender",
    price: { total: 89999, emi: 3750, emiMonths: 24, original: 150000, discountPct: 50, offerEnds: "31 August" },
    stats: { placement: "Ages 6–15", salary: "6 courses · 3 bands", partners: "40+ partner schools" },
    statLabels: { placement: "Who it's for", salary: "Curriculum depth", partners: "Schools running it" },
    proofSticker: { label: "Young builders", value: "1,200+ trained" },
    partners: {
      eyebrow: "# Where it runs",
      heading: "Schools and learning centres already running Future Engineering.",
      note: "Delivered in-school with your timetable, or as after-school cohorts on our campus.",
    },
    highlights: [
      "Age-banded curriculum mapped to NEP 2020 & CBSE computing outcomes",
      "Every band ends in a built, demoed project — never just worksheets",
      "Small batches of 12 with a trained instructor and a teaching assistant",
      "Parent progress reports each term with the child's portfolio",
    ],
    perfectFor: [
      "Children aged 6–15 who ask how things work and want to build, not just watch.",
      "Parents who want screen time to produce something — a game, a robot, an app.",
      "Schools looking for a ready-to-run computing and robotics programme with trained faculty.",
    ],
    notForYou: [
      "You want unsupervised app-based learning — this track is instructor-led and project-graded.",
      "You're looking for exam coaching only; olympiad drills are one module, not the whole programme.",
    ],
    weekTransformation: {
      before: "Band 1 — your child can drag blocks and make a sprite dance.",
      after: "Band 3 — they've trained a model, wired a robot, and pitched a capstone to a judging panel.",
    },
    sampleProjects: [
      { title: "Catch-the-star game", desc: "First game with score, collisions and win states — built by 7-year-olds.", stack: "Scratch · Design thinking" },
      { title: "Line-following rover", desc: "Sensor-driven robot built, printed and raced in the classroom challenge.", stack: "Arduino · Sensors · Tinkercad" },
      { title: "Study-buddy AI app", desc: "Teen-built revision assistant with safe prompts and fact-checking built in.", stack: "Python · LLM API · Streamlit" },
    ],
    outcomeCompanies: ["CBSE schools", "ICSE schools", "IB world schools", "State-board partners", "Atal Tinkering Labs", "Science fairs", "Coding olympiads", "Robotics leagues"],
    signatureQuote: {
      text: "He used to ask for one more level. Now he asks for one more feature. The demo day was the first time I saw him explain something technical to a room.",
      author: "Sushma R.",
      role: "Parent · Grade 5 learner",
    },
    curriculum: [
      { phase: "Band 1 — Spark (Ages 6–8)", weeks: "2 months", topics: ["Computational thinking unplugged", "ScratchJr & Scratch", "Sequences, loops, events", "First showcase project"] },
      { phase: "Band 2 — Build (Ages 8–12)", weeks: "5 months", topics: ["Blocks to typed code", "HTML & CSS pages", "Python fundamentals", "Data, charts and debugging"] },
      { phase: "Band 3 — Invent (Ages 11–15)", weeks: "5 months", topics: ["Robotics, sensors and IoT", "3D design and printing", "AI & data literacy", "Ethics and safe AI use"] },
      { phase: "Capstone & Olympiad", weeks: "2 months", topics: ["Real problem discovery", "Git-tracked team build", "Algorithm drills", "Judged demo day"] },
    ],
    mentors: [
      { name: "Lakshmi Prasad", role: "Curriculum Lead — School Programmes", bio: "15 years teaching computing across CBSE and IB. Designed the age-banded scope and sequence used here." },
      { name: "Farhan Qureshi", role: "Robotics & Maker Mentor", bio: "Robotics coach with national-league teams. Runs the hardware labs and the maker fair." },
    ],
    tools: ["Scratch", "Python", "micro:bit", "Arduino", "Raspberry Pi", "Tinkercad", "Teachable Machine", "App Inventor", "MakeCode", "LEGO SPIKE", "p5.js", "Canva"],
    faqs: [
      { q: "Does my child need any prior coding?", a: "No. Band 1 starts fully unplugged. We place every child by age and a short readiness chat, not by prior experience." },
      { q: "How much screen time is involved?", a: "Roughly half. Every session pairs screen work with unplugged activities, hardware or design work on paper." },
      { q: "Can our school run this on campus?", a: "Yes — we deliver in-school with trained instructors, equipment kits and teacher training. Talk to admissions for the school package." },
      { q: "What does my child leave with?", a: "A digital portfolio of projects, a term-wise progress report, and a certificate at the end of each band." },
    ],
  },
];

export const findTrack = (slug: string) => FLAGSHIP_TRACKS.find((t) => t.slug === slug);
