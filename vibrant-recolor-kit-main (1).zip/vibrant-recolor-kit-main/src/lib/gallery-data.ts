import heroStudents from "@/assets/hero-students.jpg";
import aboutTeam from "@/assets/about-team.jpg";
import instructor1 from "@/assets/instructor-1.jpg";
import instructor2 from "@/assets/instructor-2.jpg";
import instructor3 from "@/assets/instructor-3.jpg";
import instructor4 from "@/assets/instructor-4.jpg";

export type GalleryCategory = "Campus" | "Events" | "Student Work" | "Classrooms";

export type GalleryItem = {
  src: string;
  caption: string;
  category: GalleryCategory;
  tall?: boolean;
  wide?: boolean;
};

export const GALLERY_CATEGORIES: GalleryCategory[] = ["Campus", "Events", "Student Work", "Classrooms"];

export const GALLERY: GalleryItem[] = [
  { src: heroStudents, caption: "Cohort huddle, spring intake", category: "Classrooms", wide: true },
  { src: aboutTeam, caption: "Studio floor, Brooklyn campus", category: "Campus", tall: true },
  { src: instructor1, caption: "Portfolio review night", category: "Events" },
  { src: instructor2, caption: "Guest talk — design systems", category: "Events" },
  { src: instructor3, caption: "Demo day, class of '25", category: "Events" },
  { src: instructor4, caption: "Late-night build session", category: "Classrooms", tall: true },
  { src: heroStudents, caption: "Community meetup", category: "Events" },
  { src: aboutTeam, caption: "Capstone showcase", category: "Student Work" },
  { src: instructor2, caption: "Mentor 1:1s", category: "Classrooms" },
  { src: instructor3, caption: "Identity system — Rae Studios", category: "Student Work" },
  { src: instructor1, caption: "Editorial spread — issue 04", category: "Student Work" },
  { src: instructor4, caption: "Second-floor lounge", category: "Campus" },
];

export type VideoKind = "Campus" | "Testimonial" | "Preview" | "Faculty";

export type VideoItem = {
  id: string;
  title: string;
  description: string;
  kind: VideoKind;
  duration: string;
  thumb: string;
  src: string;
};

export const VIDEOS: VideoItem[] = [
  { id: "v1", title: "Campus tour — Brooklyn floor", description: "A walk through the studio, mentor rooms, and demo stage.", kind: "Campus", duration: "2:14", thumb: aboutTeam, src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" },
  { id: "v2", title: "Why I picked TekSchool — Priya", description: "From marketing analyst to shipping her first React app.", kind: "Testimonial", duration: "1:48", thumb: instructor2, src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4" },
  { id: "v3", title: "Inside Modern React", description: "A five-minute look at week three of the React cohort.", kind: "Preview", duration: "3:02", thumb: heroStudents, src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4" },
  { id: "v4", title: "A day in Data with Python", description: "Notebooks, mentor reviews, and a real dataset.", kind: "Preview", duration: "2:37", thumb: instructor3, src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4" },
  { id: "v5", title: "From bootcamp to first job — Arjun", description: "12 weeks, one portfolio, three offers.", kind: "Testimonial", duration: "2:05", thumb: instructor1, src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4" },
  { id: "v6", title: "UX Foundations preview", description: "Research, sketching, and the first review night.", kind: "Preview", duration: "1:52", thumb: instructor4, src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4" },
  { id: "v7", title: "Meet Sarah Chen — Frontend Lead", description: "Twelve years shipping product UI, now teaching it.", kind: "Faculty", duration: "1:36", thumb: instructor1, src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4" },
  { id: "v8", title: "Studio life, one Friday", description: "Demo night, guest crit, and a lot of stickers.", kind: "Campus", duration: "2:21", thumb: heroStudents, src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4" },
];

export const VIDEO_KINDS: VideoKind[] = ["Campus", "Testimonial", "Preview", "Faculty"];
