import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const demoSchema = z.object({
  program: z.string().trim().min(1).max(80),
  experience_level: z.string().trim().min(1).max(80),
  goal: z.string().trim().min(1).max(120),
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(255),
  phone: z.string().trim().min(6).max(30),
  slot: z.string().trim().min(1).max(60),
  utm_source: z.string().trim().max(120).optional(),
  utm_medium: z.string().trim().max(120).optional(),
  utm_campaign: z.string().trim().max(120).optional(),
});

export type DemoRegistrationInput = z.infer<typeof demoSchema>;

export const registerDemo = createServerFn({ method: "POST" })
  .inputValidator((input: DemoRegistrationInput) => demoSchema.parse(input))
  .handler(async ({ data }): Promise<{ ok: true }> => {
    const { createClient } = await import("@supabase/supabase-js");
    const url = process.env["SUPABASE_URL"] ?? process.env["VITE_SUPABASE_URL"];
    const key =
      process.env["SUPABASE_PUBLISHABLE_KEY"] ??
      process.env["VITE_SUPABASE_PUBLISHABLE_KEY"];
    if (!url || !key) throw new Error("Backend is not configured");

    const supabase = createClient(url, key, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const { error } = await supabase.from("demo_registrations").insert(data);
    if (error) {
      console.error("demo_registrations insert failed:", error.message);
      throw new Error("Could not save your registration. Please try again.");
    }

    // Optional Slack notification — only fires when a webhook is configured.
    const slackWebhook = process.env["SLACK_WEBHOOK_URL"];
    if (slackWebhook) {
      try {
        await fetch(slackWebhook, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            text: `New demo booking: ${data.name} (${data.email}) — ${data.program}, slot ${data.slot}`,
          }),
        });
      } catch (e) {
        console.error("Slack notification failed:", e);
      }
    }

    // Optional confirmation email — only fires when Resend is configured.
    const resendKey = process.env["RESEND_API_KEY"];
    const resendFrom = process.env["RESEND_FROM_EMAIL"];
    if (resendKey && resendFrom) {
      try {
        const res = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${resendKey}`,
          },
          body: JSON.stringify({
            from: resendFrom,
            to: [data.email],
            subject: "Your TekSchool demo is booked",
            html: `<p>Hi ${data.name},</p><p>You're booked for the free <b>${data.program}</b> demo on <b>${data.slot}</b>. We'll send the joining link shortly.</p><p>— TekSchool</p>`,
          }),
        });
        if (!res.ok) console.error("Resend failed:", res.status, await res.text());
      } catch (e) {
        console.error("Resend request failed:", e);
      }
    }

    return { ok: true };
  });
