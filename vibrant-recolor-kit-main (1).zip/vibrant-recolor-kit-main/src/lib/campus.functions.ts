import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const campusSchema = z.object({
  institution: z.string().trim().min(2).max(140),
  institution_type: z.string().trim().min(1).max(60),
  contact_name: z.string().trim().min(2).max(100),
  role: z.string().trim().max(100).optional(),
  email: z.string().trim().email().max(255),
  phone: z.string().trim().min(6).max(30),
  city: z.string().trim().max(100).optional(),
  students: z.string().trim().max(60).optional(),
  program_interest: z.string().trim().min(1).max(80),
  start_window: z.string().trim().max(60).optional(),
  message: z.string().trim().max(1000).optional(),
});

export type CampusEnquiryInput = z.infer<typeof campusSchema>;

export const submitCampusEnquiry = createServerFn({ method: "POST" })
  .inputValidator((input: CampusEnquiryInput) => campusSchema.parse(input))
  .handler(async ({ data }): Promise<{ ok: true }> => {
    const { createClient } = await import("@supabase/supabase-js");
    const url = process.env["SUPABASE_URL"] ?? process.env["VITE_SUPABASE_URL"];
    const key =
      process.env["SUPABASE_PUBLISHABLE_KEY"] ??
      process.env["VITE_SUPABASE_PUBLISHABLE_KEY"];
    if (!url || !key) throw new Error("Backend is not configured");

    const supabase = createClient(url, key, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const { error } = await supabase.from("campus_enquiries").insert(data);
    if (error) {
      console.error("campus_enquiries insert failed:", error.message);
      throw new Error("Could not send your enquiry. Please try again.");
    }

    return { ok: true };
  });
