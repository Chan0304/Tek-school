import wRag from "@/assets/workshop-rag.jpg";
import wK8s from "@/assets/workshop-k8s.jpg";
import wPortfolio from "@/assets/workshop-portfolio.jpg";
import wTypescript from "@/assets/workshop-typescript.jpg";
import wFinetune from "@/assets/workshop-finetune.jpg";
import wSystemDesign from "@/assets/workshop-systemdesign.jpg";
import instructor1 from "@/assets/instructor-1.jpg";
import instructor2 from "@/assets/instructor-2.jpg";
import instructor3 from "@/assets/instructor-3.jpg";
import instructor4 from "@/assets/instructor-4.jpg";


export type WorkshopFormat = "In person" | "Online" | "Hybrid";
export type WorkshopTrack = "AI" | "Cloud" | "Software" | "Career";

export type Workshop = {
  id: string;
  title: string;
  blurb: string;
  track: WorkshopTrack;
  format: WorkshopFormat;
  date: string;
  time: string;
  duration: string;
  seats: number;
  seatsLeft: number;
  price: string;
  host: string;
  hostRole: string;
  image: string;
  takeaways: string[];
  about: string;
  agenda: { time: string; label: string }[];
  forWho: string[];
  prereqs: string;
  hostPhoto: string;
  hostBio: string;
  hostCreds: string[];
  featured?: boolean;
};

export const WORKSHOP_TRACKS: WorkshopTrack[] = ["AI", "Cloud", "Software", "Career"];

export const WORKSHOPS: Workshop[] = [
  {
    id: "w1",
    title: "Build a RAG chatbot in 3 hours",
    blurb: "Chunking, embeddings, vector search, and a working answer pipeline you deploy before you leave.",
    track: "AI",
    format: "In person",
    date: "Sat, Aug 22",
    time: "10:00 AM",
    duration: "3 hrs",
    seats: 30,
    seatsLeft: 6,
    price: "Free",
    host: "Sarah Chen",
    hostRole: "AI Engineering Lead",
    image: wRag,
    featured: true,
    takeaways: ["Ship a working RAG app", "Pick the right embedding model", "Evaluate answer quality"],
    about: "A single afternoon that takes you from a folder of PDFs to a chatbot that answers questions about them with citations. We build the whole pipeline live \u2014 no notebooks you can't run at home \u2014 and you leave with a deployed URL you can share the same evening.",
    agenda: [{ time: "0:00", label: "Why retrieval beats a bigger prompt" }, { time: "0:30", label: "Chunking and embedding your own documents" }, { time: "1:15", label: "Vector search, filters, and re-ranking" }, { time: "2:00", label: "Wiring the answer pipeline with citations" }, { time: "2:35", label: "Deploying and evaluating your bot" }],
    forWho: ["Developers who have used an LLM API once or twice", "Data folks who want a working retrieval stack", "Founders prototyping an internal knowledge assistant"],
    prereqs: "A laptop, Node or Python installed, and any free LLM API key. We supply the sample corpus.",
    hostPhoto: instructor1,
    hostBio: "Sarah has spent six years building search and retrieval systems, most recently leading an applied AI team shipping document assistants to 40k+ enterprise users. She teaches the AI Engineering flagship at TekSchool.",
    hostCreds: ["Ex-Staff ML Engineer, enterprise search", "Led a 9-person applied AI team", "Faculty, AI Engineering flagship"],
  },
  {
    id: "w2",
    title: "Kubernetes from zero to first deploy",
    blurb: "Pods, services, ingress, and a rolling deploy on a real cluster — no prior k8s needed.",
    track: "Cloud",
    format: "Hybrid",
    date: "Sun, Aug 30",
    time: "11:00 AM",
    duration: "4 hrs",
    seats: 40,
    seatsLeft: 14,
    price: "₹499",
    host: "Marcus Lee",
    hostRole: "SRE, Cloud faculty",
    image: wK8s,
    takeaways: ["Deploy a service to a live cluster", "Read logs and debug crashloops", "Autoscaling basics"],
    about: "Kubernetes explained the way it actually behaves, not the way the docs list it. We start with a plain container, break it on purpose, and rebuild it as a resilient service on a live cluster you control for the session.",
    agenda: [{ time: "0:00", label: "Containers vs pods \u2014 the mental model" }, { time: "0:40", label: "Deployments, services, and ingress" }, { time: "1:40", label: "Break it: crashloops, OOM kills, bad probes" }, { time: "2:40", label: "Rolling deploys and rollbacks" }, { time: "3:20", label: "Autoscaling and what to monitor" }],
    forWho: ["Backend and full-stack devs deploying by hand today", "DevOps beginners who have used Docker", "Anyone who has been handed a cluster and no context"],
    prereqs: "Comfort with a terminal and basic Docker. Cluster access is provided \u2014 nothing to install.",
    hostPhoto: instructor2,
    hostBio: "Marcus runs reliability for a payments platform serving millions of daily transactions and has migrated three production estates onto Kubernetes. He mentors the Cloud Engineering cohort.",
    hostCreds: ["SRE, high-volume payments infrastructure", "3 production Kubernetes migrations", "Faculty, Cloud Engineering flagship"],
  },
  {
    id: "w3",
    title: "Portfolio teardown night",
    blurb: "Bring your project. Get line-by-line feedback from hiring engineers in front of the room.",
    track: "Career",
    format: "In person",
    date: "Fri, Sep 5",
    time: "6:30 PM",
    duration: "2 hrs",
    seats: 25,
    seatsLeft: 3,
    price: "Free",
    host: "Priya Nair",
    hostRole: "Placements lead",
    image: wPortfolio,
    takeaways: ["A prioritised fix list", "What recruiters skim first", "Case-study structure that lands"],
    about: "Bring the project you're least sure about. We put portfolios on the big screen and review them the way a hiring engineer does \u2014 sixty seconds of skimming, then the hard questions. Blunt, useful, and always in public so everyone learns.",
    agenda: [{ time: "0:00", label: "How a recruiter actually reads your portfolio" }, { time: "0:25", label: "Live teardowns \u2014 six projects, full room" }, { time: "1:30", label: "Rewriting your case studies together" }, { time: "1:50", label: "Your prioritised fix list" }],
    forWho: ["Students preparing for placements", "Career switchers with one or two projects", "Anyone whose applications go unanswered"],
    prereqs: "A live portfolio link or a repo README. Sign up early \u2014 only six teardown slots.",
    hostPhoto: instructor3,
    hostBio: "Priya has placed over 400 junior engineers and reviews hiring funnels with partner companies every week. She knows precisely where a portfolio loses attention.",
    hostCreds: ["400+ juniors placed", "Runs employer partnerships at TekSchool", "Ex-technical recruiter, product startups"],
  },
  {
    id: "w4",
    title: "TypeScript patterns that scale",
    blurb: "Generics, discriminated unions, and typing an API layer so refactors stop hurting.",
    track: "Software",
    format: "Online",
    date: "Wed, Sep 10",
    time: "7:00 PM",
    duration: "2.5 hrs",
    seats: 100,
    seatsLeft: 41,
    price: "Free",
    host: "Dev Kapoor",
    hostRole: "Software Engineering faculty",
    image: wTypescript,
    takeaways: ["Model state you can't misuse", "Type a fetch layer end to end", "Kill `any` for good"],
    about: "The TypeScript session for people who already ship TypeScript but keep reaching for `any` when things get hard. We refactor a messy real codebase together and make invalid states impossible to represent.",
    agenda: [{ time: "0:00", label: "Generics without the fear" }, { time: "0:35", label: "Discriminated unions and exhaustive checks" }, { time: "1:15", label: "Typing a fetch layer end to end" }, { time: "1:55", label: "Refactor lab on a real codebase" }],
    forWho: ["Devs with 6+ months of TypeScript", "Teams fighting brittle refactors", "React developers typing props badly"],
    prereqs: "Working knowledge of JavaScript and basic TypeScript syntax. Bring a laptop with Node 20+.",
    hostPhoto: instructor4,
    hostBio: "Dev maintains internal type tooling used across a 60-engineer product org and has written the frontend architecture guides our Software Engineering cohort learns from.",
    hostCreds: ["Frontend architect, 60-engineer org", "Author, TekSchool TypeScript curriculum", "Open-source type utility maintainer"],
  },
  {
    id: "w5",
    title: "Fine-tuning small models on your data",
    blurb: "LoRA, dataset hygiene, and knowing when a prompt beats a fine-tune.",
    track: "AI",
    format: "Online",
    date: "Sat, Sep 19",
    time: "10:30 AM",
    duration: "3 hrs",
    seats: 60,
    seatsLeft: 22,
    price: "₹799",
    host: "Ayesha Rahman",
    hostRole: "ML engineer, guest",
    image: wFinetune,
    takeaways: ["Prepare a clean training set", "Run a LoRA fine-tune", "Measure the lift honestly"],
    about: "Most fine-tunes fail because of the dataset, not the model. We spend the first hour on data hygiene, then run a real LoRA fine-tune on a small open model and measure honestly whether it beat a good prompt.",
    agenda: [{ time: "0:00", label: "When a prompt is genuinely enough" }, { time: "0:35", label: "Building and cleaning a training set" }, { time: "1:20", label: "Running a LoRA fine-tune" }, { time: "2:10", label: "Evaluating the lift without fooling yourself" }, { time: "2:40", label: "Serving the adapter cheaply" }],
    forWho: ["Engineers with an LLM feature already in production", "ML practitioners new to parameter-efficient tuning", "Teams weighing fine-tuning against RAG"],
    prereqs: "Python familiarity. A free Colab account is enough \u2014 GPU is provided in the notebook.",
    hostPhoto: instructor1,
    hostBio: "Ayesha ships small specialised models for regulated industries where a 7B model on your own data beats a frontier API. She joins us as a guest each term.",
    hostCreds: ["ML engineer, applied research team", "Shipped 12+ fine-tuned models to production", "Guest faculty, AI Engineering"],
  },
  {
    id: "w6",
    title: "System design interview lab",
    blurb: "Two live mock rounds, whiteboard to trade-offs, scored against a real rubric.",
    track: "Career",
    format: "Hybrid",
    date: "Sat, Sep 26",
    time: "4:00 PM",
    duration: "3 hrs",
    seats: 20,
    seatsLeft: 8,
    price: "₹999",
    host: "Rohit Verma",
    hostRole: "Staff engineer, mentor",
    image: wSystemDesign,
    takeaways: ["A repeatable answer framework", "Capacity math on the spot", "Scored feedback you can act on"],
    about: "Two live mock interviews, scored against the same rubric our hiring partners use. You either sit in the chair or watch and score \u2014 both teach. You leave with a written scorecard and a framework you can reuse under pressure.",
    agenda: [{ time: "0:00", label: "The rubric interviewers actually fill in" }, { time: "0:20", label: "Mock round one \u2014 live, whiteboard" }, { time: "1:20", label: "Capacity math and trade-off language" }, { time: "1:50", label: "Mock round two" }, { time: "2:40", label: "Scorecards and next steps" }],
    forWho: ["Engineers with 2+ years targeting senior roles", "Final-year students facing design rounds", "Anyone who freezes at 'design Twitter'"],
    prereqs: "Basic familiarity with databases, caching, and queues. Twenty seats only, so it stays interactive.",
    hostPhoto: instructor2,
    hostBio: "Rohit has run over 300 design interviews as a staff engineer and sits on his company's hiring committee. He grades the way the panel grades.",
    hostCreds: ["Staff engineer, distributed systems", "300+ system design interviews conducted", "Hiring committee member"],
  },
];
