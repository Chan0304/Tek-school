// Config-driven seasonal campaign engine.
export type Campaign = {
  id: string;
  season: "monsoon" | "diwali" | "yearEnd" | "default";
  badge: string;
  headline: string;
  sub: string;
  code: string;
  endsAt?: string; // ISO
  cta: string;
  whatsappHref: string;
  theme: {
    // background gradient (light overlay bg for the card)
    bgFrom: string; bgTo: string;
    // accent (badge + button)
    accent: string; accentDeep: string;
    // ambient motif
    motif: "rain" | "sparkle" | "snow" | "none";
    textOn: "dark" | "light";
  };
};

// Date-range check ignoring year.
function inMonthRange(now: Date, startMonth: number, endMonth: number) {
  const m = now.getMonth() + 1;
  return m >= startMonth && m <= endMonth;
}

// Build a campaign for the current date, ends of month by default.
export function getActiveCampaign(now = new Date()): Campaign | null {
  const y = now.getFullYear();
  if (inMonthRange(now, 6, 9)) {
    return {
      id: `monsoon-${y}`,
      season: "monsoon",
      badge: "Monsoon Learning Sale",
      headline: "20% off any programme this monsoon",
      sub: "Use MONSOON26 at enrollment. Includes career-launch bootcamp.",
      code: "MONSOON26",
      endsAt: new Date(y, 8, 30, 23, 59).toISOString(),
      cta: "Claim offer",
      whatsappHref: "https://wa.me/918080187187?text=Hi%20TekSchool%2C%20I%27d%20like%20to%20use%20MONSOON26",
      theme: { bgFrom: "#EAF3FB", bgTo: "#CBDEF0", accent: "#5BA4E8", accentDeep: "#2D5FA8", motif: "rain", textOn: "dark" },
    };
  }
  if (inMonthRange(now, 10, 11)) {
    return {
      id: `diwali-${y}`,
      season: "diwali",
      badge: "Diwali Special",
      headline: "Light up your career — ₹15,000 off",
      sub: "Enroll before Nov 15. Includes 1:1 mentor track.",
      code: "DIWALI26",
      endsAt: new Date(y, 10, 15, 23, 59).toISOString(),
      cta: "Claim offer",
      whatsappHref: "https://wa.me/918080187187?text=Hi%20TekSchool%2C%20DIWALI26",
      theme: { bgFrom: "#FFF6E5", bgTo: "#F6D89A", accent: "#F4A261", accentDeep: "#B4763A", motif: "sparkle", textOn: "dark" },
    };
  }
  if (inMonthRange(now, 12, 12)) {
    return {
      id: `yearEnd-${y}`,
      season: "yearEnd",
      badge: "Year-End Offer",
      headline: "Start 2027 job-ready",
      sub: "Lock a January cohort seat with 25% off. Ends Dec 31.",
      code: "NEW27",
      endsAt: new Date(y, 11, 31, 23, 59).toISOString(),
      cta: "Claim offer",
      whatsappHref: "https://wa.me/918080187187?text=Hi%20TekSchool%2C%20NEW27",
      theme: { bgFrom: "#1E1B4B", bgTo: "#2D2A6B", accent: "#F4C86B", accentDeep: "#B48A2E", motif: "snow", textOn: "light" },
    };
  }
  // default: neutral demo booking (soft)
  return {
    id: "default",
    season: "default",
    badge: "Book a free demo",
    headline: "See a live class from the inside",
    sub: "45-minute session with a current cohort. No cost, no commitment.",
    code: "DEMO",
    cta: "Book a demo",
    whatsappHref: "https://wa.me/918080187187?text=Hi%20TekSchool%2C%20demo",
    theme: { bgFrom: "#F5F7FB", bgTo: "#E2EAF6", accent: "#5BA4E8", accentDeep: "#2D5FA8", motif: "none", textOn: "dark" },
  };
}

// Where the popup is allowed to render.
export function isMarketingPath(pathname: string): boolean {
  if (pathname.startsWith("/dashboard")) return false;
  if (pathname.startsWith("/admin")) return false;
  if (pathname.startsWith("/welcome")) return false;
  if (pathname.startsWith("/api")) return false;
  return true;
}
