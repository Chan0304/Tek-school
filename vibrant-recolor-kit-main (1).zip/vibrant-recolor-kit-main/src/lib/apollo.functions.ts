import { createServerFn } from "@tanstack/react-start";

export type ApolloHRContact = {
  id: string;
  name: string;
  title: string;
  company: string;
  email: string;
  phone: string;
  linkedin: string;
  hiringFor: string[];
  confidence: number;
  source: string;
};

const GATEWAY_URL = "https://connector-gateway.lovable.dev/firecrawl/v2";

const PRESETS: Record<string, { keywords: string; location: string; hiringFor: string[] }> = {
  ai: {
    keywords: '("technical recruiter" OR "talent acquisition" OR "engineering recruiter") (AI OR "machine learning" OR ML)',
    location: "Bengaluru India",
    hiringFor: ["AI Engineer", "ML Engineer"],
  },
  cloud: {
    keywords: '("technical recruiter" OR "talent acquisition") (cloud OR DevOps OR SRE OR AWS)',
    location: "India",
    hiringFor: ["Cloud SRE", "DevOps Engineer"],
  },
  backend: {
    keywords: '("technical recruiter" OR "engineering recruiter") (backend OR "full stack" OR software)',
    location: "India",
    hiringFor: ["Backend Engineer", "Full-stack Engineer"],
  },
};

function pickPreset(target: string) {
  const t = target.toLowerCase();
  if (t.includes("ai") || t.includes("ml")) return PRESETS.ai;
  if (t.includes("cloud") || t.includes("devops")) return PRESETS.cloud;
  return PRESETS.backend;
}

// Parse a LinkedIn search result title like: "Priya Sharma - Technical Recruiter - Acme | LinkedIn"
function parseLinkedIn(title: string, url: string) {
  const clean = title.replace(/\s*\|\s*LinkedIn.*$/i, "").replace(/\s*-\s*LinkedIn.*$/i, "");
  const parts = clean.split(/\s+[-–—]\s+/);
  const name = parts[0]?.trim() || "Unknown";
  const jobTitle = parts[1]?.trim() || "Recruiter";
  const company = parts[2]?.trim() || parts.slice(2).join(" - ").trim() || "—";
  const linkedin = url.replace(/^https?:\/\//, "").replace(/\/$/, "");
  return { name, title: jobTitle, company, linkedin };
}

export const findHRContacts = createServerFn({ method: "POST" })
  .inputValidator((input: { target: string; location?: string }) => input)
  .handler(async ({ data }): Promise<{ contacts: ApolloHRContact[]; note?: string }> => {
    const lovableKey = process.env.LOVABLE_API_KEY;
    const firecrawlKey = process.env.FIRECRAWL_API_KEY;
    if (!lovableKey || !firecrawlKey) {
      throw new Error("Firecrawl connector not configured");
    }

    const preset = pickPreset(data.target);
    const location = data.location || preset.location;
    const query = `site:linkedin.com/in ${preset.keywords} ${location}`;

    const res = await fetch(`${GATEWAY_URL}/search`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${lovableKey}`,
        "X-Connection-Api-Key": firecrawlKey,
      },
      body: JSON.stringify({ query, limit: 12 }),
    });

    const bodyText = await res.text();
    if (!res.ok) {
      console.error(`Firecrawl search failed [${res.status}]: ${bodyText}`);
      throw new Error(`Firecrawl search failed [${res.status}]: ${bodyText.slice(0, 300)}`);
    }

    let parsed: any;
    try { parsed = JSON.parse(bodyText); } catch { parsed = {}; }

    // Firecrawl v2 search response: { success, data: { web: [{url,title,description}] } } or { data: [...] }
    const rawResults: any[] = parsed?.data?.web || parsed?.data || parsed?.results || [];
    const linkedinResults = rawResults.filter((r) => (r.url || "").includes("linkedin.com/in/"));

    if (linkedinResults.length === 0) {
      return {
        contacts: [],
        note: "Firecrawl returned no LinkedIn profiles for this query. Try a different vertical or check Firecrawl credit balance.",
      };
    }

    const contacts: ApolloHRContact[] = linkedinResults.slice(0, 12).map((r, i) => {
      const { name, title, company, linkedin } = parseLinkedIn(r.title || "", r.url || "");
      return {
        id: `fc_${i}_${linkedin.slice(-12)}`,
        name,
        title,
        company,
        email: "(request via LinkedIn InMail)",
        phone: "(request via LinkedIn InMail)",
        linkedin,
        hiringFor: preset.hiringFor,
        confidence: Math.max(60, Math.min(95, 88 - i * 2)),
        source: "Firecrawl · LinkedIn public search",
      };
    });

    return {
      contacts,
      note: "Names, titles, and companies are sourced live from public LinkedIn profile snippets via Firecrawl. Reach out through the LinkedIn profile — email/phone are not publicly listed.",
    };
  });
