// Global CTA action bus for the dashboard. Any button can fire an action and
// a single <ActionModals /> mounted in the layout renders the right modal.
import { useEffect, useState } from "react";

export type Action =
  | { kind: "join-class"; topic: string; instructor: string; when: string; duration: string }
  | { kind: "watch-recording"; topic: string; module: string }
  | { kind: "add-to-calendar"; topic: string; when: string }
  | { kind: "submit-assignment"; title: string; submissionType: string; module: string }
  | { kind: "view-feedback"; title: string; grade?: string; feedback?: string; mentor?: string }
  | { kind: "apply-job"; role: string; company: string; location: string; salary?: string }
  | { kind: "view-application"; role: string; company: string; stage: string }
  | { kind: "rsvp-event"; title: string; kind_: string; when: string }
  | { kind: "message-person"; name: string; role: string }
  | { kind: "open-channel"; name: string; desc: string }
  | { kind: "open-resource"; title: string; kind_: string; desc: string }
  | { kind: "download-recording"; topic: string; module?: string }
  | { kind: "upgrade-cohort" }
  | { kind: "reward-detail"; title: string; progress: string }
  | { kind: "save-settings" }
  | { kind: "change-password" }
  | { kind: "toast"; message: string };

const EVT = "tek-action";

export function openAction(a: Action) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent<Action>(EVT, { detail: a }));
}

export function useAction() {
  const [action, setAction] = useState<Action | null>(null);
  useEffect(() => {
    const handler = (e: Event) => setAction((e as CustomEvent<Action>).detail);
    window.addEventListener(EVT, handler);
    return () => window.removeEventListener(EVT, handler);
  }, []);
  return { action, close: () => setAction(null) };
}

// Simple toast queue
type Toast = { id: number; message: string };
const listeners = new Set<(t: Toast[]) => void>();
let toasts: Toast[] = [];
let seq = 0;
export function pushToast(message: string) {
  const t = { id: ++seq, message };
  toasts = [...toasts, t];
  listeners.forEach((l) => l(toasts));
  setTimeout(() => {
    toasts = toasts.filter((x) => x.id !== t.id);
    listeners.forEach((l) => l(toasts));
  }, 3200);
}
export function useToasts() {
  const [list, setList] = useState<Toast[]>(toasts);
  useEffect(() => {
    listeners.add(setList);
    return () => { listeners.delete(setList); };
  }, []);
  return list;
}
