import { Cpu, Bot, BookOpen, Users, Headphones, Award, ArrowRight } from "lucide-react";
import { FormModalShell } from "./FormModalShell";

const FEATURES = [
  { icon: Cpu, title: "AI workstations & maker kits", desc: "GPU-enabled desktops, micro:bits, Arduino and robotics hardware shipped to your lab." },
  { icon: BookOpen, title: "Age-banded curriculum", desc: "Ready lesson plans mapped to CBSE / NEP outcomes for grades 3 through 12." },
  { icon: Users, title: "Teacher upskilling", desc: "Hands-on certification program so your faculty can run the lab confidently." },
  { icon: Bot, title: "AI & robotics projects", desc: "Chatbots, image classifiers, line-following rovers and capstone demos every term." },
  { icon: Headphones, title: "Ongoing support", desc: "Technical maintenance, content updates and a dedicated campus success manager." },
  { icon: Award, title: "Student certification", desc: "Portfolio reports and completion certificates for every learner." },
];

export function AILabModal({ open, onClose, onRequest }: { open: boolean; onClose: () => void; onRequest: () => void }) {
  return (
    <FormModalShell
      open={open}
      onClose={onClose}
      badge="New offering"
      title="AI Lab Set up"
      subtitle="A ready-to-run AI + robotics lab for your school or college — hardware, curriculum, training and support included."
      maxWidth="560px"
    >
      <div className="space-y-5">
        <div className="grid gap-4 sm:grid-cols-2">
          {FEATURES.map((f) => (
            <div key={f.title} className="rounded-2xl border border-border/70 bg-muted/30 p-4">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-[color:var(--lavender)] text-[color:var(--lavender-foreground)]">
                <f.icon className="h-4.5 w-4.5" />
              </span>
              <p className="mt-3 text-sm font-semibold">{f.title}</p>
              <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>

        <div className="rounded-2xl bg-gradient-to-br from-[#1E3A8A] via-[#2563EB] to-[#7C3AED] p-5 text-white">
          <p className="font-display text-lg font-bold">Start with a free campus assessment.</p>
          <p className="mt-1 text-sm text-white/85">
            Our team visits your institution, audits the space and recommends the right lab configuration.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            onClose();
            setTimeout(onRequest, 200);
          }}
          className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary py-3.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
        >
          Request AI lab setup <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </FormModalShell>
  );
}
