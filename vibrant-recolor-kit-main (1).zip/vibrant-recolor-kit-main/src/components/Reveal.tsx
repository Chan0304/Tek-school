import { useEffect, useRef, useState, type ReactNode, type CSSProperties } from "react";

/**
 * Scroll-triggered fade + slide-up entrance.
 *
 * Part of the site-wide motion system:
 *  - easing:  var(--ease-out-soft)  (cubic-bezier(.16,1,.3,1))
 *  - timing:  var(--dur-enter)      (~420ms)
 *  - trigger: ~15% viewport intersection, fires once
 *  - stagger: pass `index` for a 90ms-per-item cascade (cap 8 → group fade)
 *  - reduced-motion: degrades to instant show (handled globally in styles.css)
 */
export function Reveal({
  children,
  delay = 0,
  index,
  className = "",
  as: As = "div",
  y = 24,
}: {
  children: ReactNode;
  delay?: number;
  index?: number;
  className?: string;
  as?: keyof React.JSX.IntrinsicElements;
  y?: number;
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      setShown(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            setShown(true);
            io.disconnect();
            break;
          }
        }
      },
      { threshold: 0.15, rootMargin: "0px 0px -40px 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  // Stagger: 90ms per item, capped at 8 items to avoid dragging tails.
  const staggerDelay =
    typeof index === "number" ? Math.min(index, 7) * 90 : 0;
  const totalDelay = delay + staggerDelay;

  const style: CSSProperties = {
    opacity: shown ? 1 : 0,
    transform: shown ? "translate3d(0,0,0)" : `translate3d(0, ${y}px, 0)`,
    transition: `opacity var(--dur-enter) var(--ease-out-soft) ${totalDelay}ms, transform var(--dur-enter) var(--ease-out-soft) ${totalDelay}ms`,
    willChange: "opacity, transform",
  };

  // @ts-expect-error dynamic tag
  return <As ref={ref} className={className} style={style}>{children}</As>;
}
