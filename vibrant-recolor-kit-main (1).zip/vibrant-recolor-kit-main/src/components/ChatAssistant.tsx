import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { X, Minus, RotateCcw, UserRound, Send, ArrowUpRight, Clock, Users, CheckCircle2, AlertCircle } from "lucide-react";
import { AssistantMark } from "./AssistantMark";
import type { CourseColor, CourseData } from "@/lib/courses-data";

/* ---------------- Quick reply pills ---------------- */

type QuickReply = { label: string; accent: "coral" | "lavender" | "blue" };

const STARTERS: QuickReply[] = [
  { label: "Find a course", accent: "coral" },
  { label: "Check enrollment status", accent: "lavender" },
  { label: "Talk to admissions", accent: "blue" },
];

const accentStyles: Record<QuickReply["accent"], string> = {
  coral: "bg-[color:var(--coral)] text-[color:var(--primary)]",
  lavender: "bg-[color:var(--lavender)] text-[color:var(--primary)]",
  blue: "bg-[color:var(--sky)] text-[color:var(--primary)]",
};

function Pill({ reply, onClick }: { reply: QuickReply; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      data-cursor="none"
      className={`inline-flex items-center rounded-full px-4 py-2 text-sm font-medium shadow-sm transition-transform duration-200 hover:-rotate-1 hover:scale-[1.02] ${accentStyles[reply.accent]}`}
    >
      {reply.label}
    </button>
  );
}

/* ---------------- Inline course card ---------------- */

const cardTint: Record<CourseColor, string> = {
  coral: "bg-[color:var(--coral)]",
  lavender: "bg-[color:var(--lavender)]",
  blue: "bg-[color:var(--sky)]",
  navy: "bg-[color:var(--primary)] text-[color:var(--primary-foreground)]",
};

function InlineCourseCard({ c }: { c: CourseData }) {
  const isNavy = c.color === "navy";
  return (
    <Link
      to="/courses/$slug"
      params={{ slug: c.slug }}
      data-cursor="enroll"
      className={`group block rounded-2xl p-4 shadow-sm ${cardTint[c.color]} transition-transform hover:-translate-y-0.5`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className={`text-[11px] uppercase tracking-wide ${isNavy ? "opacity-70" : "text-[color:var(--primary)]/60"}`}>
            {c.category} · {c.level}
          </div>
          <div className="mt-1 font-display text-base font-semibold leading-tight">{c.title}</div>
        </div>
        <ArrowUpRight className="h-4 w-4 shrink-0 opacity-70 group-hover:opacity-100" />
      </div>
      <div className={`mt-2 flex items-center justify-between text-xs ${isNavy ? "opacity-90" : "text-[color:var(--primary)]/80"}`}>
        <span className="font-bold text-sm">${c.price.toLocaleString()}</span>
        <span>{c.seatsLeft === 0 ? "Waitlist" : `${c.seatsLeft} seats`}</span>
      </div>
      <div className={`mt-2 flex items-center gap-3 text-[11px] ${isNavy ? "opacity-80" : "text-[color:var(--primary)]/70"}`}>
        <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" />{c.duration}</span>
        <span className="inline-flex items-center gap-1"><Users className="h-3 w-3" />{c.students}</span>
      </div>
    </Link>
  );
}

/* ---------------- Thinking dots ---------------- */

function ThinkingDots() {
  return (
    <div className="flex items-center gap-1.5 py-1">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="h-2 w-2 rounded-full"
          style={{
            background: "linear-gradient(135deg, #5BA4E8, #2D5FA8)",
            animation: `tek-pulse 1.2s ease-in-out ${i * 0.15}s infinite`,
          }}
        />
      ))}
    </div>
  );
}

/* ---------------- Handoff card (routes to Contact w/ prefill) ---------------- */

function HandoffCard({ o, transcript, onNavigated }: {
  o: { ticketId?: string; summary?: string; preferredInterest?: string; name?: string; email?: string; responseTime?: string };
  transcript: string;
  onNavigated: () => void;
}) {
  const navigate = useNavigate();
  const goToContact = () => {
    try {
      sessionStorage.setItem("tek-contact-prefill", JSON.stringify({
        name: o.name || "",
        email: o.email || "",
        interest: o.preferredInterest || "Not sure yet",
        message: `From assistant chat (ticket ${o.ticketId}):\n${o.summary || ""}\n\n---\nConversation summary:\n${transcript}`,
      }));
    } catch { /* ignore */ }
    onNavigated();
    navigate({ to: "/contact" });
  };
  return (
    <div className="mt-2 rounded-2xl border border-[color:var(--sky)]/30 bg-[color:var(--sky)]/10 p-3 text-xs text-[color:var(--primary)]">
      <div className="flex items-start gap-2">
        <UserRound className="h-4 w-4 mt-0.5" />
        <div>
          <p>Passing you to admissions (ticket {o.ticketId}). Reply time is {o.responseTime}.</p>
          <button
            type="button"
            onClick={goToContact}
            className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-[color:var(--primary)] text-white px-3 py-1.5 text-xs font-semibold"
          >
            Open contact form <ArrowUpRight className="h-3 w-3" />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Tool result renderer ---------------- */

function ToolResult({ name, output, transcript, onNavigated }: {
  name: string;
  output: unknown;
  transcript: string;
  onNavigated: () => void;
}) {
  if (!output || typeof output !== "object") return null;
  const o = output as Record<string, unknown>;

  if (name === "find_courses" && Array.isArray(o.courses)) {
    return (
      <div className="mt-2 grid gap-2">
        {(o.courses as CourseData[]).map((c) => <InlineCourseCard key={c.slug} c={c} />)}
      </div>
    );
  }
  if (name === "check_availability") {
    if (!o.found) return <ConfirmBox tone="warn">Couldn't find that course. Want me to list what's open?</ConfirmBox>;
    if (o.waitlist) return <ConfirmBox tone="warn">{`${o.title} is full — waitlist only. Next cohort opens ${o.nextCohort}.`}</ConfirmBox>;
    return <ConfirmBox>{`${o.seatsLeft} of ${o.seatsTotal} seats left in ${o.title}. Next cohort starts ${o.nextCohort}. $${(o.price as number).toLocaleString()}.`}</ConfirmBox>;
  }
  if (name === "start_enrollment") {
    if (!o.ok) {
      const reason = o.reason === "invalid_email" ? "That email doesn't look right — mind sending it again?"
        : o.reason === "invalid_name" ? "Could you send your full name?"
        : "Hmm, I couldn't find that course.";
      return <ConfirmBox tone="warn">{reason}</ConfirmBox>;
    }
    return (
      <div className="mt-2 rounded-2xl bg-[color:var(--coral)] text-[color:var(--primary)] p-4 text-sm">
        <div className="flex items-start gap-2">
          <CheckCircle2 className="h-5 w-5 mt-0.5" />
          <div>
            <p className="font-display font-bold">Application started — {String(o.applicationId)}</p>
            <p className="mt-1 text-xs opacity-90">
              {String(o.name)} · {String(o.courseTitle)}<br />
              {o.waitlist ? "Waitlist — we'll email when a seat opens." : `Next cohort: ${String(o.nextCohort)}`}
            </p>
            <p className="mt-2 text-xs opacity-90">
              Check {String(o.email)} — confirmation link is on its way. Payment (${(o.price as number).toLocaleString()}) is the next step.
            </p>
          </div>
        </div>
      </div>
    );
  }
  if (name === "handoff_human") {
    return <HandoffCard o={o as never} transcript={transcript} onNavigated={onNavigated} />;
  }
  return null;
}

function ConfirmBox({ children, tone = "ok" }: { children: React.ReactNode; tone?: "ok" | "warn" }) {
  const cls = tone === "warn"
    ? "border-amber-300 bg-amber-50 text-amber-900"
    : "border-[color:var(--sky)]/30 bg-[color:var(--sky)]/10 text-[color:var(--primary)]";
  return (
    <div className={`mt-2 rounded-2xl border ${cls} px-3 py-2 text-xs flex items-start gap-2`}>
      {tone === "warn" ? <AlertCircle className="h-3.5 w-3.5 mt-0.5 shrink-0" /> : <CheckCircle2 className="h-3.5 w-3.5 mt-0.5 shrink-0" />}
      <span>{children}</span>
    </div>
  );
}

/* ---------------- Message rendering ---------------- */

function MessageBubble({ m, transcript, onNavigated }: { m: UIMessage; transcript: string; onNavigated: () => void }) {
  const isUser = m.role === "user";
  const text = m.parts
    .filter((p): p is Extract<typeof p, { type: "text" }> => p.type === "text")
    .map((p) => p.text)
    .join("");

  const toolParts = m.parts.filter((p) => p.type.startsWith("tool-"));

  if (isUser) {
    return (
      <div className="flex justify-end">
        <div className="max-w-[85%] rounded-2xl rounded-br-md bg-[color:var(--primary)] px-3.5 py-2 text-sm text-[color:var(--primary-foreground)]">
          {text}
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start gap-2">
      <div className="mt-0.5 h-7 w-7 shrink-0 rounded-full bg-white ring-1 ring-black/5 grid place-items-center">
        <AssistantMark className="h-5 w-5" />
      </div>
      <div className="min-w-0 max-w-[85%]">
        {text && (
          <div className="rounded-2xl rounded-tl-md bg-[#F5F3EE] px-3.5 py-2 text-sm text-[color:var(--primary)] whitespace-pre-wrap">
            {text}
          </div>
        )}
        {toolParts.map((p, i) => {
          const toolName = p.type.replace(/^tool-/, "");
          const state = (p as { state?: string }).state;
          if (state && state !== "output-available") {
            return (
              <div key={i} className="mt-2 inline-flex items-center gap-2 rounded-full bg-[#F5F3EE] px-3 py-1.5 text-xs text-[color:var(--primary)]/70">
                <ThinkingDots />
                <span>Working on it…</span>
              </div>
            );
          }
          const output = (p as { output?: unknown }).output;
          return <ToolResult key={i} name={toolName} output={output} transcript={transcript} onNavigated={onNavigated} />;
        })}
      </div>
    </div>
  );
}

/* ---------------- Main assistant ---------------- */

export function ChatAssistant() {
  const [open, setOpen] = useState(false);
  const [pulsed, setPulsed] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const { messages, sendMessage, status, setMessages } = useChat({
    transport: new DefaultChatTransport({ api: "/api/chat" }),
  });

  const isLoading = status === "submitted" || status === "streaming";

  useEffect(() => {
    const t = setTimeout(() => setPulsed(true), 2500);
    const openHandler = () => setOpen(true);
    window.addEventListener("tek-open-chat", openHandler);
    return () => {
      clearTimeout(t);
      window.removeEventListener("tek-open-chat", openHandler);
    };
  }, []);


  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, isLoading]);

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open, messages.length]);

  const send = (text: string) => {
    const t = text.trim();
    if (!t || isLoading) return;
    sendMessage({ text: t });
  };

  const reset = () => setMessages([]);

  // Build a short transcript string for handoff context.
  const transcript = messages
    .map((m) => {
      const txt = m.parts
        .filter((p): p is Extract<typeof p, { type: "text" }> => p.type === "text")
        .map((p) => p.text)
        .join(" ")
        .trim();
      return txt ? `${m.role === "user" ? "You" : "Tek Guru"}: ${txt}` : "";
    })
    .filter(Boolean)
    .slice(-12)
    .join("\n");

  return (
    <>
      <style>{`
        @keyframes tek-pulse { 0%,100% { opacity:.35; transform: translateY(0);} 50% { opacity:1; transform: translateY(-2px);} }
        @keyframes tek-ring { 0% { box-shadow: 0 0 0 0 rgba(91,164,232,.55);} 100% { box-shadow: 0 0 0 22px rgba(91,164,232,0);} }
      `}</style>

      {!open && (
        <button
          type="button"
          onClick={() => setOpen(true)}
          aria-label="Open Tek Guru"
          data-cursor="view"
          className="fixed bottom-5 right-5 z-50 grid h-14 w-14 place-items-center rounded-full bg-white text-[color:var(--primary)] shadow-lg ring-1 ring-black/10 transition hover:scale-105"
          style={!pulsed ? { animation: "tek-ring 1.6s ease-out 1" } : undefined}
        >
          <AssistantMark className="h-7 w-7" />
        </button>
      )}

      {open && (
        <div
          className="fixed z-50 bg-white shadow-2xl ring-1 ring-black/5 flex flex-col
                     inset-0 rounded-none
                     sm:inset-auto sm:bottom-5 sm:right-5 sm:h-[640px] sm:max-h-[85vh] sm:w-[400px] sm:rounded-[24px]"
        >
          <div className="flex items-center gap-3 rounded-t-none sm:rounded-t-[24px] bg-[color:var(--primary)] px-4 py-3 text-white">
            <div className="grid h-9 w-9 place-items-center rounded-full bg-white/10">
              <AssistantMark className="h-6 w-6" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="font-display font-semibold truncate">Tek Guru</span>
                <span className="inline-flex items-center gap-1 text-[11px] opacity-90">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> online
                </span>
              </div>
              <div className="text-[11px] opacity-70">Your always-on admissions & learning mentor</div>
            </div>
            <button onClick={reset} title="Start over" className="rounded-full p-1.5 hover:bg-white/10">
              <RotateCcw className="h-4 w-4" />
            </button>
            <button onClick={() => setOpen(false)} title="Minimize" className="rounded-full p-1.5 hover:bg-white/10">
              <Minus className="h-4 w-4 sm:hidden" />
              <X className="hidden h-4 w-4 sm:block" />
            </button>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-3 bg-white">
            {messages.length === 0 && (
              <div className="space-y-3">
                <div className="flex items-start gap-2">
                  <div className="mt-0.5 h-7 w-7 shrink-0 rounded-full bg-white ring-1 ring-black/5 grid place-items-center">
                    <AssistantMark className="h-5 w-5" />
                  </div>
                  <div className="rounded-2xl rounded-tl-md bg-[#F5F3EE] px-3.5 py-2 text-sm text-[color:var(--primary)]">
                    Hi 👋 I'm Tek Guru. Tell me what's on your mind and I'll sort it out with you.
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 pl-9">
                  {STARTERS.map((s) => (
                    <Pill key={s.label} reply={s} onClick={() => send(s.label)} />
                  ))}
                </div>
              </div>
            )}

            {messages.map((m) => (
              <MessageBubble
                key={m.id}
                m={m}
                transcript={transcript}
                onNavigated={() => setOpen(false)}
              />
            ))}

            {status === "submitted" && (
              <div className="flex items-start gap-2">
                <div className="mt-0.5 h-7 w-7 shrink-0 rounded-full bg-white ring-1 ring-black/5 grid place-items-center">
                  <AssistantMark className="h-5 w-5" />
                </div>
                <div className="rounded-2xl rounded-tl-md bg-[#F5F3EE] px-3.5 py-2">
                  <ThinkingDots />
                </div>
              </div>
            )}
          </div>

          <div className="border-t bg-white px-4 pt-2 pb-3 rounded-b-none sm:rounded-b-[24px]">
            <button
              onClick={() => send("Please connect me to a real person from admissions.")}
              className="mb-2 inline-flex items-center gap-1.5 text-xs text-[color:var(--primary)]/70 hover:text-[color:var(--primary)]"
            >
              <UserRound className="h-3.5 w-3.5" />
              Talk to a human
            </button>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const el = inputRef.current;
                if (!el) return;
                const v = el.value;
                el.value = "";
                send(v);
              }}
              className="flex items-end gap-2 rounded-2xl border bg-white px-3 py-2 focus-within:ring-2 focus-within:ring-[color:var(--sky)]/40"
            >
              <textarea
                ref={inputRef}
                rows={1}
                placeholder="Ask Tek Guru anything…"
                maxLength={1000}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    (e.currentTarget.form as HTMLFormElement).requestSubmit();
                  }
                }}
                className="flex-1 resize-none bg-transparent text-sm outline-none max-h-32 min-w-0"
              />
              <button
                type="submit"
                disabled={isLoading}
                className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[color:var(--primary)] text-white disabled:opacity-40"
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
