import { useRouterState } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";

/**
 * Cross-fade page content on route change (~500ms, soft ease-out).
 * Keys on pathname so <main> children remount with the tek-route-in keyframe.
 * Reduced-motion is honored globally via prefers-reduced-motion in styles.css.
 */
export function RouteTransition({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [key, setKey] = useState(pathname);

  useEffect(() => {
    setKey(pathname);
    // Scroll to top on route change for a clean entrance frame.
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "auto" });
  }, [pathname]);

  return (
    <div key={key} className="tek-route-fade">
      {children}
    </div>
  );
}
