import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useRouterState } from "@tanstack/react-router";
import { getActiveCampaign, isMarketingPath, type Campaign } from "@/lib/campaigns";
import { X, Sparkles, Umbrella, Snowflake, Gift } from "lucide-react";
import { LeadModal } from "./LeadModal";

const DISMISS_KEY_PREFIX = "tek-campaign-dismissed-";

export function SeasonalPopup() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [ready, setReady] = useState(false);
  const [open, setOpen] = useState(false);
  const [leadOpen, setLeadOpen] = useState(false);
  const campaign = useMemo(() => getActiveCampaign(), []);
  const armedRef = useRef(false);

  // Trigger logic: 5s delay OR 45% scroll; skip on non-marketing routes; queue if another modal is open.
  useEffect(() => {
    if (!campaign) return;
    if (!isMarketingPath(path)) return;
    if (typeof window === "undefined") return;
    if (sessionStorage.getItem(DISMISS_KEY_PREFIX + campaign.id)) return;
    if (armedRef.current) return;
    armedRef.current = true;

    let done = false;
    const tryOpen = () => {
      if (done) return;
      // Queue if another modal is open — poll briefly.
      if (document.documentElement.hasAttribute("data-modal-open")) {
        setTimeout(tryOpen, 500);
        return;
      }
      done = true;
      setReady(true);
      // next frame so scale-in plays
      requestAnimationFrame(() => setOpen(true));
    };

    const delay = setTimeout(tryOpen, 5000);
    const onScroll = () => {
      const doc = document.documentElement;
      const pct = (doc.scrollTop + window.innerHeight) / doc.scrollHeight;
      if (pct >= 0.45) tryOpen();
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => { clearTimeout(delay); window.removeEventListener("scroll", onScroll); };
  }, [path, campaign]);

  if (!campaign || typeof document === "undefined") return null;

  const dismiss = () => {
    sessionStorage.setItem(DISMISS_KEY_PREFIX + campaign.id, "1");
    setOpen(false);
    setTimeout(() => setReady(false), 220);
  };

  return (
    <>
      <LeadModal
        open={leadOpen}
        onClose={() => setLeadOpen(false)}
        badge={campaign.badge}
        title={campaign.headline}
        subtitle={`Share your details and we'll apply code ${campaign.code} to your enrollment.`}
        interest={`Campaign: ${campaign.code}`}
        institutionType="Campaign lead"
        cta="Claim my offer"
      />
      {ready && createPortal(
    <div className={`fixed inset-0 z-[95] transition-opacity duration-200 ${open ? "opacity-100" : "opacity-0"}`}>
      <button aria-label="Close" onClick={dismiss} className="absolute inset-0 bg-slate-900/55 backdrop-blur-sm" />

      <div className="pointer-events-none absolute inset-0 flex items-end justify-center p-0 sm:items-center sm:p-6">
        <div
          data-modal-open="true"
          className={`pointer-events-auto relative w-full max-w-lg overflow-hidden rounded-t-3xl border shadow-2xl transition-transform duration-200 sm:rounded-3xl ${
            open ? "translate-y-0 scale-100" : "translate-y-6 scale-95"
          }`}
          style={{ background: `linear-gradient(135deg, ${campaign.theme.bgFrom}, ${campaign.theme.bgTo})`, borderColor: campaign.theme.accent + "40", color: campaign.theme.textOn === "light" ? "#fff" : "#0B1220" }}
        >
          <AmbientMotif motif={campaign.theme.motif} tint={campaign.theme.accent} />
          <button
            aria-label="Close"
            onClick={dismiss}
            className={`absolute right-4 top-4 z-10 grid h-9 w-9 place-items-center rounded-full ${campaign.theme.textOn === "light" ? "text-white/70 hover:bg-white/10" : "text-slate-500 hover:bg-white/60"}`}
          >
            <X className="h-4 w-4" />
          </button>

          <div className="relative z-[1] p-5 pr-14 sm:p-9 sm:pr-9">
            <span
              className="inline-flex max-w-full items-center gap-1.5 truncate rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider sm:text-[11px]"
              style={{ background: campaign.theme.textOn === "light" ? "rgba(255,255,255,0.12)" : "rgba(255,255,255,0.65)", color: campaign.theme.accentDeep }}
            >
              <BadgeIcon season={campaign.season} /> {campaign.badge}
            </span>
            <h2 className="mt-3 font-display text-xl font-bold leading-tight sm:mt-4 sm:text-3xl">{campaign.headline}</h2>
            <p className={`mt-2 text-[13px] sm:text-sm ${campaign.theme.textOn === "light" ? "text-white/80" : "text-slate-700"}`}>{campaign.sub}</p>
            {campaign.endsAt && <Countdown iso={campaign.endsAt} accent={campaign.theme.accentDeep} onLight={campaign.theme.textOn === "light"} />}

            <div className="mt-5 flex flex-col gap-3 sm:mt-6 sm:flex-row sm:flex-wrap sm:items-center">
              <button
                type="button"
                onClick={() => { setLeadOpen(true); dismiss(); }}
                className="inline-flex w-full items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold text-white shadow-lg sm:w-auto sm:py-2.5"
                style={{ background: `linear-gradient(135deg, ${campaign.theme.accentDeep}, ${campaign.theme.accent})` }}
              >
                {campaign.cta} <Sparkles className="h-3.5 w-3.5" />
              </button>

              <div className="flex items-center justify-between gap-3 sm:contents">
                <a
                  href={campaign.whatsappHref}
                  target="_blank" rel="noopener noreferrer"
                  onClick={dismiss}
                  className={`text-sm font-semibold underline underline-offset-4 ${campaign.theme.textOn === "light" ? "text-white/80" : "text-slate-700"}`}
                >
                  Chat on WhatsApp
                </a>
                <button onClick={dismiss} className={`text-xs sm:ml-auto ${campaign.theme.textOn === "light" ? "text-white/60" : "text-slate-500"} hover:underline`}>
                  Maybe later
                </button>
              </div>
            </div>

            <p className={`mt-4 text-[10px] uppercase tracking-widest sm:text-[11px] ${campaign.theme.textOn === "light" ? "text-white/50" : "text-slate-500"}`}>
              Code · <b className="tracking-normal">{campaign.code}</b>
            </p>
          </div>

        </div>
      </div>
    </div>,
    document.body,
      )}
    </>
  );
}


function BadgeIcon({ season }: { season: Campaign["season"] }) {
  if (season === "monsoon") return <Umbrella className="h-3.5 w-3.5" />;
  if (season === "yearEnd") return <Snowflake className="h-3.5 w-3.5" />;
  if (season === "diwali") return <Sparkles className="h-3.5 w-3.5" />;
  return <Gift className="h-3.5 w-3.5" />;
}

function Countdown({ iso, accent, onLight }: { iso: string; accent: string; onLight: boolean }) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const diff = Math.max(0, new Date(iso).getTime() - now);
  const d = Math.floor(diff / 86400000);
  const h = Math.floor((diff % 86400000) / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  return (
    <div className="mt-4 flex flex-wrap items-center gap-2">
      {[
        [d, "d"], [h, "h"], [m, "m"], [s, "s"],
      ].map(([v, u], i) => (
        <span key={i} className="inline-flex items-baseline gap-0.5 rounded-lg px-2.5 py-1 text-sm font-bold tabular-nums" style={{ background: onLight ? "rgba(255,255,255,0.14)" : "rgba(255,255,255,0.7)", color: accent }}>
          {String(v).padStart(2, "0")}<span className="text-[10px] font-semibold opacity-70">{u}</span>
        </span>
      ))}
      <span className={`text-[11px] ${onLight ? "text-white/60" : "text-slate-500"}`}>until offer ends</span>
    </div>
  );
}

function AmbientMotif({ motif, tint }: { motif: Campaign["theme"]["motif"]; tint: string }) {
  const reduced = typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
  if (motif === "none" || reduced) return null;
  if (motif === "rain") {
    return (
      <svg className="pointer-events-none absolute inset-0 h-full w-full opacity-40" viewBox="0 0 400 300" preserveAspectRatio="none" aria-hidden>
        {Array.from({ length: 22 }).map((_, i) => {
          const x = (i * 47) % 400;
          const dur = 1.6 + ((i * 13) % 10) / 10;
          return <line key={i} x1={x} y1={-20} x2={x - 8} y2={20} stroke={tint} strokeWidth="1.4" strokeLinecap="round">
            <animate attributeName="y1" from="-20" to="300" dur={`${dur}s`} repeatCount="indefinite" />
            <animate attributeName="y2" from="20" to="340" dur={`${dur}s`} repeatCount="indefinite" />
          </line>;
        })}
      </svg>
    );
  }
  if (motif === "sparkle") {
    return (
      <svg className="pointer-events-none absolute inset-0 h-full w-full opacity-60" viewBox="0 0 400 300" aria-hidden>
        {Array.from({ length: 14 }).map((_, i) => {
          const x = (i * 71) % 380 + 10;
          const y = (i * 53) % 260 + 20;
          const dur = 1.8 + (i % 5) * 0.3;
          return (
            <g key={i} transform={`translate(${x} ${y})`}>
              <path d="M0 -5 L1 -1 L5 0 L1 1 L0 5 L-1 1 L-5 0 L-1 -1 Z" fill={tint}>
                <animate attributeName="opacity" values="0.2;1;0.2" dur={`${dur}s`} repeatCount="indefinite" />
              </path>
            </g>
          );
        })}
      </svg>
    );
  }
  if (motif === "snow") {
    return (
      <svg className="pointer-events-none absolute inset-0 h-full w-full opacity-70" viewBox="0 0 400 300" preserveAspectRatio="none" aria-hidden>
        {Array.from({ length: 18 }).map((_, i) => {
          const x = (i * 41) % 400;
          const r = 1 + (i % 3);
          const dur = 5 + (i % 5);
          return <circle key={i} cx={x} cy={-r} r={r} fill="#fff">
            <animate attributeName="cy" from={-r} to={320} dur={`${dur}s`} repeatCount="indefinite" />
          </circle>;
        })}
      </svg>
    );
  }
  return null;
}
