import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Modal, PrimaryBtn, GhostBtn } from "./Modal";
import { pushToast, useAction, useToasts, type Action } from "@/lib/action-bus";
import { CheckCircle2, Video, Download, Github, FileText, Upload, Send, Bell, Award, Calendar, MessageCircle, Hash, Sparkles } from "lucide-react";

export function ActionModals() {
  const { action, close } = useAction();
  useEffect(() => {
    if (action?.kind === "toast") {
      pushToast(action.message);
      close();
    }
  }, [action, close]);

  return (
    <>
      <Renderer action={action} close={close} />
      <ToastStack />
    </>
  );
}

function Renderer({ action, close }: { action: Action | null; close: () => void }) {
  const navigate = useNavigate();
  const open = action !== null && action.kind !== "toast";
  if (!action || action.kind === "toast") return <Modal open={false} onClose={close} />;

  switch (action.kind) {
    case "join-class":
      return (
        <Modal open={open} onClose={close} tone="navy"
          eyebrow={<span className="pill-tag -rotate-2 bg-accent-blue/20 text-accent-blue-deep"><Video className="h-3 w-3" /> Live class</span>}
          title={action.topic}
          footer={<>
            <GhostBtn onClick={close}>Not now</GhostBtn>
            <PrimaryBtn onClick={() => { close(); navigate({ to: "/dashboard/live-room", search: { topic: action.topic, instructor: action.instructor } as any }); }}>Open live room</PrimaryBtn>
          </>}
        >
          <p className="text-sm">{action.instructor} · {action.when} · {action.duration}</p>
          <ul className="mt-4 space-y-2 text-sm">
            {["Camera + mic checked", "Notebook + code editor open", "Questions ready in the chat panel"].map((t) => (
              <li key={t} className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-[var(--accent-blue-deep)]" /> {t}</li>
            ))}
          </ul>
        </Modal>
      );

    case "watch-recording":
      return (
        <Modal open={open} onClose={close} title={action.topic}
          eyebrow={<span className="pill-tag -rotate-2 bg-lavender/50"><Video className="h-3 w-3" /> Recording</span>}
          footer={<><GhostBtn onClick={close}>Close</GhostBtn>
            <PrimaryBtn onClick={() => { pushToast("Recording opened at 1×"); close(); }}>Play now</PrimaryBtn></>}
        >
          <p className="text-sm">{action.module}. Playback saves to your progress — resume anytime.</p>
          <div className="mt-4 aspect-video rounded-2xl bg-gradient-to-br from-[#1E1B4B] to-[#2D5FA8] grid place-items-center text-white">
            <Video className="h-10 w-10 opacity-80" />
          </div>
        </Modal>
      );

    case "add-to-calendar":
      return (
        <Modal open={open} onClose={close} title="Add to calendar"
          eyebrow={<span className="pill-tag -rotate-2 bg-accent-blue/20 text-accent-blue-deep"><Calendar className="h-3 w-3" /> Reminder</span>}
          footer={<>
            <GhostBtn onClick={close}>Close</GhostBtn>
            <PrimaryBtn onClick={() => { pushToast("Added to Google Calendar"); close(); }}>Google</PrimaryBtn>
            <PrimaryBtn onClick={() => { pushToast("ICS downloaded"); close(); }}>Download .ics</PrimaryBtn>
          </>}
        >
          <p className="text-sm">{action.topic} — {action.when}</p>
        </Modal>
      );

    case "submit-assignment": {
      const isRepo = action.submissionType === "Code repo";
      return (
        <SubmitForm open={open} close={close} title={action.title} module={action.module} isRepo={isRepo} />
      );
    }

    case "view-feedback":
      return <FeedbackForm open={open} close={close} title={action.title} grade={action.grade} feedback={action.feedback} mentor={action.mentor ?? "Ananya Rao"} />;


    case "apply-job":
      return (
        <ApplyForm open={open} close={close} role={action.role} company={action.company} location={action.location} salary={action.salary} />
      );

    case "view-application":
      return (
        <Modal open={open} onClose={close} title={`${action.company} — ${action.role}`}
          eyebrow={<span className="pill-tag -rotate-2 bg-accent-blue/20 text-accent-blue-deep">Stage: {action.stage}</span>}
          footer={<>
            <GhostBtn onClick={close}>Close</GhostBtn>
            <PrimaryBtn onClick={() => { pushToast("Placement team notified"); close(); }}>Request help</PrimaryBtn>
          </>}
        >
          <ol className="relative mt-2 space-y-3 border-l border-slate-200 pl-5 text-sm">
            {["Applied", "Screening", "Interview", "Offer"].map((s) => {
              const active = ["Applied","Screening","Interview","Offer"].indexOf(action.stage) >= ["Applied","Screening","Interview","Offer"].indexOf(s);
              return (
                <li key={s}>
                  <span className={`absolute -left-[7px] h-3 w-3 rounded-full ${active ? "bg-[var(--accent-blue-deep)]" : "bg-slate-200"}`} />
                  <p className={active ? "font-semibold" : "text-slate-400"}>{s}</p>
                </li>
              );
            })}
          </ol>
        </Modal>
      );

    case "rsvp-event":
      return (
        <Modal open={open} onClose={close} title={action.title}
          eyebrow={<span className="pill-tag -rotate-2 bg-coral/40 text-coral-foreground">{action.kind_}</span>}
          footer={<><GhostBtn onClick={close}>Cancel</GhostBtn>
            <PrimaryBtn onClick={() => { pushToast("You're RSVP'd. Confirmation emailed."); close(); }}>Confirm RSVP</PrimaryBtn></>}
        >
          <p className="text-sm">{action.when}. Reserve your spot — capacity is limited.</p>
        </Modal>
      );

    case "message-person":
      return <MessageForm open={open} close={close} name={action.name} role={action.role} />;

    case "open-channel":
      return (
        <Modal open={open} onClose={close} title={`#${action.name}`}
          eyebrow={<span className="pill-tag -rotate-2 bg-accent-blue/20 text-accent-blue-deep"><Hash className="h-3 w-3" /> Channel</span>}
          footer={<><GhostBtn onClick={close}>Close</GhostBtn>
            <PrimaryBtn onClick={() => { pushToast("Opening Discord…"); close(); }}>Open in Discord</PrimaryBtn></>}
        >
          <p className="text-sm">{action.desc}</p>
          <div className="mt-4 space-y-2 rounded-2xl bg-slate-50 p-3 text-xs">
            <p><b>Ananya</b> — pinned the RAG cheat-sheet. Start there before Friday.</p>
            <p><b>Karan V.</b> — anyone running into CUDA OOM on the LoRA notebook?</p>
            <p><b>Meera S.</b> — sharing my week-4 write-up, tear it apart 🙏</p>
          </div>
        </Modal>
      );

    case "open-resource":
      return (
        <Modal open={open} onClose={close} title={action.title}
          eyebrow={<span className="pill-tag -rotate-2 bg-lavender/50">{action.kind_}</span>}
          footer={<>
            <GhostBtn onClick={close}>Close</GhostBtn>
            <PrimaryBtn onClick={() => { pushToast(`${action.kind_} opened`); close(); }}>{action.kind_ === "PDF" ? "Open PDF" : action.kind_ === "Tool" ? "Launch tool" : "Open"}</PrimaryBtn>
          </>}
        >
          <p className="text-sm">{action.desc}</p>
        </Modal>
      );

    case "download-recording":
      return (
        <Modal open={open} onClose={close} title="Download recording"
          eyebrow={<span className="pill-tag -rotate-2 bg-coral/40 text-coral-foreground"><Download className="h-3 w-3" /> {action.module ?? "Recording"}</span>}
          footer={<><GhostBtn onClick={close}>Close</GhostBtn>
            <PrimaryBtn onClick={() => { pushToast("Recording saved to your device"); close(); }}>Download 720p</PrimaryBtn></>}
        >
          <p className="text-sm">{action.topic}</p>
        </Modal>
      );

    case "upgrade-cohort":
      return (
        <Modal open={open} onClose={close} title="Add a 1:1 mentor track" tone="navy"
          eyebrow={<span className="pill-tag -rotate-2 bg-lavender/50"><Sparkles className="h-3 w-3" /> Upgrade</span>}
          footer={<><GhostBtn onClick={close}>Not now</GhostBtn>
            <PrimaryBtn onClick={() => { pushToast("Placement team will reach out in 24h"); close(); }}>Talk to placements</PrimaryBtn></>}
        >
          <ul className="space-y-2">
            {["Weekly 45-min mentor 1:1", "Priority placement queue", "Portfolio + resume review"].map((t) => (
              <li key={t} className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-[var(--accent-blue-deep)]" /> {t}</li>
            ))}
          </ul>
        </Modal>
      );

    case "reward-detail":
      return (
        <Modal open={open} onClose={close} title={action.title}
          eyebrow={<span className="pill-tag -rotate-2 bg-coral/40 text-coral-foreground"><Award className="h-3 w-3" /> Weekly reward</span>}
          footer={<PrimaryBtn onClick={close}>Got it</PrimaryBtn>}
        >
          <p className="text-sm">{action.progress}. Ship this by Sunday to unlock a 1:1 mentor slot.</p>
        </Modal>
      );

    case "save-settings":
      return (
        <Modal open={open} onClose={close} title="Preferences saved"
          eyebrow={<span className="pill-tag -rotate-2 bg-accent-blue/20 text-accent-blue-deep"><CheckCircle2 className="h-3 w-3" /> Saved</span>}
          footer={<PrimaryBtn onClick={close}>Nice</PrimaryBtn>}
        >
          <p>You'll only get pings you actually asked for.</p>
        </Modal>
      );

    case "change-password":
      return (
        <PasswordForm open={open} close={close} />
      );
  }
}

function SubmitForm({ open, close, title, module: mod, isRepo }: { open: boolean; close: () => void; title: string; module: string; isRepo: boolean }) {
  const [val, setVal] = useState("");
  return (
    <Modal open={open} onClose={close} title={title}
      eyebrow={<span className="pill-tag -rotate-2 bg-accent-blue/20 text-accent-blue-deep">{mod}</span>}
      footer={<>
        <GhostBtn onClick={close}>Cancel</GhostBtn>
        <PrimaryBtn onClick={() => { if (!val.trim()) { pushToast("Add your submission first"); return; } pushToast("Submitted — mentor review in ~48h"); close(); }}>
          <Upload className="h-4 w-4" /> Submit
        </PrimaryBtn>
      </>}
    >
      {isRepo ? (
        <label className="block">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 flex items-center gap-1"><Github className="h-3.5 w-3.5" /> GitHub repo URL</span>
          <input value={val} onChange={(e) => setVal(e.target.value)} placeholder="https://github.com/you/mini-rag" className="mt-1 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[var(--accent-blue-deep)]" />
        </label>
      ) : (
        <label className="block">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 flex items-center gap-1"><FileText className="h-3.5 w-3.5" /> Upload file</span>
          <div className="mt-1 grid place-items-center rounded-2xl border-2 border-dashed border-slate-200 p-8 text-center">
            <input type="file" onChange={(e) => setVal(e.target.files?.[0]?.name ?? "")} className="hidden" id="tek-upload" />
            <label htmlFor="tek-upload" className="cursor-pointer text-sm font-semibold text-[var(--accent-blue-deep)]">Choose a file</label>
            {val && <p className="mt-2 text-xs text-slate-500">{val}</p>}
          </div>
        </label>
      )}
      <textarea placeholder="Add a note for your mentor (optional)" className="mt-3 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[var(--accent-blue-deep)]" rows={3} />
    </Modal>
  );
}

function ApplyForm({ open, close, role, company, location, salary }: { open: boolean; close: () => void; role: string; company: string; location: string; salary?: string }) {
  const [resume, setResume] = useState(true);
  const [note, setNote] = useState("");
  return (
    <Modal open={open} onClose={close} title={`Apply to ${company}`}
      eyebrow={<span className="pill-tag -rotate-2 bg-coral/40 text-coral-foreground">{role}</span>}
      footer={<>
        <GhostBtn onClick={close}>Cancel</GhostBtn>
        <PrimaryBtn onClick={() => { pushToast("Application sent. Placements team notified."); close(); }}>
          <Send className="h-4 w-4" /> Send application
        </PrimaryBtn>
      </>}
    >
      <p className="text-sm">{location}{salary ? ` · ${salary}` : ""}</p>
      <label className="mt-4 flex items-center gap-2 rounded-2xl bg-slate-50 p-3 text-sm">
        <input type="checkbox" checked={resume} onChange={(e) => setResume(e.target.checked)} className="h-4 w-4 rounded" />
        Attach my latest resume (v3 — reviewed by Ananya on Mon)
      </label>
      <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Why you? Two lines is enough." rows={3} className="mt-3 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[var(--accent-blue-deep)]" />
    </Modal>
  );
}

function MessageForm({ open, close, name, role }: { open: boolean; close: () => void; name: string; role: string }) {
  const [msg, setMsg] = useState("");
  return (
    <Modal open={open} onClose={close} title={`Message ${name}`}
      eyebrow={<span className="pill-tag -rotate-2 bg-accent-blue/20 text-accent-blue-deep"><MessageCircle className="h-3 w-3" /> {role}</span>}
      footer={<>
        <GhostBtn onClick={close}>Cancel</GhostBtn>
        <PrimaryBtn onClick={() => { if (!msg.trim()) return; pushToast(`Message sent to ${name}`); close(); }}>
          <Send className="h-4 w-4" /> Send
        </PrimaryBtn>
      </>}
    >
      <textarea autoFocus value={msg} onChange={(e) => setMsg(e.target.value)} rows={4} placeholder="Hey — I'm stuck on the LoRA notebook, mind a quick look?" className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[var(--accent-blue-deep)]" />
    </Modal>
  );
}

function PasswordForm({ open, close }: { open: boolean; close: () => void }) {
  return (
    <Modal open={open} onClose={close} title="Change password"
      eyebrow={<span className="pill-tag -rotate-2 bg-lavender/50">Security</span>}
      footer={<>
        <GhostBtn onClick={close}>Cancel</GhostBtn>
        <PrimaryBtn onClick={() => { pushToast("Password updated"); close(); }}>Update password</PrimaryBtn>
      </>}
    >
      <div className="grid gap-3">
        <input type="password" placeholder="Current password" className="rounded-2xl border border-slate-200 px-4 py-3 text-sm" />
        <input type="password" placeholder="New password" className="rounded-2xl border border-slate-200 px-4 py-3 text-sm" />
        <input type="password" placeholder="Confirm new password" className="rounded-2xl border border-slate-200 px-4 py-3 text-sm" />
      </div>
    </Modal>
  );
}

function FeedbackForm({ open, close, title, grade, feedback, mentor }: { open: boolean; close: () => void; title: string; grade?: string; feedback?: string; mentor: string }) {
  const [reply, setReply] = useState("");
  const [thread, setThread] = useState<{ from: "mentor" | "you"; text: string }[]>([
    { from: "mentor", text: feedback ?? "Solid submission — a few notes on structure and next steps." },
  ]);
  return (
    <Modal open={open} onClose={close} title="Mentor feedback" tone="lavender" size="lg"
      eyebrow={<span className="pill-tag -rotate-2 bg-lavender/50">{title}{grade ? ` · Grade ${grade}` : ""}</span>}
      footer={<>
        <GhostBtn onClick={close}>Close</GhostBtn>
        <PrimaryBtn onClick={() => {
          if (!reply.trim()) { pushToast("Type a reply first"); return; }
          setThread((t) => [...t, { from: "you", text: reply }, { from: "mentor", text: `Got it — I'll take another look after your next commit. Ping me on #help-ai-engineering if you get stuck. — ${mentor.split(" ")[0]}` }]);
          pushToast(`Reply sent to ${mentor}`);
          setReply("");
        }}><Send className="h-4 w-4" /> Send reply</PrimaryBtn>
      </>}
    >
      <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
        {thread.map((m, i) => (
          <div key={i} className={`flex gap-2.5 ${m.from === "you" ? "flex-row-reverse" : ""}`}>
            <div className={`grid h-8 w-8 shrink-0 place-items-center rounded-full text-xs font-bold ${m.from === "you" ? "bg-[var(--accent-blue-deep)] text-white" : "bg-lavender/60"}`}>
              {m.from === "you" ? "YU" : mentor.split(" ").map((n) => n[0]).join("").slice(0, 2)}
            </div>
            <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${m.from === "you" ? "bg-[var(--accent-blue-deep)] text-white" : "bg-slate-50 text-slate-700"}`}>
              <p className="text-[10px] font-semibold uppercase tracking-wider opacity-70 mb-0.5">{m.from === "you" ? "You" : mentor}</p>
              {m.text}
            </div>
          </div>
        ))}
      </div>
      <textarea
        value={reply}
        onChange={(e) => setReply(e.target.value)}
        rows={3}
        placeholder={`Reply to ${mentor}…`}
        className="mt-4 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[var(--accent-blue-deep)]"
      />
    </Modal>
  );
}

function ToastStack() {
  const list = useToasts();
  if (typeof document === "undefined" || list.length === 0) return null;
  return (
    <div className="pointer-events-none fixed bottom-6 left-1/2 z-[110] flex -translate-x-1/2 flex-col items-center gap-2">
      {list.map((t) => (
        <div key={t.id} className="pointer-events-auto flex items-center gap-2 rounded-full bg-[#1E1B4B] px-4 py-2.5 text-sm font-medium text-white shadow-xl motion-safe:animate-[fade-in_.2s_ease-out]">
          <Bell className="h-3.5 w-3.5 text-[#F4A261]" /> {t.message}
        </div>
      ))}
    </div>
  );
}
