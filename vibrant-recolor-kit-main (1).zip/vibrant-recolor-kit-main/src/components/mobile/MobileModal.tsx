import { useEffect, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";
import { getPhoneSurface } from "./PhoneFrame";

/**
 * Bottom-sheet modal scoped to the phone frame. Portals into #phone-surface
 * so on desktop it stays inside the iPhone bezel and on mobile it fills
 * the full app viewport. Falls back to document.body if the surface hasn't
 * mounted (SSR).
 */
export function MobileModal({
  open,
  onClose,
  title,
  eyebrow,
  children,
  footer,
}: {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  eyebrow?: ReactNode;
  children?: ReactNode;
  footer?: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open || typeof document === "undefined") return null;
  const host = getPhoneSurface() ?? document.body;

  return createPortal(
    <div className="absolute inset-0 z-[80] flex items-end justify-center">
      <button
        aria-label="Close"
        onClick={onClose}
        className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm animate-[fade-in_.15s_ease-out]"
      />
      <div className="relative w-full rounded-t-[28px] bg-white p-6 pb-8 shadow-2xl animate-[slide-in-up_.22s_cubic-bezier(.2,.8,.2,1)]">
        <span className="absolute left-1/2 top-2 h-1.5 w-10 -translate-x-1/2 rounded-full bg-slate-200" />
        <button
          aria-label="Close"
          onClick={onClose}
          className="absolute right-4 top-4 grid h-8 w-8 place-items-center rounded-full bg-slate-100 text-slate-500"
        >
          <X className="h-4 w-4" />
        </button>
        {eyebrow && (
          <p className="mb-1 pr-10 text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">{eyebrow}</p>
        )}
        {title && (
          <h2 className="pr-10 font-display text-xl font-bold leading-tight text-slate-900">{title}</h2>
        )}
        {children && <div className="mt-3 text-sm text-slate-600">{children}</div>}
        {footer && <div className="mt-5 flex flex-col gap-2">{footer}</div>}
      </div>
    </div>,
    host,
  );
}

export function SheetPrimary({ children, onClick }: { children: ReactNode; onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-[#1E1B4B] py-3.5 text-sm font-bold text-white active:scale-[0.98]"
    >
      {children}
    </button>
  );
}
export function SheetGhost({ children, onClick }: { children: ReactNode; onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      className="inline-flex w-full items-center justify-center gap-2 rounded-full border border-slate-200 bg-white py-3 text-sm font-semibold text-slate-700"
    >
      {children}
    </button>
  );
}
