import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { Bell, Flame, Trophy, Video, FileText, Sparkles, X } from "lucide-react";
import { useSession, markReturning } from "@/lib/auth";
import { CLASSES, ASSIGNMENTS, GAMIFICATION } from "@/lib/dashboard-data";
import { getPhoneSurface } from "./PhoneFrame";

type Nudge = {
  id: string;
  icon: React.ComponentType<{ className?: string }>;
  tone: "navy" | "peach" | "sky" | "green";
  title: string;
  body: string;
  cta?: { label: string; to?: string };
};

function buildNudges(name: string, firstTime: boolean): Nudge[] {
  const nextClass = CLASSES.filter((c) => c.status === "upcoming").sort((a, b) => a.date.localeCompare(b.date))[0];
  const dueSoon = ASSIGNMENTS.filter((a) => a.status === "due").sort((a, b) => a.dueDate.localeCompare(b.dueDate))[0];

  const list: Nudge[] = [];
  if (firstTime) {
    list.push({
      id: "welcome",
      icon: Sparkles,
      tone: "navy",
      title: `Welcome, ${name.split(" ")[0]} 👋`,
      body: "You're in the March '26 AI Engineering cohort. Let's ship something today.",
    });
  } else {
    list.push({
      id: "welcome-back",
      icon: Sparkles,
      tone: "navy",
      title: `Welcome back, ${name.split(" ")[0]}`,
      body: `${GAMIFICATION.streak}-day streak alive. Keep it going.`,
    });
  }
  if (nextClass) {
    const mins = Math.max(0, Math.round((new Date(nextClass.date).getTime() - Date.now()) / 60000));
    list.push({
      id: "class-soon",
      icon: Video,
      tone: "sky",
      title: mins < 60 ? `Class begins in ${mins} min` : "Your next class is today",
      body: `${nextClass.topic.split(" — ")[0]} · with ${nextClass.instructor}`,
      cta: { label: "Join room", to: `/app/class/${nextClass.id}` },
    });
  }
  if (dueSoon) {
    list.push({
      id: "assignment",
      icon: FileText,
      tone: "peach",
      title: "Assignment pending",
      body: dueSoon.title,
      cta: { label: "Open task", to: `/app/task/${dueSoon.id}` },
    });
  }
  list.push({
    id: "leaderboard",
    icon: Trophy,
    tone: "green",
    title: "You're #4 this week",
    body: "Only 210 XP to overtake Arjun N. Don't get left behind.",
    cta: { label: "See leaderboard", to: "/app/leaderboard" },
  });
  list.push({
    id: "streak",
    icon: Flame,
    tone: "peach",
    title: `${GAMIFICATION.streak}-day streak 🔥`,
    body: "Finish today's daily challenge to keep it alive.",
    cta: { label: "Take challenge", to: "/app/challenge" },
  });
  return list;
}

const toneClasses: Record<Nudge["tone"], string> = {
  navy: "bg-[#1E1B4B] text-white",
  peach: "bg-[#FCE5D0] text-[#7A3A0F]",
  sky: "bg-[#DCEBFA] text-[#1F4E8A]",
  green: "bg-[#DEF2E4] text-[#1E5B33]",
};

export function NudgeStack() {
  const session = useSession();
  const [idx, setIdx] = useState(0);
  const [dismissed, setDismissed] = useState<string[]>([]);
  const [nudges, setNudges] = useState<Nudge[]>([]);

  useEffect(() => {
    if (!session) return;
    setNudges(buildNudges(session.name, session.isFirstTime));
    if (session.isFirstTime) markReturning();
  }, [session]);

  useEffect(() => {
    if (nudges.length === 0) return;
    const t = setInterval(() => setIdx((i) => (i + 1) % nudges.length), 5500);
    return () => clearInterval(t);
  }, [nudges.length]);

  if (typeof document === "undefined" || !session || nudges.length === 0) return null;
  const active = nudges.filter((n) => !dismissed.includes(n.id));
  if (active.length === 0) return null;
  const n = active[idx % active.length];
  const Icon = n.icon;
  const host = getPhoneSurface() ?? document.body;

  return createPortal(
    <div className="pointer-events-none absolute inset-x-3 top-[76px] z-[60] flex justify-center">
      <div
        key={n.id}
        className={`pointer-events-auto flex w-full max-w-[400px] items-start gap-3 rounded-2xl p-3.5 shadow-[0_18px_40px_-18px_rgba(15,23,42,0.4)] animate-[slide-in-down_.35s_cubic-bezier(.2,.8,.2,1)] ${toneClasses[n.tone]}`}
      >
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white/25">
          <Icon className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-bold leading-tight">{n.title}</p>
          <p className="mt-0.5 line-clamp-2 text-xs opacity-90">{n.body}</p>
          {n.cta && (
            <a
              href={n.cta.to}
              className="mt-2 inline-flex items-center gap-1 rounded-full bg-white/90 px-3 py-1 text-[11px] font-bold text-slate-900"
            >
              {n.cta.label}
            </a>
          )}
        </div>
        <button
          aria-label="Dismiss"
          onClick={() => setDismissed((d) => [...d, n.id])}
          className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-white/20"
        >
          <X className="h-3 w-3" />
        </button>
      </div>
    </div>,
    host,
  );
}

/** Small floating toast — used for CTA feedback ("Submitted", "Joined", etc.). */
export function Toast({ show, message, icon: Icon = Bell }: { show: boolean; message: string; icon?: React.ComponentType<{ className?: string }> }) {
  if (typeof document === "undefined" || !show) return null;
  const host = getPhoneSurface() ?? document.body;
  return createPortal(
    <div className="pointer-events-none absolute inset-x-0 bottom-28 z-[90] flex justify-center px-6">
      <div className="pointer-events-auto flex items-center gap-2 rounded-full bg-slate-900 px-4 py-2.5 text-xs font-semibold text-white shadow-2xl animate-[slide-in-up_.25s_cubic-bezier(.2,.8,.2,1)]">
        <Icon className="h-3.5 w-3.5" /> {message}
      </div>
    </div>,
    host,
  );
}
