import { Link, useRouterState } from "@tanstack/react-router";
import { Home, GraduationCap, ListChecks, Users, User, Search, Bell } from "lucide-react";
import { useState, type ReactNode } from "react";
import { useSession } from "@/lib/auth";
import { PhoneFrame } from "./PhoneFrame";
import { NudgeStack } from "./Nudges";
import { MobileModal } from "./MobileModal";
import tekschoolLogo from "@/assets/tekschool-logo.png.asset.json";

export function AppShell({ children, showHeader = true, title }: { children: ReactNode; showHeader?: boolean; title?: string }) {
  return (
    <PhoneFrame>
      <div className="relative flex h-full min-h-0 flex-col overflow-hidden bg-[#F5F5F7]">
        {showHeader && <AppHeader title={title} />}
        <main className="min-h-0 flex-1 overflow-y-auto pb-28 scroll-smooth [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">{children}</main>
        <BottomTabs />
        <NudgeStack />
      </div>
    </PhoneFrame>
  );
}

function AppHeader({ title }: { title?: string }) {
  const [openSearch, setOpenSearch] = useState(false);
  const [openBell, setOpenBell] = useState(false);
  return (
    <>
      <header className="relative z-30 shrink-0 bg-[#1E1B4B] px-5 pb-4 pt-14 text-white shadow-[0_10px_22px_-18px_rgba(15,23,42,0.55)]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {title ? (
              <>
                <span className="inline-flex h-8 items-center rounded-lg bg-white px-2">
                  <img src={tekschoolLogo.url} alt="TekSchool" className="h-4 w-auto" />
                </span>
                <span className="font-display text-lg font-bold">{title}</span>
              </>
            ) : (
              <span className="inline-flex h-9 items-center rounded-xl bg-white px-2.5">
                <img src={tekschoolLogo.url} alt="TekSchool" className="h-5 w-auto" />
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setOpenSearch(true)} aria-label="Search" className="grid h-9 w-9 place-items-center rounded-full bg-white/10 backdrop-blur active:scale-95"><Search className="h-4 w-4" /></button>
            <button onClick={() => setOpenBell(true)} aria-label="Notifications" className="relative grid h-9 w-9 place-items-center rounded-full bg-white/10 backdrop-blur active:scale-95">
              <Bell className="h-4 w-4" />
              <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-[#F4A261] ring-2 ring-[#1E1B4B]" />
            </button>
          </div>
        </div>
      </header>

      <MobileModal open={openSearch} onClose={() => setOpenSearch(false)} eyebrow="Search" title="Find anything">
        <div className="flex items-center gap-2 rounded-2xl bg-slate-100 px-4 py-3">
          <Search className="h-4 w-4 text-slate-400" />
          <input autoFocus placeholder="Classes, tasks, mentors…" className="w-full bg-transparent text-sm focus:outline-none" />
        </div>
        <div className="mt-4 space-y-2 text-xs text-slate-500">
          <p className="font-bold uppercase tracking-[0.14em]">Try</p>
          {["RAG assignment", "Ananya Rao", "Attention math", "Leaderboard"].map((s) => (
            <button key={s} className="block w-full rounded-xl bg-slate-50 px-3 py-2 text-left text-sm font-semibold text-slate-700">{s}</button>
          ))}
        </div>
      </MobileModal>

      <MobileModal open={openBell} onClose={() => setOpenBell(false)} eyebrow="Notifications" title="What's new">
        <div className="space-y-2">
          {[
            { t: "Applied AI class starts in 12 min", s: "with Ananya Rao · Zoom link ready", tone: "bg-[#DCEBFA]" },
            { t: "Assignment due tomorrow", s: "Build a mini RAG over 500 arXiv abstracts", tone: "bg-[#FCE5D0]" },
            { t: "Ananya kudos'd your W&B write-up", s: "+30 XP · 2h ago", tone: "bg-[#DEF2E4]" },
            { t: "Leaderboard update", s: "You moved up 2 spots this week", tone: "bg-slate-100" },
          ].map((n) => (
            <div key={n.t} className={`rounded-2xl p-3 ${n.tone}`}>
              <p className="text-sm font-bold text-slate-900">{n.t}</p>
              <p className="text-xs text-slate-600">{n.s}</p>
            </div>
          ))}
        </div>
      </MobileModal>
    </>
  );
}

const TABS = [
  { to: "/app", label: "Home", icon: Home, exact: true },
  { to: "/app/classes", label: "Classes", icon: GraduationCap },
  { to: "/app/tasks", label: "Tasks", icon: ListChecks },
  { to: "/app/cohort", label: "Cohort", icon: Users },
  { to: "/app/you", label: "You", icon: User },
] as { to: string; label: string; icon: typeof Home; exact?: boolean }[];

function BottomTabs() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className="absolute bottom-0 left-0 right-0 z-40 bg-white/95 px-3 pb-3 pt-2 backdrop-blur shadow-[0_-8px_24px_-12px_rgba(15,23,42,0.12)]">
      <ul className="flex items-center justify-between">
        {TABS.map((t) => {
          const active = t.exact ? pathname === t.to : pathname.startsWith(t.to);
          const Icon = t.icon;
          return (
            <li key={t.to} className="flex-1">
              <Link to={t.to as "/app"} className="flex flex-col items-center gap-1 py-1">
                <span className={`grid h-9 w-9 place-items-center rounded-full transition-all ${active ? "bg-[#1E1B4B] text-white scale-105" : "text-slate-400"}`}>
                  <Icon className="h-4.5 w-4.5" strokeWidth={2.2} />
                </span>
                <span className={`text-[10px] font-semibold ${active ? "text-[#1E1B4B]" : "text-slate-400"}`}>{t.label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

export function Greeting() {
  const session = useSession();
  const name = session?.name ?? "Aditi Sharma";
  const initials = (session?.avatarInitials) || name.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase();
  const hour = new Date().getHours();
  const timeOfDay = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  return (
    <div className="flex items-center gap-3 px-5 pt-5">
      <div className="grid h-12 w-12 place-items-center rounded-full bg-[#E8E0F5] text-sm font-bold text-[#5B3E9B]">{initials}</div>
      <div>
        <p className="text-xs text-slate-500">{timeOfDay}</p>
        <p className="font-display text-lg font-bold text-slate-900">{name}</p>
      </div>
    </div>
  );
}

/* -------- Reusable card patterns -------- */

export function NavyCard({ eyebrow, title, subtitle, action, live }: { eyebrow: string; title: string; subtitle?: string; action?: ReactNode; live?: boolean }) {
  return (
    <div className="relative overflow-hidden rounded-3xl bg-[#1E1B4B] p-5 text-white">
      <div className="pointer-events-none absolute -bottom-16 -right-16 h-48 w-48 rounded-full bg-gradient-to-br from-[#2D5FA8]/40 to-transparent blur-2xl" />
      <div className="pointer-events-none absolute -bottom-10 -right-10 h-32 w-32 rounded-full border border-white/5" />
      <div className="relative">
        <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.14em] text-white/80">
          {live && <span className="h-1.5 w-1.5 rounded-full bg-[#F4A261]" />}
          {eyebrow}
        </p>
        <h3 className="mt-2 font-display text-xl font-bold leading-tight">{title}</h3>
        {subtitle && <p className="mt-1 text-sm text-white/70">{subtitle}</p>}
        {action && <div className="mt-4 flex justify-end">{action}</div>}
      </div>
    </div>
  );
}

export function WhiteTaskCard({ icon, eyebrow, title, progress, caption, onClick }: { icon: ReactNode; eyebrow: string; title: string; progress: number; caption: string; onClick?: () => void }) {
  return (
    <button onClick={onClick} className="w-full rounded-3xl bg-white p-5 text-left shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)]">
      <div className="flex items-center gap-2">
        <span className="grid h-6 w-6 place-items-center rounded-lg bg-slate-100 text-slate-500">{icon}</span>
        <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">{eyebrow}</p>
      </div>
      <h3 className="mt-2 font-display text-base font-bold leading-snug text-slate-900">{title}</h3>
      <div className="mt-3 h-1.5 rounded-full bg-slate-100">
        <div className="h-full rounded-full bg-[#1E1B4B]" style={{ width: `${Math.max(2, progress)}%` }} />
      </div>
      <p className="mt-2 text-[11px] text-slate-500">{caption}</p>
    </button>
  );
}

export function PastelStat({ tone, label, icon, value, unit }: { tone: "peach" | "sky"; label: string; icon: ReactNode; value: string | number; unit?: string }) {
  const cls = tone === "peach" ? "bg-[#FCE5D0] text-[#B45613]" : "bg-[#DCEBFA] text-[#1F4E8A]";
  return (
    <div className={`flex-1 rounded-3xl p-4 ${tone === "peach" ? "bg-[#FCE5D0]" : "bg-[#DCEBFA]"}`}>
      <div className="flex items-center gap-1.5">
        <span className={cls.split(" ")[1]}>{icon}</span>
        <p className={`text-[10px] font-bold uppercase tracking-[0.14em] ${tone === "peach" ? "text-[#B45613]" : "text-[#1F4E8A]"}`}>{label}</p>
      </div>
      <p className="mt-2 font-display text-3xl font-black text-slate-900 tabular-nums">
        {value}
        {unit && <span className="ml-1 text-base font-bold text-slate-600">{unit}</span>}
      </p>
    </div>
  );
}

export function SectionTitle({ title, action }: { title: string; action?: ReactNode }) {
  return (
    <div className="mb-3 flex items-center justify-between px-5">
      <h2 className="font-display text-base font-bold text-slate-900">{title}</h2>
      {action}
    </div>
  );
}
