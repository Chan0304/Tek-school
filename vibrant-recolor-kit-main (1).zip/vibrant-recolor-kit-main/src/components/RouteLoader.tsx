import { useEffect, useRef, useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { LogoLockup } from "./Logo";

const MIN_VISIBLE = 700; // ms the loader stays up, so pages never flash
const FADE = 320;

/**
 * Tek School logo loader — covers the viewport the moment a navigation
 * starts (including the very first click), then fades out once the new
 * route has rendered. Prevents the half-painted page glitch.
 */
export function RouteLoader() {
  const router = useRouter();
  const [visible, setVisible] = useState(false);
  const [leaving, setLeaving] = useState(false);
  const shownAt = useRef(0);
  const timers = useRef<number[]>([]);

  const clearTimers = () => {
    timers.current.forEach((t) => window.clearTimeout(t));
    timers.current = [];
  };

  useEffect(() => {
    const show = () => {
      clearTimers();
      shownAt.current = Date.now();
      setLeaving(false);
      setVisible(true);
    };

    const hide = () => {
      const elapsed = Date.now() - shownAt.current;
      const wait = Math.max(0, MIN_VISIBLE - elapsed);
      clearTimers();
      timers.current.push(
        window.setTimeout(() => setLeaving(true), wait),
        window.setTimeout(() => setVisible(false), wait + FADE),
      );
    };

    const unsubStart = router.subscribe("onBeforeNavigate", ({ pathChanged }) => {
      if (pathChanged) show();
    });
    const unsubEnd = router.subscribe("onResolved", ({ pathChanged }) => {
      if (pathChanged) hide();
    });

    return () => {
      unsubStart();
      unsubEnd();
      clearTimers();
    };
  }, [router]);

  if (!visible) return null;

  return (
    <div
      aria-hidden
      className="pointer-events-auto fixed inset-0 z-[200] grid place-items-center overflow-hidden bg-background"
      style={{
        opacity: leaving ? 0 : 1,
        transition: `opacity ${FADE}ms var(--ease-out-soft)`,
      }}
    >
      <div className="absolute -top-24 left-1/2 h-[26rem] w-[26rem] -translate-x-1/2 rounded-full bg-[color-mix(in_oklab,var(--accent-blue)_18%,transparent)] blur-3xl" />
      <div className="absolute -bottom-28 right-[12%] h-72 w-72 rounded-full bg-[color-mix(in_oklab,var(--coral)_16%,transparent)] blur-3xl" />

      <div className="relative flex flex-col items-center gap-6">
        <div className="motion-safe:animate-[tek-loader-pop_640ms_cubic-bezier(0.22,1,0.36,1)_both]">
          <LogoLockup className="h-12" />
        </div>
        <div className="h-1 w-40 overflow-hidden rounded-full bg-[color-mix(in_oklab,var(--primary)_10%,transparent)]">
          <div className="h-full w-1/3 rounded-full gradient-blue motion-safe:animate-[tek-loader-sweep_900ms_var(--ease-in-out)_infinite]" />
        </div>
      </div>
    </div>
  );
}
