import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Modal, PrimaryBtn, GhostBtn } from "./Modal";
import { useSession } from "@/lib/auth";
import { CLASSES, ASSIGNMENTS, APPLICATIONS, formatDate, relativeDay } from "@/lib/dashboard-data";
import { Video, ClipboardList, Briefcase, Sparkles } from "lucide-react";

const KEY = "tek-welcome-shown";

export function WelcomeBriefing() {
  const session = useSession();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!session) return;
    if (typeof window === "undefined") return;
    if (sessionStorage.getItem(KEY)) return;
    const t = setTimeout(() => {
      sessionStorage.setItem(KEY, "1");
      setOpen(true);
    }, 700);
    return () => clearTimeout(t);
  }, [session]);

  if (!session) return null;

  const nextClass = CLASSES.filter((c) => c.status === "upcoming").sort((a, b) => a.date.localeCompare(b.date))[0];
  const nextDue = ASSIGNMENTS.filter((a) => a.status === "due").sort((a, b) => a.dueDate.localeCompare(b.dueDate))[0];
  const activeApp = APPLICATIONS.find((a) => a.stage === "Interview" || a.stage === "Offer");

  return (
    <Modal
      open={open}
      onClose={() => setOpen(false)}
      tone="navy"
      size="lg"
      eyebrow={<span className="pill-tag -rotate-2 bg-coral/40 text-coral-foreground"><Sparkles className="h-3 w-3" /> Your week at a glance</span>}
      title={`Welcome back, ${session.name.split(" ")[0]} — here's what's coming up`}
      footer={<>
        <GhostBtn onClick={() => setOpen(false)}>Later</GhostBtn>
        <PrimaryBtn onClick={() => { setOpen(false); navigate({ to: "/dashboard/classes" }); }}>Take me there</PrimaryBtn>
      </>}
    >
      <div className="grid gap-3 sm:grid-cols-3">
        {nextClass && (
          <Card icon={Video} tone="bg-accent-blue/15 text-[var(--accent-blue-deep)]" label="Next live class"
            title={nextClass.topic} sub={`${formatDate(nextClass.date)} · ${nextClass.instructor}`} />
        )}
        {nextDue && (
          <Card icon={ClipboardList} tone="bg-coral/25 text-coral-foreground" label="Assignment due"
            title={nextDue.title} sub={`${relativeDay(nextDue.dueDate)} · ${nextDue.module}`} />
        )}
        {activeApp && (
          <Card icon={Briefcase} tone="bg-lavender/60" label="Placement update"
            title={`${activeApp.company} — ${activeApp.stage}`} sub={`${activeApp.role} · ${activeApp.lastUpdate}`} />
        )}
      </div>
      <p className="mt-4 text-xs text-slate-500">Streak: {session.streak} days · Week {session.weekCurrent} of {session.weekTotal}. Keep shipping.</p>
    </Modal>
  );
}

function Card({ icon: Icon, tone, label, title, sub }: { icon: typeof Video; tone: string; label: string; title: string; sub: string }) {
  return (
    <div className="rounded-2xl border border-slate-100 bg-white p-4">
      <span className={`inline-flex h-9 w-9 items-center justify-center rounded-xl ${tone}`}><Icon className="h-4 w-4" /></span>
      <p className="mt-3 text-[10px] font-semibold uppercase tracking-wider text-slate-400">{label}</p>
      <p className="mt-1 text-sm font-semibold leading-snug text-foreground line-clamp-2">{title}</p>
      <p className="mt-1 text-xs text-slate-500">{sub}</p>
    </div>
  );
}
