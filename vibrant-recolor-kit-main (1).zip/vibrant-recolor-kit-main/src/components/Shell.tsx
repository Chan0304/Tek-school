import type { ReactNode } from "react";
import { TopNav } from "./TopNav";
import { Footer } from "./Footer";
import { ChatAssistant } from "./ChatAssistant";
import { CustomCursor } from "./CustomCursor";
import { SignInPanel } from "./SignInPanel";
import { SeasonalPopup } from "./SeasonalPopup";
import { SplashScreen } from "./SplashScreen";
import { RouteTransition } from "./RouteTransition";



export function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background">
      <SplashScreen />
      <div className="mx-auto w-full max-w-[1400px]">
        <TopNav />
        <main><RouteTransition>{children}</RouteTransition></main>
        <Footer />
      </div>
      <ChatAssistant />
      <CustomCursor />
      <SignInPanel />
      <SeasonalPopup />
    </div>
  );
}


