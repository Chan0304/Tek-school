import { useEffect, useRef, useState } from "react";

const KEY = "tek-splash-shown";
const DISPLAY_MS = 1200;

export function SplashScreen() {
  const [hidden, setHidden] = useState(false);
  const [out, setOut] = useState(false);
  const timers = useRef<number[]>([]);

  useEffect(() => {
    if (sessionStorage.getItem(KEY) === "1") {
      setHidden(true);
      return;
    }
    sessionStorage.setItem(KEY, "1");

    timers.current = [
      window.setTimeout(() => setOut(true), DISPLAY_MS),
      window.setTimeout(() => setHidden(true), DISPLAY_MS + 500),
    ];

    return () => {
      timers.current.forEach(clearTimeout);
    };
  }, []);

  if (hidden) return null;

  return (
    <div
      aria-hidden={out}
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center bg-background transition-opacity duration-500 ease-out ${
        out ? "pointer-events-none opacity-0" : "opacity-100"
      }`}
    >
      <div className="h-12 w-12 rounded-full border-[3px] border-primary/15 border-t-primary animate-spin" />
    </div>
  );
}
