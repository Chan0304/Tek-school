// Reusable confirm dialog with intent (destructive/default). Uses Modal.
import type { ReactNode } from "react";
import { Modal, PrimaryBtn, GhostBtn } from "@/components/Modal";
import { AlertTriangle } from "lucide-react";

export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  message,
  confirmLabel = "Confirm",
  cancelLabel = "Cancel",
  destructive = false,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  destructive?: boolean;
}) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      tone={destructive ? "coral" : "default"}
      eyebrow={destructive ? (
        <span className="pill-tag -rotate-2 bg-coral/20 text-coral">
          <AlertTriangle className="h-3 w-3" /> Destructive
        </span>
      ) : undefined}
      title={title}
      footer={
        <>
          <GhostBtn onClick={onClose}>{cancelLabel}</GhostBtn>
          {destructive ? (
            <button
              onClick={() => { onConfirm(); onClose(); }}
              className="inline-flex items-center gap-1.5 rounded-full bg-coral px-5 py-2.5 text-sm font-semibold text-coral-foreground shadow-[0_10px_25px_-12px_var(--coral)] hover:opacity-95"
            >
              {confirmLabel}
            </button>
          ) : (
            <PrimaryBtn onClick={() => { onConfirm(); onClose(); }}>{confirmLabel}</PrimaryBtn>
          )}
        </>
      }
    >
      {typeof message === "string" ? <p>{message}</p> : message}
    </Modal>
  );
}
