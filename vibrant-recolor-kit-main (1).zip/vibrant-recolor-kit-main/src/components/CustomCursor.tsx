import { useEffect, useRef, useState } from "react";

/**
 * Site-wide custom cursor.
 * - Two-layer cursor: a small dot that tracks tightly, and a fluid outer ring
 *   that trails slightly behind for a "super smooth" feel.
 * - Spring scale on hover over interactive elements.
 * - Stays small at all times; a brief ripple ring pings on click.
 * - Hides on touch/coarse-pointer devices via feature detection.
 */
export function CustomCursor() {
  const [enabled, setEnabled] = useState(false);
  const [visible, setVisible] = useState(false);
  const [pulse, setPulse] = useState(0);
  const [hovered, setHovered] = useState(false);
  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const target = useRef({ x: 0, y: 0 });
  const dotPos = useRef({ x: 0, y: 0 });
  const ringPos = useRef({ x: 0, y: 0 });
  const raf = useRef<number | null>(null);
  const pulseTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastEnter = useRef<HTMLElement | null>(null);

  const INTERACTIVE_SELECTOR =
    "[data-cursor], a, button, [role='button'], input, textarea, select, label[for], summary, .tek-interactive";

  function triggerPulse() {
    if (pulseTimer.current) clearTimeout(pulseTimer.current);
    setPulse((p) => p + 1);
    pulseTimer.current = setTimeout(() => setPulse(0), 420);
  }

  // Feature-detect: only enable on fine pointer, no coarse touch.
  useEffect(() => {
    if (typeof window === "undefined") return;
    const fine = window.matchMedia("(pointer: fine)").matches;
    const coarse = window.matchMedia("(pointer: coarse)").matches;
    const hasTouch =
      "ontouchstart" in window || (navigator.maxTouchPoints ?? 0) > 0;
    setEnabled(fine && !coarse && !hasTouch);
  }, []);

  useEffect(() => {
    if (!enabled) return;
    document.documentElement.classList.add("tek-cursor-on");
    let seen = false;

    const onMove = (e: MouseEvent) => {
      target.current.x = e.clientX;
      target.current.y = e.clientY;
      if (!seen) {
        seen = true;
        // snap both layers on first sighting so they don't fly in from the corner
        dotPos.current.x = e.clientX;
        dotPos.current.y = e.clientY;
        ringPos.current.x = e.clientX;
        ringPos.current.y = e.clientY;
        setVisible(true);
      }
    };

    const onDown = (e: MouseEvent) => {
      const el = e.target as HTMLElement | null;
      if (!el) return;
      if (el.closest<HTMLElement>(INTERACTIVE_SELECTOR)) triggerPulse();
    };

    const onLeave = () => setVisible(false);
    const onEnter = () => setVisible(true);

    const onOver = (e: MouseEvent) => {
      const el = e.target as HTMLElement | null;
      if (!el) return;
      const hit = el.closest<HTMLElement>(INTERACTIVE_SELECTOR);
      if (hit && hit !== lastEnter.current) {
        lastEnter.current = hit;
        setHovered(true);
      }
    };

    const onOut = (e: MouseEvent) => {
      const el = e.target as HTMLElement | null;
      if (!el) return;
      const hit = el.closest<HTMLElement>(INTERACTIVE_SELECTOR);
      if (hit && hit === lastEnter.current) {
        lastEnter.current = null;
        setHovered(false);
      }
    };

    window.addEventListener("mousemove", onMove, { passive: true });
    window.addEventListener("mousedown", onDown, { passive: true });
    document.addEventListener("mouseleave", onLeave);
    document.addEventListener("mouseenter", onEnter);
    document.addEventListener("mouseover", onOver, { passive: true });
    document.addEventListener("mouseout", onOut, { passive: true });

    let last = performance.now();
    const tick = (now: number) => {
      const dt = Math.min(now - last, 50);
      last = now;
      const t = target.current;

      // Dot: tight, almost 1:1 follow (~22ms time constant)
      const kDot = 1 - Math.exp(-dt / 22);
      dotPos.current.x += (t.x - dotPos.current.x) * kDot;
      dotPos.current.y += (t.y - dotPos.current.y) * kDot;

      // Ring: trailing, fluid follow (~110ms time constant)
      const kRing = 1 - Math.exp(-dt / 110);
      ringPos.current.x += (t.x - ringPos.current.x) * kRing;
      ringPos.current.y += (t.y - ringPos.current.y) * kRing;

      const dot = dotRef.current;
      const ring = ringRef.current;
      if (dot) {
        dot.style.transform = `translate3d(${dotPos.current.x.toFixed(2)}px, ${dotPos.current.y.toFixed(2)}px, 0) translate(-50%, -50%)`;
      }
      if (ring) {
        ring.style.transform = `translate3d(${ringPos.current.x.toFixed(2)}px, ${ringPos.current.y.toFixed(2)}px, 0) translate(-50%, -50%)`;
      }
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);

    return () => {
      document.documentElement.classList.remove("tek-cursor-on");
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mousedown", onDown);
      document.removeEventListener("mouseleave", onLeave);
      document.removeEventListener("mouseenter", onEnter);
      document.removeEventListener("mouseover", onOver);
      document.removeEventListener("mouseout", onOut);
      if (raf.current) cancelAnimationFrame(raf.current);
      if (pulseTimer.current) clearTimeout(pulseTimer.current);
    };
  }, [enabled]);

  if (!enabled) return null;

  return (
    <>
      <style>{`
        html.tek-cursor-on, html.tek-cursor-on * { cursor: none !important; }
        @keyframes tek-cur-pulse {
          0% { transform: scale(0.85); opacity: 0.55; }
          60% { opacity: 0.18; }
          100% { transform: scale(1.9); opacity: 0; }
        }
      `}</style>
      {/* Trailing fluid ring */}
      <div
        ref={ringRef}
        aria-hidden
        className="pointer-events-none fixed left-0 top-0 z-[9998]"
        style={{
          opacity: visible ? (hovered ? 0.45 : 0.25) : 0,
          transition: "opacity 260ms ease, width 260ms ease, height 260ms ease",
          willChange: "transform",
        }}
      >
        <div
          className="rounded-full border border-[color:var(--primary)]"
          style={{
            width: hovered ? 52 : 40,
            height: hovered ? 52 : 40,
            transition: "width 260ms cubic-bezier(.34,1.56,.64,1), height 260ms cubic-bezier(.34,1.56,.64,1)",
          }}
        />
      </div>

      {/* Main dot */}
      <div
        ref={dotRef}
        aria-hidden
        className="pointer-events-none fixed left-0 top-0 z-[9999]"
        style={{
          opacity: visible ? 1 : 0,
          transition: "opacity 200ms ease",
          willChange: "transform",
        }}
      >
        <div className="relative grid place-items-center">
          {/* click ripple ring */}
          {pulse > 0 && (
            <span
              aria-hidden
              className="absolute rounded-full border-[2px] border-[color:var(--primary)]"
              style={{
                width: 28,
                height: 28,
                animation:
                  "tek-cur-pulse 420ms cubic-bezier(.34,1.56,.64,1) both",
              }}
            />
          )}
          <div
            className="grid place-items-center rounded-full bg-[color:var(--primary)]"
            style={{
              width: hovered ? 12 : 10,
              height: hovered ? 12 : 10,
              transform: pulse > 0 ? "scale(1.35)" : "scale(1)",
              transition: "width 220ms cubic-bezier(.34,1.56,.64,1), height 220ms cubic-bezier(.34,1.56,.64,1), transform 160ms cubic-bezier(.34,1.56,.64,1)",
            }}
          />
        </div>
      </div>
    </>
  );
}
