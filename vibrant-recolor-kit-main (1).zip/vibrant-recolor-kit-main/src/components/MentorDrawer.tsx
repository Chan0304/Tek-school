import { useEffect, type ReactNode } from "react";
import { createPortal } from "react-dom";
import {
  X,
  Award,
  Briefcase,
  GraduationCap,
  Sparkles,
  MapPin,
  Users,
} from "lucide-react";

export type Mentor = {
  name: string;
  role: string;
  img: string;
  color: "coral" | "lavender" | "blue" | "navy";
  bio: string;
  fact: string;
  achievements: string[];
  qualifications: string[];
  experience: { role: string; org: string; period: string; desc: string }[];
};

const colorBg = (c: Mentor["color"]) =>
  c === "coral"
    ? "bg-[color:var(--coral)]"
    : c === "lavender"
      ? "bg-[color:var(--lavender)]"
      : c === "blue"
        ? "gradient-blue"
        : "bg-primary";

type Props = {
  mentor: Mentor | null;
  onClose: () => void;
};

export function MentorDrawer({ mentor, onClose }: Props) {
  useEffect(() => {
    if (!mentor) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [mentor, onClose]);

  if (!mentor || typeof document === "undefined") return null;
  const m = mentor;

  return createPortal(
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`${m.name} profile`}
      className="fixed inset-0 z-[110]"
    >
      <button
        aria-label="Close"
        onClick={onClose}
        className="tek-overlay-in absolute inset-0 bg-slate-900/55 backdrop-blur-sm"
      />
      <aside className="absolute right-0 top-0 flex h-full w-full max-w-[560px] flex-col overflow-hidden bg-white shadow-2xl motion-safe:animate-[slide-in-right_.32s_var(--ease-out-soft)]">
        <button
          aria-label="Close"
          onClick={onClose}
          className="absolute right-4 top-4 z-20 grid h-9 w-9 place-items-center rounded-full bg-white/90 text-slate-500 backdrop-blur transition-colors hover:bg-white hover:text-primary"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="h-full w-full overflow-y-auto">
          {/* Hero */}
          <div className={`relative h-72 ${colorBg(m.color)}`}>
            <img
              src={m.img}
              alt={m.name}
              className="h-full w-full object-cover mix-blend-luminosity opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 p-6 text-white">
              <span className="inline-block rounded-full bg-white/20 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider backdrop-blur-sm">
                {m.role}
              </span>
              <h2 className="font-display mt-2 text-3xl font-bold leading-tight">
                {m.name}
              </h2>
            </div>
          </div>

          <div className="p-6 sm:p-8">
            <p className="text-sm leading-relaxed text-muted-foreground">
              {m.bio}
            </p>

            <Section title="Experience" icon={Briefcase}>
              <div className="space-y-4">
                {m.experience.map((exp) => (
                  <div
                    key={exp.period}
                    className="relative rounded-2xl border border-border/60 bg-muted/40 p-4"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="font-display text-base font-bold">
                          {exp.role}
                        </p>
                        <p className="text-sm text-muted-foreground">{exp.org}</p>
                      </div>
                      <span className="shrink-0 rounded-full bg-primary/10 px-2.5 py-1 text-[11px] font-semibold text-primary">
                        {exp.period}
                      </span>
                    </div>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                      {exp.desc}
                    </p>
                  </div>
                ))}
              </div>
            </Section>

            <Section title="Qualifications" icon={GraduationCap}>
              <ul className="space-y-3">
                {m.qualifications.map((q) => (
                  <li key={q} className="flex items-start gap-3 text-sm">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[color:var(--accent-blue-deep)]" />
                    <span className="text-muted-foreground">{q}</span>
                  </li>
                ))}
              </ul>
            </Section>

            <Section title="Achievements" icon={Award}>
              <ul className="space-y-3">
                {m.achievements.map((a) => (
                  <li key={a} className="flex items-start gap-3 text-sm">
                    <Award className="mt-0.5 h-4 w-4 shrink-0 text-[color:var(--coral)]" />
                    <span className="text-muted-foreground">{a}</span>
                  </li>
                ))}
              </ul>
            </Section>

            <Section title="What makes them tick" icon={Sparkles}>
              <div className="rounded-2xl bg-[color:var(--sky)] p-5">
                <p className="text-sm leading-relaxed text-foreground">{m.fact}</p>
              </div>
            </Section>

            <div className="mt-10 flex items-center gap-3 rounded-2xl border border-border/60 bg-muted/40 p-4">
              <div className="grid h-10 w-10 place-items-center rounded-full bg-primary text-primary-foreground">
                <MapPin className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs font-semibold text-muted-foreground">Based in</p>
                <p className="text-sm font-medium">Bengaluru & Remote</p>
              </div>
              <div className="ml-auto grid h-10 w-10 place-items-center rounded-full bg-[color:var(--coral)] text-[color:var(--coral-foreground)]">
                <Users className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs font-semibold text-muted-foreground">Students</p>
                <p className="text-sm font-medium">Mentor-led cohorts</p>
              </div>
            </div>

            <div className="mt-8 pb-4">
              <button
                onClick={onClose}
                className="w-full rounded-full bg-primary px-5 py-3.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
              >
                Back to team
              </button>
            </div>
          </div>
        </div>
      </aside>
    </div>,
    document.body,
  ) as ReactNode;
}

function Section({
  title,
  icon: Icon,
  children,
}: {
  title: string;
  icon: React.ElementType;
  children: ReactNode;
}) {
  return (
    <div className="mt-9">
      <div className="mb-4 flex items-center gap-2">
        <Icon className="h-4 w-4 text-[color:var(--accent-blue-deep)]" />
        <p className="text-xs font-semibold uppercase tracking-[0.12em] text-muted-foreground">
          {title}
        </p>
      </div>
      {children}
    </div>
  );
}
