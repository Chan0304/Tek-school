import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { X, Bell, CalendarClock, Trophy, Briefcase, MessageCircle, CheckCheck } from "lucide-react";

export type Notification = {
  id: string;
  title: string;
  body: string;
  when: string;
  kind: "class" | "achievement" | "placement" | "community";
  to?: string;
  read: boolean;
};

export const SEED_NOTIFICATIONS: Notification[] = [
  {
    id: "n1",
    title: "Live class starts in 30 minutes",
    body: "Transformers from scratch — attention head walkthrough with Ananya Rao.",
    when: "just now",
    kind: "class",
    to: "/dashboard/live-room",
    read: false,
  },
  {
    id: "n2",
    title: "Razorpay moved you to Interview",
    body: "AI Engineer — LLM Products. Prep kit added to your placements tab.",
    when: "2h ago",
    kind: "placement",
    to: "/dashboard/placements",
    read: false,
  },
  {
    id: "n3",
    title: "Quest complete · +200 XP",
    body: "You shipped this week's RAG assignment. Level 8 is 1,080 XP away.",
    when: "5h ago",
    kind: "achievement",
    to: "/dashboard/profile",
    read: false,
  },
  {
    id: "n4",
    title: "Ananya replied in #help-ai-engineering",
    body: "\"Chunk overlap of 15% works better for arXiv abstracts.\"",
    when: "1d ago",
    kind: "community",
    to: "/dashboard/community",
    read: true,
  },
  {
    id: "n5",
    title: "Assignment due in 2 days",
    body: "Build a mini RAG over 500 arXiv abstracts — code repo submission.",
    when: "1d ago",
    kind: "class",
    to: "/dashboard/assignments",
    read: true,
  },
];

const TONE: Record<Notification["kind"], { icon: typeof Bell; chip: string }> = {
  class: { icon: CalendarClock, chip: "bg-[#2D5FA8]/12 text-[#2D5FA8]" },
  achievement: { icon: Trophy, chip: "bg-[#E85D4C]/12 text-[#C24634]" },
  placement: { icon: Briefcase, chip: "bg-[#1E1B4B]/10 text-[#1E1B4B]" },
  community: { icon: MessageCircle, chip: "bg-[#5B3FA0]/12 text-[#5B3FA0]" },
};

export function NotificationDrawer({
  open,
  onClose,
  items,
  onMarkAllRead,
  onRead,
}: {
  open: boolean;
  onClose: () => void;
  items: Notification[];
  onMarkAllRead: () => void;
  onRead: (id: string) => void;
}) {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    if (open) {
      const t = requestAnimationFrame(() => setMounted(true));
      return () => cancelAnimationFrame(t);
    }
    setMounted(false);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  const unread = items.filter((n) => !n.read).length;

  return (
    <div className="fixed inset-0 z-[70]" role="dialog" aria-label="Notifications">
      <div
        onClick={onClose}
        className={`absolute inset-0 bg-slate-900/30 backdrop-blur-[2px] transition-opacity duration-300 ${mounted ? "opacity-100" : "opacity-0"}`}
      />
      <aside
        className={`absolute right-0 top-0 flex h-full w-full max-w-[420px] flex-col bg-white shadow-2xl transition-transform duration-300 ease-out ${
          mounted ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <header className="flex items-center gap-3 border-b border-slate-200/80 px-5 py-4">
          <span className="grid h-9 w-9 place-items-center rounded-full bg-[var(--accent-blue-deep)]/10 text-[var(--accent-blue-deep)]">
            <Bell className="h-4 w-4" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="font-display text-lg font-bold leading-tight">Notifications</p>
            <p className="text-[11px] font-semibold text-slate-500">
              {unread > 0 ? `${unread} unread` : "You're all caught up"}
            </p>
          </div>
          {unread > 0 && (
            <button
              onClick={onMarkAllRead}
              className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 px-3 py-1.5 text-[11px] font-bold text-slate-600 transition-colors hover:bg-slate-50"
            >
              <CheckCheck className="h-3.5 w-3.5" /> Mark all read
            </button>
          )}
          <button
            onClick={onClose}
            aria-label="Close notifications"
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-slate-200 transition-colors hover:bg-slate-50"
          >
            <X className="h-4 w-4 text-slate-500" />
          </button>
        </header>

        <div className="flex-1 overflow-y-auto p-3">
          {items.length === 0 ? (
            <div className="grid h-full place-items-center px-8 text-center">
              <div>
                <Bell className="mx-auto h-8 w-8 text-slate-300" />
                <p className="mt-3 text-sm font-semibold text-slate-500">No notifications yet</p>
              </div>
            </div>
          ) : (
            <ul className="space-y-2">
              {items.map((n, i) => {
                const tone = TONE[n.kind];
                const Inner = (
                  <>
                    <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${tone.chip}`}>
                      <tone.icon className="h-4 w-4" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-start gap-2">
                        <span className={`flex-1 text-sm leading-snug ${n.read ? "font-semibold text-slate-600" : "font-bold text-slate-900"}`}>
                          {n.title}
                        </span>
                        {!n.read && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-[var(--accent-blue-deep)]" />}
                      </span>
                      <span className="mt-1 block text-xs leading-relaxed text-slate-500">{n.body}</span>
                      <span className="mt-1.5 block text-[10px] font-bold uppercase tracking-wider text-slate-400">{n.when}</span>
                    </span>
                  </>
                );
                const cls = `flex w-full items-start gap-3 rounded-2xl border p-3 text-left transition-colors ${
                  n.read ? "border-slate-100 bg-white hover:bg-slate-50" : "border-[var(--accent-blue-deep)]/15 bg-[var(--accent-blue-deep)]/[0.04] hover:bg-[var(--accent-blue-deep)]/[0.07]"
                }`;
                return (
                  <li
                    key={n.id}
                    className={mounted ? "animate-fade-in" : "opacity-0"}
                    style={{ animationDelay: `${60 + i * 45}ms`, animationFillMode: "both" }}
                  >
                    {n.to ? (
                      <Link to={n.to} onClick={() => { onRead(n.id); onClose(); }} className={cls}>
                        {Inner}
                      </Link>
                    ) : (
                      <button onClick={() => onRead(n.id)} className={cls}>
                        {Inner}
                      </button>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </aside>
    </div>
  );
}
