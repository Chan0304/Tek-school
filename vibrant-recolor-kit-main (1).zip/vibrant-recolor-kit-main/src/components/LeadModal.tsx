import { useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, Loader2 } from "lucide-react";
import { FormModalShell } from "./FormModalShell";
import { submitCampusEnquiry } from "@/lib/campus.functions";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/;

const fieldCls =
  "w-full rounded-[12px] border border-slate-200 bg-slate-50 p-3 text-sm text-foreground outline-none transition-colors focus:border-primary/40 focus:bg-white focus:ring-2 focus:ring-primary/20";
const labelCls = "mb-1.5 block text-xs font-semibold text-muted-foreground";

function Req() {
  return <span className="text-[color:var(--coral)]"> *</span>;
}

/**
 * Compact lead-capture modal (Name · Email · Phone · Location) using the
 * shared premium modal shell from the home page popups.
 */
export function LeadModal({
  open,
  onClose,
  badge,
  title,
  subtitle,
  interest,
  institutionType = "General enquiry",
  cta = "Submit request",
  locationLabel = "Location",
  locationPlaceholder = "City / institution",
}: {
  open: boolean;
  onClose: () => void;
  badge?: string;
  title: string;
  subtitle?: string;
  interest: string;
  institutionType?: string;
  cta?: string;
  locationLabel?: string;
  locationPlaceholder?: string;
}) {
  const send = useServerFn(submitCampusEnquiry);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [location, setLocation] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const emailInvalid = email.length > 0 && !EMAIL_RE.test(email.trim());
  const complete = useMemo(
    () =>
      name.trim().length >= 2 &&
      EMAIL_RE.test(email.trim()) &&
      phone.trim().length >= 6 &&
      location.trim().length >= 2,
    [name, email, phone, location],
  );

  const close = () => {
    onClose();
    setTimeout(() => {
      setDone(false);
      setError(null);
    }, 250);
  };

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!complete) {
      setError("Please complete every field.");
      return;
    }
    setSubmitting(true);
    try {
      await send({
        data: {
          institution: location.trim(),
          institution_type: institutionType,
          contact_name: name.trim(),
          email: email.trim(),
          phone: phone.trim(),
          city: location.trim(),
          program_interest: interest,
        },
      });
      setDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <FormModalShell open={open} onClose={close} badge={badge} title={title} subtitle={subtitle} maxWidth="480px">
      {done ? (
        <div className="py-8 text-center">
          <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-primary text-primary-foreground">
            <CheckCircle2 className="h-8 w-8" />
          </div>
          <h3 className="mt-5 font-display text-2xl font-bold">Request received</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            Thanks {name.trim().split(" ")[0]} — our team will reach out within two working days.
          </p>
          <button
            type="button"
            onClick={close}
            className="mt-7 w-full rounded-full bg-primary py-3 text-sm font-semibold text-primary-foreground"
          >
            Done
          </button>
        </div>
      ) : (
        <form onSubmit={onSubmit} noValidate className="space-y-4">
          <div>
            <label htmlFor="lm-name" className={labelCls}>Name<Req /></label>
            <input id="lm-name" required maxLength={100} value={name} onChange={(e) => setName(e.target.value)} className={fieldCls} placeholder="Your full name" />
          </div>
          <div>
            <label htmlFor="lm-email" className={labelCls}>Email<Req /></label>
            <input id="lm-email" type="email" required maxLength={255} value={email} onChange={(e) => setEmail(e.target.value)} className={fieldCls} placeholder="you@example.com" />
            {emailInvalid && <p className="mt-1 text-xs text-[color:var(--coral)]">Enter a valid email address.</p>}
          </div>
          <div>
            <label htmlFor="lm-phone" className={labelCls}>Phone number<Req /></label>
            <input id="lm-phone" type="tel" required maxLength={30} value={phone} onChange={(e) => setPhone(e.target.value)} className={fieldCls} placeholder="+91 98xxx xxxxx" />
          </div>
          <div>
            <label htmlFor="lm-loc" className={labelCls}>{locationLabel}<Req /></label>
            <input id="lm-loc" required maxLength={100} value={location} onChange={(e) => setLocation(e.target.value)} className={fieldCls} placeholder={locationPlaceholder} />
          </div>

          {error && <p className="text-xs font-medium text-[color:var(--coral)]">{error}</p>}

          <button
            type="submit"
            disabled={submitting}
            className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary py-3.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-60"
          >
            {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
            {submitting ? "Sending…" : cta}
          </button>
          <p className="text-center text-[11px] text-muted-foreground">We'll only use these details to contact you about this request.</p>
        </form>
      )}
    </FormModalShell>
  );
}
