import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell } from "@/components/mobile/AppShell";
import { MobileModal, SheetPrimary, SheetGhost } from "@/components/mobile/MobileModal";
import { Toast } from "@/components/mobile/Nudges";
import { ASSIGNMENTS, relativeDay } from "@/lib/dashboard-data";
import { ArrowLeft, Upload, FileText, Check, Paperclip, Github } from "lucide-react";

export const Route = createFileRoute("/app/task/$id")({
  head: () => ({ meta: [{ title: "Assignment — TekSchool" }, { name: "robots", content: "noindex" }] }),
  component: TaskDetail,
  notFoundComponent: () => <AppShell title="Not found"><p className="p-6 text-sm">Task not found.</p></AppShell>,
});

function TaskDetail() {
  const { id } = Route.useParams();
  const a = ASSIGNMENTS.find((x) => x.id === id);
  if (!a) throw notFound();
  const [open, setOpen] = useState(false);
  const [link, setLink] = useState("");
  const [toast, setToast] = useState<string | null>(null);
  function flash(m: string) { setToast(m); setTimeout(() => setToast(null), 1800); }

  const isRepo = a.submissionType === "Code repo";

  return (
    <AppShell title="Assignment">
      <div className="px-5 pt-3">
        <Link to="/app/tasks" className="inline-flex items-center gap-1 text-xs font-semibold text-slate-500"><ArrowLeft className="h-3.5 w-3.5" /> Back</Link>
      </div>

      <div className="mt-3 px-5">
        <div className="rounded-3xl bg-white p-5 shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)]">
          <div className="flex items-center gap-2">
            <span className="grid h-6 w-6 place-items-center rounded-lg bg-slate-100"><FileText className="h-3.5 w-3.5" /></span>
            <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">{a.module} · Due {relativeDay(a.dueDate)}</p>
          </div>
          <h3 className="mt-2 font-display text-xl font-bold leading-snug">{a.title}</h3>
          <p className="mt-3 text-sm text-slate-600">Submit via {a.submissionType.toLowerCase()}. Rubric weighs correctness (60%), code quality (25%), write-up (15%).</p>
          <div className="mt-4 h-1.5 rounded-full bg-slate-100"><div className="h-full rounded-full bg-[#1E1B4B]" style={{ width: `${a.status === "reviewed" || a.status === "submitted" ? 100 : 20}%` }} /></div>
          <p className="mt-2 text-[11px] text-slate-500">
            {a.status === "reviewed" ? `Grade ${a.grade}` : a.status === "submitted" ? "Under review" : "Draft saved · 20% complete"}
          </p>
        </div>
      </div>

      {a.status === "reviewed" && a.feedback && (
        <div className="mt-4 px-5">
          <div className="rounded-3xl bg-[#DCEBFA] p-5">
            <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-[#1F4E8A]">Mentor feedback</p>
            <p className="mt-2 text-sm leading-relaxed text-slate-800">{a.feedback}</p>
          </div>
        </div>
      )}

      {(a.status === "due" || a.status === "overdue") && (
        <div className="mt-4 px-5">
          <button onClick={() => setOpen(true)} className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-[#1E1B4B] py-3.5 text-sm font-bold text-white active:scale-[0.98]">
            <Upload className="h-4 w-4" /> Submit {a.submissionType}
          </button>
        </div>
      )}

      <MobileModal open={open} onClose={() => setOpen(false)} eyebrow="Submission" title={`Submit ${a.submissionType}`}
        footer={<>
          <SheetPrimary onClick={() => { setOpen(false); flash("Submitted — mentor notified"); }}><Upload className="h-4 w-4 mr-1" /> Submit for review</SheetPrimary>
          <SheetGhost onClick={() => setOpen(false)}>Save draft</SheetGhost>
        </>}>
        {isRepo ? (
          <label className="block">
            <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-slate-500">GitHub repo URL</span>
            <div className="mt-1.5 flex items-center gap-2 rounded-2xl bg-slate-100 px-4 py-3">
              <Github className="h-4 w-4 text-slate-400" />
              <input autoFocus value={link} onChange={(e) => setLink(e.target.value)} placeholder="github.com/you/mini-rag" className="w-full bg-transparent text-sm focus:outline-none" />
            </div>
          </label>
        ) : (
          <button className="flex w-full items-center gap-3 rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-6">
            <Paperclip className="h-5 w-5 text-slate-400" />
            <div className="text-left">
              <p className="text-sm font-semibold text-slate-800">Tap to upload</p>
              <p className="text-xs text-slate-500">PDF, DOCX or ZIP · max 25MB</p>
            </div>
          </button>
        )}
        <p className="mt-3 text-xs text-slate-500">Late submissions recover 50% of the grade if within 24 hours.</p>
      </MobileModal>

      <Toast show={!!toast} message={toast ?? ""} icon={Check} />
    </AppShell>
  );
}
