import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell, NavyCard } from "@/components/mobile/AppShell";
import { MobileModal, SheetPrimary, SheetGhost } from "@/components/mobile/MobileModal";
import { Toast } from "@/components/mobile/Nudges";
import { CLASSES, formatDate } from "@/lib/dashboard-data";
import { ArrowLeft, Play, Download, MessageSquare, Video, Check, Send } from "lucide-react";

export const Route = createFileRoute("/app/class/$id")({
  head: () => ({ meta: [{ title: "Class — TekSchool" }, { name: "robots", content: "noindex" }] }),
  component: ClassDetail,
  notFoundComponent: () => <AppShell title="Not found"><p className="p-6 text-sm">Class not found.</p></AppShell>,
});

function ClassDetail() {
  const { id } = Route.useParams();
  const c = CLASSES.find((x) => x.id === id);
  if (!c) throw notFound();
  const isLive = c.status === "upcoming" || c.status === "live";
  const [openJoin, setOpenJoin] = useState(false);
  const [openWatch, setOpenWatch] = useState(false);
  const [openSlides, setOpenSlides] = useState(false);
  const [openAsk, setOpenAsk] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [msg, setMsg] = useState("");
  function flash(m: string) { setToast(m); setTimeout(() => setToast(null), 1800); }

  return (
    <AppShell title="Class">
      <div className="px-5 pt-3">
        <Link to="/app/classes" className="inline-flex items-center gap-1 text-xs font-semibold text-slate-500"><ArrowLeft className="h-3.5 w-3.5" /> Back</Link>
      </div>
      <div className="mt-3 px-5">
        {isLive ? (
          <NavyCard
            live
            eyebrow={`${c.module} · ${formatDate(c.date)}`}
            title={c.topic}
            subtitle={`with ${c.instructor} · ${c.duration}`}
            action={<button onClick={() => setOpenJoin(true)} className="inline-flex items-center gap-1.5 rounded-full bg-white px-4 py-2 text-xs font-bold text-[#1E1B4B] active:scale-95"><Play className="h-3 w-3 fill-current" /> Join room</button>}
          />
        ) : (
          <div className="rounded-3xl bg-white p-5 shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)]">
            <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">{c.module} · Recording</p>
            <h3 className="mt-2 font-display text-lg font-bold">{c.topic}</h3>
            <p className="mt-1 text-xs text-slate-500">{c.instructor} · {c.duration}</p>
            <div className="mt-3 h-1.5 rounded-full bg-slate-100"><div className="h-full rounded-full bg-[#1E1B4B]" style={{ width: `${c.progress ?? 0}%` }} /></div>
            <div className="mt-4 flex gap-2">
              <button onClick={() => setOpenWatch(true)} className="inline-flex items-center gap-1.5 rounded-full bg-[#1E1B4B] px-4 py-2 text-xs font-bold text-white active:scale-95"><Play className="h-3 w-3 fill-current" /> Watch</button>
              <button onClick={() => setOpenSlides(true)} className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 px-4 py-2 text-xs font-bold text-slate-700 active:scale-95"><Download className="h-3 w-3" /> Slides</button>
            </div>
          </div>
        )}
      </div>

      <div className="mt-6 px-5">
        <h4 className="mb-2 font-display text-sm font-bold">What you'll cover</h4>
        <ul className="space-y-2 text-sm text-slate-700">
          <li className="rounded-2xl bg-white p-3">1. Concept walkthrough with real examples</li>
          <li className="rounded-2xl bg-white p-3">2. Live coding — apply on a real dataset</li>
          <li className="rounded-2xl bg-white p-3">3. Q&A + assignment brief</li>
        </ul>
      </div>

      <div className="mt-6 px-5">
        <button onClick={() => setOpenAsk(true)} className="inline-flex items-center gap-1.5 rounded-full bg-white px-4 py-2 text-xs font-semibold shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)] active:scale-95"><MessageSquare className="h-3.5 w-3.5" /> Ask {c.instructor}</button>
      </div>

      <MobileModal open={openJoin} onClose={() => setOpenJoin(false)} eyebrow="Live room" title={`Join ${c.instructor}'s class`}
        footer={<>
          <SheetPrimary onClick={() => { setOpenJoin(false); flash("Joined — welcome!"); }}><Video className="h-4 w-4 mr-1" /> Enter room</SheetPrimary>
          <SheetGhost onClick={() => setOpenJoin(false)}>Not now</SheetGhost>
        </>}>
        <div className="rounded-2xl bg-slate-900 p-6 text-center text-white">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-white/10">
            <Video className="h-6 w-6" />
          </div>
          <p className="mt-3 text-sm font-semibold">{c.topic}</p>
          <p className="mt-1 text-xs text-white/60">{c.duration} · Camera off by default</p>
        </div>
      </MobileModal>

      <MobileModal open={openWatch} onClose={() => setOpenWatch(false)} eyebrow="Recording" title={c.topic}>
        <div className="aspect-video overflow-hidden rounded-2xl bg-slate-900">
          <div className="grid h-full place-items-center text-white/50 text-xs">▶ Playback stub</div>
        </div>
        <p className="mt-3 text-xs">Auto-quality · 1.25× available in fullscreen.</p>
      </MobileModal>

      <MobileModal open={openSlides} onClose={() => setOpenSlides(false)} eyebrow="Slides" title="Download slides"
        footer={<SheetPrimary onClick={() => { setOpenSlides(false); flash("Slides downloaded"); }}><Download className="h-4 w-4 mr-1" /> Save PDF</SheetPrimary>}>
        <div className="rounded-2xl bg-slate-100 p-4 text-xs">
          <p className="font-bold text-slate-900">{c.topic}.pdf</p>
          <p className="mt-1 text-slate-500">32 slides · 4.8 MB · updated {formatDate(c.date)}</p>
        </div>
      </MobileModal>

      <MobileModal open={openAsk} onClose={() => setOpenAsk(false)} eyebrow="Message" title={`Ask ${c.instructor}`}
        footer={<SheetPrimary onClick={() => { if (msg.trim()) { setOpenAsk(false); setMsg(""); flash(`Sent to ${c.instructor.split(" ")[0]}`); } }}><Send className="h-4 w-4 mr-1" /> Send message</SheetPrimary>}>
        <textarea autoFocus value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Type your question…" rows={4} className="w-full rounded-2xl bg-slate-100 p-3 text-sm focus:outline-none" />
      </MobileModal>

      <Toast show={!!toast} message={toast ?? ""} icon={Check} />
    </AppShell>
  );
}
