import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell, WhiteTaskCard, SectionTitle } from "@/components/mobile/AppShell";
import { ASSIGNMENTS, relativeDay } from "@/lib/dashboard-data";
import { FileText, Github, HelpCircle } from "lucide-react";

export const Route = createFileRoute("/app/tasks")({
  head: () => ({ meta: [{ title: "Tasks — TekSchool" }, { name: "robots", content: "noindex" }] }),
  component: TasksScreen,
});

const GROUPS = [
  { key: "due", label: "Due Soon" },
  { key: "submitted", label: "Submitted" },
  { key: "reviewed", label: "Reviewed" },
  { key: "overdue", label: "Overdue" },
] as const;

function iconFor(type: string) {
  if (type === "Code repo") return <Github className="h-3.5 w-3.5" />;
  if (type === "Quiz") return <HelpCircle className="h-3.5 w-3.5" />;
  return <FileText className="h-3.5 w-3.5" />;
}

function progressFor(status: string): number {
  if (status === "reviewed") return 100;
  if (status === "submitted") return 100;
  if (status === "due") return 20;
  return 0;
}

function TasksScreen() {
  return (
    <AppShell title="Tasks">
      <div className="mt-5 space-y-6">
        {GROUPS.map((g) => {
          const items = ASSIGNMENTS.filter((a) => a.status === g.key);
          if (items.length === 0) return null;
          return (
            <div key={g.key}>
              <SectionTitle title={g.label} action={<span className="text-xs font-semibold text-slate-400">{items.length}</span>} />
              <div className="space-y-3 px-5">
                {items.map((a) => (
                  <Link key={a.id} to="/app/task/$id" params={{ id: a.id }}>
                    <WhiteTaskCard
                      icon={iconFor(a.submissionType)}
                      eyebrow={`${a.module} · ${relativeDay(a.dueDate)}`}
                      title={a.title}
                      progress={progressFor(a.status)}
                      caption={a.status === "reviewed" ? `Grade ${a.grade}` : a.status === "submitted" ? "Under review" : a.status === "overdue" ? "Late — submit to recover 50%" : "Draft saved · 20% complete"}
                    />
                  </Link>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </AppShell>
  );
}
