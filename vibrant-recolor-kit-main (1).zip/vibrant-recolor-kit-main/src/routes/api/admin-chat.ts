import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, streamText, tool, stepCountIs, type UIMessage } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";
import {
  STUDENTS, ENQUIRIES, PLACEMENTS, HIRING_PARTNERS, ADMIN_ASSIGNMENTS, FINANCE, COHORTS, INSTRUCTORS, KPIS,
} from "@/lib/admin-data";
import { AUTHORITIES, type Authority } from "@/lib/outreach-data";

const SYSTEM_PROMPT = `You are the TekSchool Admin Copilot — sharp, concise, and operations-savvy. You help staff run the school: admissions, cohorts, placements, outreach, finance, curriculum.

RULES:
- Keep replies compact. Use short paragraphs or tight bullet lists (max 6 bullets).
- Reference REAL numbers only when a tool returns them — never invent counts, names, or emails.
- When asked "show me / list / find", call the matching tool instead of describing.
- For bulk actions (email/SMS/WhatsApp) or role grants, draft first, ask to confirm, then say the user should hit "Send" in Outreach.
- If a request is outside admin scope, say so plainly.`;

const tools = {
  kpi_snapshot: tool({
    description: "Return current headline KPIs for the school (students, enquiries, conversion, placement, revenue).",
    inputSchema: z.object({}),
    execute: async () => KPIS,
  }),
  find_students: tool({
    description: "Search students by name/email/city/track. Returns up to 8.",
    inputSchema: z.object({ query: z.string().optional(), track: z.string().optional(), atRiskOnly: z.boolean().optional() }),
    execute: async ({ query, track, atRiskOnly }) => {
      const q = (query ?? "").toLowerCase();
      const rows = STUDENTS.filter((s) =>
        (!q || s.name.toLowerCase().includes(q) || s.email.toLowerCase().includes(q) || s.city.toLowerCase().includes(q))
        && (!track || s.track === track)
        && (!atRiskOnly || s.atRisk)
      ).slice(0, 8);
      return { count: rows.length, rows };
    },
  }),
  pipeline_snapshot: tool({
    description: "Return counts of enquiries by stage and top 5 stale enquiries.",
    inputSchema: z.object({}),
    execute: async () => {
      const byStage: Record<string, number> = {};
      ENQUIRIES.forEach((e) => { byStage[e.stage] = (byStage[e.stage] ?? 0) + 1; });
      const stale = [...ENQUIRIES].filter((e) => e.stage !== "Enrolled" && e.stage !== "Lost").slice(0, 5);
      return { byStage, stale };
    },
  }),
  find_hr_contacts: tool({
    description: "Find verified HR / hiring-manager contacts at hiring partners for a given track. Simulates enrichment.",
    inputSchema: z.object({ track: z.string().optional(), limit: z.number().optional() }),
    execute: async ({ track, limit }) => {
      const rows = HIRING_PARTNERS.filter((p) => !track || p.track === track).slice(0, limit ?? 5).map((p) => ({
        company: p.company, contact: p.contact, email: p.email, activeRoles: p.activeRoles, track: p.track,
        confidence: 0.82 + Math.random() * 0.15,
      }));
      return { count: rows.length, rows };
    },
  }),
  authority_contacts: tool({
    description: "Return school-authority contacts (principals, admin heads) for outreach.",
    inputSchema: z.object({ query: z.string().optional() }),
    execute: async ({ query }) => {
      const q = (query ?? "").toLowerCase();
      const rows = AUTHORITIES.filter((c: Authority) =>
        !q || c.name.toLowerCase().includes(q) || c.institution.toLowerCase().includes(q) || c.city.toLowerCase().includes(q)
      ).slice(0, 8);

      return { count: rows.length, rows };
    },
  }),
  draft_outreach: tool({
    description: "Draft a bulk message (email / SMS / WhatsApp). Return subject + body only — sending happens from the Outreach page.",
    inputSchema: z.object({
      channel: z.enum(["email", "sms", "whatsapp"]),
      audience: z.string().describe("e.g. 'principals in Bengaluru' or 'HR at cloud-hiring partners'"),
      goal: z.string(),
      tone: z.enum(["warm", "formal", "urgent"]).optional(),
    }),
    execute: async ({ channel, audience, goal, tone }) => ({
      channel, audience, tone: tone ?? "warm", goal,
      subject: channel === "email" ? `TekSchool · ${goal.slice(0, 60)}` : undefined,
    }),
  }),
  placement_status: tool({
    description: "Snapshot of placements by stage plus 5 most-recently-updated candidates.",
    inputSchema: z.object({}),
    execute: async () => {
      const byStage: Record<string, number> = {};
      PLACEMENTS.forEach((p) => { byStage[p.stage] = (byStage[p.stage] ?? 0) + 1; });
      const recent = [...PLACEMENTS].sort((a, b) => a.updatedDays - b.updatedDays).slice(0, 5);
      return { byStage, recent };
    },
  }),
  grading_queue: tool({
    description: "Return assignments with the largest pending-grading backlog.",
    inputSchema: z.object({}),
    execute: async () => ({ rows: [...ADMIN_ASSIGNMENTS].sort((a, b) => b.pending - a.pending).slice(0, 5) }),
  }),
  finance_overview: tool({
    description: "Return revenue, outstanding, and top 5 overdue accounts.",
    inputSchema: z.object({}),
    execute: async () => {
      const total = FINANCE.reduce((s, r) => s + r.total, 0);
      const collected = FINANCE.reduce((s, r) => s + r.paid, 0);
      const outstanding = total - collected;
      const overdue = [...FINANCE].filter((r) => r.paid < r.total).slice(0, 5);
      return { total, collected, outstanding, overdue };
    },
  }),
  cohort_health: tool({
    description: "Health of upcoming cohorts (capacity, mentor, dates).",
    inputSchema: z.object({}),
    execute: async () => ({ cohorts: COHORTS, instructors: INSTRUCTORS.length }),
  }),
};

export const Route = createFileRoute("/api/admin-chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { messages } = (await request.json()) as { messages: UIMessage[] };
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });
        const gateway = createLovableAiGatewayProvider(key);
        const result = streamText({
          model: gateway("google/gemini-3-flash-preview"),
          system: SYSTEM_PROMPT,
          messages: await convertToModelMessages(messages),
          tools,
          stopWhen: stepCountIs(50),
        });
        return result.toUIMessageStreamResponse({ originalMessages: messages });
      },
    },
  },
});
