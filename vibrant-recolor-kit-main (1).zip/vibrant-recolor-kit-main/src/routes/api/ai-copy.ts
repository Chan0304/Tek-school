// AI copy rewrite for Creative Studio — returns 3 tone variants of the input text.
import { createFileRoute } from "@tanstack/react-router";
import { generateText } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";

export const Route = createFileRoute("/api/ai-copy")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response(JSON.stringify({ error: "Missing LOVABLE_API_KEY" }), { status: 500 });
        try {
          const { text, context } = (await request.json()) as { text: string; context?: string };
          if (!text?.trim()) return new Response(JSON.stringify({ error: "Text is required" }), { status: 400 });

          const gateway = createLovableAiGatewayProvider(key);
          const { text: out } = await generateText({
            model: gateway("openai/gpt-5.5"),
            system: `You rewrite marketing copy for TekSchool — an Indian engineering school (AI, Cloud, Software Engineering programs).
Voice: warm, confident, direct, a bit informal. Never hype, never corporate.
Return EXACTLY three variations in this format, no preamble:
PROFESSIONAL: <one line>
PUNCHY: <one line>
URGENT: <one line>
Each variation must be under 90 characters, retain the original meaning, and feel human.`,
            prompt: `Original copy: "${text.trim()}"${context ? `\nContext: ${context}` : ""}\n\nRewrite as three tone variations.`,
          });

          const lines = out.split("\n").map((l) => l.trim()).filter(Boolean);
          const pick = (tag: string) => {
            const line = lines.find((l) => l.toUpperCase().startsWith(tag + ":"));
            return line ? line.slice(tag.length + 1).trim().replace(/^["']|["']$/g, "") : "";
          };
          return Response.json({
            variants: [
              { tone: "Professional", text: pick("PROFESSIONAL") || text },
              { tone: "Punchy", text: pick("PUNCHY") || text },
              { tone: "Urgent", text: pick("URGENT") || text },
            ],
          });
        } catch (err) {
          const msg = err instanceof Error ? err.message : "Unknown error";
          const status = /429/.test(msg) ? 429 : /402/.test(msg) ? 402 : 500;
          return new Response(JSON.stringify({ error: msg }), { status });
        }
      },
    },
  },
});
