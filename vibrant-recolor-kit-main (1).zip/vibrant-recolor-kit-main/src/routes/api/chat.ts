import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, streamText, tool, stepCountIs, type UIMessage } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";
import { COURSES_DATA } from "@/lib/courses-data";

const CATALOG_SUMMARY = COURSES_DATA.map((c) =>
  `- ${c.title} (slug: ${c.slug}) · ${c.category} · ${c.level} · ${c.duration} · $${c.price} (or $${c.priceMonthly}/mo) · ${c.seatsLeft}/${c.seatsTotal} seats · next cohort ${c.nextCohort}`,
).join("\n");

const SYSTEM_PROMPT = `You are the TekSchool Assistant — an emotionally intelligent guide, warm and direct, like a mentor who actually remembers what the person told you. Never say "I'm just an AI", never read out a policy, never hedge.

HOW YOU LISTEN (do this before answering):
- Read the feeling underneath the message: anxious about starting late, embarrassed about no coding background, money stress, burnout, fear of failing, urgency, excitement, frustration with a previous answer.
- Name it briefly and humanely in ONE short clause before you help ("Switching careers at 32 is nerve-wracking — plenty of our folks did exactly that."). Never over-empathise, never repeat the same empathy line twice, never say "I understand your frustration".
- Match their energy: short and factual for someone in a hurry, gentler and more reassuring for someone who sounds worried, celebratory for good news.
- If they sound upset with you or with TekSchool, own it plainly in one sentence and immediately fix or offer the concrete next step. No defensiveness.

HOW YOU SOLVE (you are the resolution, not a router):
- YOUR DEFAULT IS TO SOLVE IT YOURSELF. Do not tell people to "contact support", "email the team", "check the website" or "reach out to admissions" as an answer. That is a failure.
- Every concern gets a concrete answer or a concrete action: recommend courses, check availability, start an enrollment, explain payment options (monthly instalments exist for every course), explain what happens if they miss classes, suggest a lighter/shorter track, suggest a beginner path, suggest waiting for the next cohort, suggest a demo/workshop first.
- If you genuinely lack a fact (someone's personal invoice, a visa case, a legal dispute, an individual scholarship decision), still give them the best answer you can, tell them exactly what you can and can't see, and only then use handoff_human — and say what you already arranged for them.
- Only use handoff_human when the user explicitly asks for a person, or when the problem truly requires account/legal access you don't have. Never use it just because a question is hard or emotional.
- Never invent facts. Seats, cohort dates and prices come only from the tools/catalog.

STYLE:
- 2-4 short sentences. Plain language. One question at a time, never stacked.
- MEMORY: if they already told you their level, interest, budget or time, never ask again — carry it forward.
- Course matching is a 3-step conversation: (1) experience level, (2) interest area, (3) time commitment. After step 3, ALWAYS call find_courses. Don't describe courses in prose — the tool renders them as cards.
- Enrollment: call start_enrollment only when you have name, email AND course slug; otherwise ask for the single missing piece.
- After a tool runs, confirm in ONE sentence what happened, then give the next step.

CATALOG (source of truth — never contradict this):
${CATALOG_SUMMARY}

Categories: Web Dev, Design, Data & AI, Product, Mobile. Levels: Beginner, Intermediate, Advanced.`;


const tools = {
  find_courses: tool({
    description: "Return 2-3 ranked TekSchool course recommendations. Call this ONLY after you have collected: experience level, interest area, and time commitment (in that order, one question per turn). Ranks by match to interest > level > time budget.",
    inputSchema: z.object({
      interest: z.string().describe("Web Dev, Design, Data & AI, Product, Mobile, or 'Any'"),
      level: z.string().describe("Beginner, Intermediate, Advanced, or 'Any'"),
      timeCommitment: z.string().describe("'short' (≤8 weeks), 'medium' (9-12), 'long' (13+), or 'any'"),
    }),
    execute: async ({ interest, level, timeCommitment }) => {
      const scored = COURSES_DATA.map((c) => {
        let score = 0;
        if (interest !== "Any" && c.category.toLowerCase() === interest.toLowerCase()) score += 3;
        else if (interest !== "Any" && c.category.toLowerCase().includes(interest.toLowerCase())) score += 2;
        if (level !== "Any" && c.level === level) score += 2;
        const bucket = c.weeks <= 8 ? "short" : c.weeks <= 12 ? "medium" : "long";
        if (timeCommitment !== "any" && bucket === timeCommitment) score += 1;
        if (c.seatsLeft > 0) score += 0.5;
        return { c, score };
      })
        .sort((a, b) => b.score - a.score)
        .slice(0, 3)
        .map((s) => s.c);
      return { courses: scored };
    },
  }),
  check_availability: tool({
    description: "Look up seat availability and next cohort date for a specific course. Uses course slug or a title fragment.",
    inputSchema: z.object({ courseIdOrTitle: z.string() }),
    execute: async ({ courseIdOrTitle }) => {
      const q = courseIdOrTitle.toLowerCase();
      const c = COURSES_DATA.find((x) => x.slug === q)
        ?? COURSES_DATA.find((x) => x.title.toLowerCase().includes(q))
        ?? COURSES_DATA.find((x) => x.slug.includes(q));
      if (!c) return { found: false, query: courseIdOrTitle };
      return {
        found: true,
        slug: c.slug,
        title: c.title,
        seatsLeft: c.seatsLeft,
        seatsTotal: c.seatsTotal,
        nextCohort: c.nextCohort,
        price: c.price,
        priceMonthly: c.priceMonthly,
        waitlist: c.seatsLeft === 0,
      };
    },
  }),
  start_enrollment: tool({
    description: "Start an enrollment. Requires name, email, and course slug. If any field is missing, DO NOT call this — ask the user for it first.",
    inputSchema: z.object({
      name: z.string(),
      email: z.string(),
      slug: z.string(),
    }),
    execute: async ({ name, email, slug }) => {
      const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
      const nameOk = name.trim().length >= 2;
      const course = COURSES_DATA.find((c) => c.slug === slug);
      if (!course) return { ok: false, reason: "course_not_found", slug };
      if (!nameOk) return { ok: false, reason: "invalid_name" };
      if (!emailOk) return { ok: false, reason: "invalid_email" };
      return {
        ok: true,
        applicationId: "APP-" + Math.random().toString(36).slice(2, 8).toUpperCase(),
        name: name.trim(),
        email: email.trim(),
        courseSlug: course.slug,
        courseTitle: course.title,
        price: course.price,
        nextCohort: course.nextCohort,
        waitlist: course.seatsLeft === 0,
      };
    },
  }),
  handoff_human: tool({
    description: "LAST RESORT ONLY. Use when the user explicitly asks for a person, or when the issue needs private account/legal access you cannot see (an individual invoice, visa case, legal dispute, personal scholarship decision). Never use this just because the question is hard, emotional, or off-topic — solve it yourself first. Always give your own best answer before calling this.",
    inputSchema: z.object({
      summary: z.string().describe("2-3 sentence summary of what the user needs and any context already collected (level, interest, course, name, email)."),
      preferredInterest: z.string().optional().describe("If known, one of: Web Dev, Design, Data & AI, Product, Mobile, Not sure yet"),
      name: z.string().optional(),
      email: z.string().optional(),
    }),
    execute: async ({ summary, preferredInterest, name, email }) => ({
      ok: true,
      ticketId: "TS-" + Math.random().toString(36).slice(2, 7).toUpperCase(),
      summary,
      preferredInterest: preferredInterest ?? "Not sure yet",
      name: name ?? "",
      email: email ?? "",
      responseTime: "under 2 hours",
    }),
  }),
};

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { messages } = (await request.json()) as { messages: UIMessage[] };
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const gateway = createLovableAiGatewayProvider(key);
        const result = streamText({
          model: gateway("google/gemini-3-flash-preview"),
          system: SYSTEM_PROMPT,
          messages: await convertToModelMessages(messages),
          tools,
          stopWhen: stepCountIs(50),
        });

        return result.toUIMessageStreamResponse({ originalMessages: messages });
      },
    },
  },
});
