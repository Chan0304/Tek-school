// AI image generation for Creative Studio — non-streaming, returns a base64 data URL ready to drop on the canvas.
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/ai-image")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response(JSON.stringify({ error: "Missing LOVABLE_API_KEY" }), { status: 500 });
        try {
          const { prompt } = (await request.json()) as { prompt: string };
          if (!prompt?.trim()) return new Response(JSON.stringify({ error: "Prompt is required" }), { status: 400 });

          const upstream = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${key}`,
            },
            body: JSON.stringify({
              model: "google/gemini-2.5-flash-image",
              messages: [{ role: "user", content: `Generate a high-quality poster illustration: ${prompt.trim()}. Style: modern editorial, TekSchool brand palette (navy #1E1B4B, sky #5BA4E8, coral #F4A261, lavender #D4C4E8). No visible text or watermarks.` }],
              modalities: ["image", "text"],
            }),
          });
          if (!upstream.ok) {
            const body = await upstream.text();
            return new Response(JSON.stringify({ error: body }), { status: upstream.status });
          }
          const json = await upstream.json() as {
            choices?: Array<{ message?: { images?: Array<{ image_url?: { url?: string } }> } }>;
          };
          const url = json.choices?.[0]?.message?.images?.[0]?.image_url?.url;
          if (!url) return new Response(JSON.stringify({ error: "No image returned" }), { status: 502 });
          return Response.json({ url });
        } catch (err) {
          const msg = err instanceof Error ? err.message : "Unknown error";
          return new Response(JSON.stringify({ error: msg }), { status: 500 });
        }
      },
    },
  },
});
