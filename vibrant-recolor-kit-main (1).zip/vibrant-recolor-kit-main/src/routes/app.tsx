import { createFileRoute, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect } from "react";
import { useSession, useHydrated } from "@/lib/auth";

export const Route = createFileRoute("/app")({
  head: () => ({ meta: [{ title: "TekSchool App" }, { name: "robots", content: "noindex" }] }),
  component: AppLayout,
});

function AppLayout() {
  const session = useSession();
  const hydrated = useHydrated();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    if (!hydrated) return;
    const isAuthRoute = pathname === "/app/login" || pathname === "/app/splash";
    if (!session && !isAuthRoute) {
      navigate({ to: "/app/splash", replace: true });
    }
  }, [hydrated, session, pathname, navigate]);

  const isAuthRoute = pathname === "/app/login" || pathname === "/app/splash";
  if (hydrated && !session && !isAuthRoute) return null;
  return <Outlet />;
}

