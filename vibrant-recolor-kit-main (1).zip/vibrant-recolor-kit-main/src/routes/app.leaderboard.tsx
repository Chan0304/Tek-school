import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/mobile/AppShell";
import { LEADERBOARD } from "@/lib/dashboard-data";
import { ArrowLeft, Crown } from "lucide-react";

export const Route = createFileRoute("/app/leaderboard")({
  head: () => ({ meta: [{ title: "Leaderboard — TekSchool" }, { name: "robots", content: "noindex" }] }),
  component: LeaderboardScreen,
});

function Ava({ name, photo, size = 48 }: { name: string; photo?: string; size?: number }) {
  const initials = name.split(" ").map((n) => n[0]).slice(0, 2).join("");
  return (
    <div className="grid overflow-hidden rounded-full bg-[#E8E0F5] font-bold text-[#5B3E9B]" style={{ width: size, height: size, fontSize: size * 0.35 }}>
      {photo ? <img src={photo} alt={name} className="h-full w-full object-cover" /> : <span className="grid h-full w-full place-items-center">{initials}</span>}
    </div>
  );
}

function LeaderboardScreen() {
  const top3 = LEADERBOARD.slice(0, 3);
  const rest = LEADERBOARD.slice(3);
  const you = LEADERBOARD.find((r) => r.isYou);
  const podium = [top3[1], top3[0], top3[2]];
  const heights = [72, 96, 60];

  return (
    <AppShell title="Leaderboard">
      <div className="px-5 pt-3">
        <Link to="/app" className="inline-flex items-center gap-1 text-xs font-semibold text-slate-500"><ArrowLeft className="h-3.5 w-3.5" /> Back</Link>
      </div>

      <div className="mx-5 mt-3 overflow-hidden rounded-3xl bg-[#1E1B4B] p-5 text-white">
        <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-white/70">This week · March '26 cohort</p>
        <div className="mt-6 flex items-end justify-center gap-4">
          {podium.map((r, i) => r && (
            <div key={r.rank} className="flex flex-col items-center">
              {r.rank === 1 && <Crown className="h-4 w-4 text-[#F4A261]" />}
              <Ava name={r.name} photo={r.photo} size={i === 1 ? 56 : 44} />
              <p className="mt-2 text-[11px] font-bold">{r.name.split(" ")[0]}</p>
              <p className="text-[10px] text-white/60">{r.xp} XP</p>
              <div className="mt-2 w-12 rounded-t-lg bg-gradient-to-t from-[#2D5FA8] to-[#5BA4E8]" style={{ height: heights[i] }} />
              <p className="w-full rounded-b-lg bg-white/10 py-0.5 text-center text-[10px] font-bold">#{r.rank}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-4 space-y-2 px-5">
        {rest.map((r) => (
          <div key={r.rank} className={`flex items-center gap-3 rounded-2xl p-3 ${r.isYou ? "bg-[#DCEBFA] ring-2 ring-[#1E1B4B]" : "bg-white"} shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)]`}>
            <span className="w-6 text-center text-sm font-bold text-slate-500">{r.rank}</span>
            <Ava name={r.name} photo={r.photo} size={36} />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-bold">{r.name}{r.isYou && " (you)"}</p>
            </div>
            <span className="text-sm font-bold tabular-nums">{r.xp} XP</span>
          </div>
        ))}
      </div>

      {you && (
        <div className="sticky bottom-24 z-20 mx-5 mt-4 rounded-2xl bg-[#1E1B4B] p-3 text-white shadow-lg">
          <div className="flex items-center gap-3">
            <span className="w-6 text-center text-sm font-bold">#{you.rank}</span>
            <Ava name={you.name} photo={you.photo} size={36} />
            <p className="flex-1 text-sm font-bold">You</p>
            <span className="text-sm font-bold tabular-nums">{you.xp} XP</span>
          </div>
        </div>
      )}
    </AppShell>
  );
}
