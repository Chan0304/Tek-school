import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AdminShell } from "@/components/admin/AdminShell";
import { PipelineBoard } from "@/components/admin/PipelineBoard";
import { ENQUIRIES, type Enquiry } from "@/lib/admin-data";

export const Route = createFileRoute("/admin/enquiries")({
  head: () => ({ meta: [{ title: "Enquiries — Admin" }, { name: "robots", content: "noindex" }] }),
  component: EnquiriesAdmin,
});

const STAGES = ["New","Contacted","Demo Booked","Enrolled","Lost"];
const TINT: Record<string, string> = { "New": "#F4A261", "Contacted": "#5BA4E8", "Demo Booked": "#2D5FA8", "Enrolled": "#10B981", "Lost": "#94A3B8" };

function EnquiriesAdmin() {
  const [items, setItems] = useState<Enquiry[]>(ENQUIRIES);
  return (
    <AdminShell title="Enquiries">
      <p className="mb-3 text-xs text-slate-500">Every lead — from Contact form, WhatsApp, Instagram — lands here. Drag to update stage.</p>
      <PipelineBoard<Enquiry>
        stages={STAGES}
        items={items}
        tint={TINT}
        onMove={(id, to) => setItems((arr) => arr.map((x) => x.id === id ? { ...x, stage: to as Enquiry["stage"] } : x))}
        renderCard={(i) => (
          <div>
            <p className="font-semibold">{i.name}</p>
            <p className="text-[11px] text-slate-500">{i.track} · via {i.source}</p>
            <p className="mt-1 text-[11px]">{i.notes}</p>
            <p className="mt-1 text-[10px] uppercase tracking-wider text-slate-400">{i.createdAt} · {i.counselor}</p>
          </div>
        )}
      />
    </AdminShell>
  );
}
