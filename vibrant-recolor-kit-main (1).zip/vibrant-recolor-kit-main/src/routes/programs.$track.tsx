import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { BookDemoDrawer } from "@/components/BookDemoDrawer";
import { LeadModal } from "@/components/LeadModal";
import { FLAGSHIP_TRACKS, findTrack, type FlagshipTrack } from "@/lib/flagship-programs";
import { Squiggle, Asterisk, Arrow } from "@/components/Doodles";
import {
  ArrowUpRight,
  Users,
  ChevronDown,
  X,
  Terminal,
  Server,
  Code2,
  Quote,
} from "lucide-react";
import { useEffect, useState } from "react";
import { coursesForTrack, type TrackCourse } from "@/lib/track-courses";
import { FutureEngineeringPage } from "@/components/FutureEngineeringPage";


export const Route = createFileRoute("/programs/$track")({
  loader: ({ params }): { track: FlagshipTrack } => {
    const track = findTrack(params.track);
    if (!track) throw notFound();
    return { track };
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.track.title} — TekSchool` },
          { name: "description", content: loaderData.track.tagline },
          { property: "og:title", content: `${loaderData.track.title} — TekSchool` },
          { property: "og:description", content: loaderData.track.tagline },
        ]
      : [{ title: "Program — TekSchool" }],
  }),
  component: ProgramTrack,
  notFoundComponent: () => (
    <Shell>
      <div className="px-6 py-24 text-center">
        <Asterisk className="mx-auto h-16 w-16" color="var(--coral)" />
        <h1 className="font-display text-4xl font-bold mt-6">Track not found.</h1>
        <Link
          to="/courses"
          className="mt-6 inline-block rounded-full bg-primary px-5 py-2 text-primary-foreground text-sm font-semibold"
        >
          Browse programs
        </Link>
      </div>
    </Shell>
  ),
});

const toneClass = (c: string) =>
  c === "coral"
    ? "bg-[color:var(--coral)] text-[color:var(--coral-foreground)]"
    : c === "lavender"
    ? "bg-[color:var(--lavender)] text-[color:var(--lavender-foreground)]"
    : c === "blue"
    ? "gradient-blue text-white"
    : "bg-primary text-primary-foreground";

const softToneClass = (c: string) =>
  c === "coral"
    ? "bg-[color:var(--coral)]/15 text-[color:var(--coral-foreground)]"
    : c === "lavender"
    ? "bg-[color:var(--lavender)]/40 text-[color:var(--lavender-foreground)]"
    : c === "blue"
    ? "bg-[color:var(--accent-blue)]/15 text-[color:var(--accent-blue-deep)]"
    : "bg-primary/10 text-primary";

const SECTIONS = [
  { id: "overview", label: "Overview" },
  { id: "fit", label: "Is it for you" },
  { id: "courses", label: "Courses" },
  { id: "curriculum", label: "Curriculum" },
  { id: "projects", label: "Projects" },
  { id: "partners", label: "Partners" },
  { id: "pricing", label: "Pricing" },
  { id: "faq", label: "FAQ" },
];




function CoursesSection({ track }: { track: FlagshipTrack }) {
  const courses = coursesForTrack(track.slug);
  const [openCode, setOpenCode] = useState<string | null>(null);
  const [level, setLevel] = useState<"All" | TrackCourse["level"]>("All");
  const [enquiryCourse, setEnquiryCourse] = useState<string | null>(null);

  const levels: Array<"All" | TrackCourse["level"]> = ["All", "Foundation", "Core", "Advanced", "Capstone"];
  const visible = level === "All" ? courses : courses.filter((c) => c.level === level);
  const totalHours = courses.reduce((n, c) => n + c.hours, 0);
  const totalLessons = courses.reduce((n, c) => n + c.lessons.length, 0);

  if (!courses.length) return null;

  return (
    <Section id="courses">
      <LeadModal
        open={enquiryCourse !== null}
        onClose={() => setEnquiryCourse(null)}
        badge={track.title}
        title={`Ask about ${enquiryCourse ?? "this course"}`}
        subtitle="Share your details and we'll send the syllabus, schedule, and next cohort dates."
        interest={enquiryCourse ?? ""}
        institutionType={track.title}
        cta="Send enquiry"
      />
      <SectionHeading
        eyebrow="Courses"
        title={`Every course inside ${track.title}.`}
        intro="The full module list for this track only — expand any course to see its week-by-week lesson plan."
      />

      <div className="mb-6 grid gap-3 sm:grid-cols-3">
        {[
          { label: "Courses", value: String(courses.length) },
          { label: "Lesson modules", value: `${totalLessons}+` },
          { label: "Guided hours", value: `${totalHours} hrs` },
        ].map((m) => (
          <div key={m.label} className="rounded-2xl border bg-white px-5 py-4">
            <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{m.label}</p>
            <p className="font-display text-2xl font-bold leading-none mt-1.5">{m.value}</p>
          </div>
        ))}
      </div>

      <div className="mb-5 flex flex-wrap gap-2">
        {levels.map((l) => (
          <button
            key={l}
            onClick={() => {
              setLevel(l);
              setOpenCode(null);
              scrollToSection("courses");
            }}

            className={`rounded-full px-4 py-1.5 text-sm font-semibold transition-colors ${
              level === l ? "bg-primary text-primary-foreground" : "border bg-white text-muted-foreground hover:text-foreground"
            }`}
          >
            {l}
          </button>
        ))}
      </div>

      <ol className="grid gap-4">
        {visible.map((c, i) => {
          const open = openCode === c.code;
          return (
            <li
              key={c.code}
              id={`course-${c.code}`}
              className="scroll-mt-[142px] rounded-3xl border bg-white overflow-hidden"
            >
              <button
                onClick={() => {
                  const next = open ? null : c.code;
                  setOpenCode(next);
                  if (next) {
                    // Keep the opened course pinned under the sticky nav so the
                    // expanded lesson plan never pushes the header out of view.
                    window.setTimeout(() => {
                      document
                        .getElementById(`course-${c.code}`)
                        ?.scrollIntoView({ behavior: "smooth", block: "start" });
                    }, 80);
                  }
                }}
                aria-expanded={open}
                className="w-full text-left p-6 flex flex-wrap items-start gap-4 hover:bg-muted/40 transition-colors"
              >

                <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-sm font-bold ${toneClass(track.color)}`}>
                  {String(i + 1).padStart(2, "0")}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="pill-tag bg-muted text-muted-foreground text-[11px]">{c.code}</span>
                    <span className={`pill-tag ${softToneClass(track.color)} text-[11px]`}>{c.level}</span>
                    <span className="text-xs font-semibold text-muted-foreground">{c.duration} · {c.hours} hrs</span>
                  </div>
                  <h3 className="font-display text-xl md:text-2xl font-bold mt-2 leading-snug">{c.title}</h3>
                  <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed max-w-2xl">{c.summary}</p>
                </div>
                <ChevronDown className={`h-5 w-5 shrink-0 mt-1 transition-transform ${open ? "rotate-180" : ""}`} />
              </button>

              {open && (
                <div className="border-t border-border/60 px-6 pb-6 pt-5 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
                  <div>
                    <h4 className="font-display text-base font-bold">Lesson plan</h4>
                    <ol className="mt-3 space-y-3">
                      {c.lessons.map((l) => (
                        <li key={l.week} className="rounded-2xl border bg-background/60 p-4">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="pill-tag bg-primary text-primary-foreground text-[11px]">{l.week}</span>
                            <p className="font-semibold text-sm">{l.title}</p>
                          </div>
                          <ul className="mt-2.5 grid sm:grid-cols-2 gap-2 text-sm">
                            {l.topics.map((t) => (
                              <li key={t} className="flex items-start gap-2">
                                <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-[color:var(--accent-blue-deep)] shrink-0" />
                                <span className="text-muted-foreground">{t}</span>
                              </li>
                            ))}
                          </ul>
                          {l.deliverable && (
                            <p className="mt-2.5 text-xs font-semibold text-[color:var(--accent-blue-deep)]">
                              Deliverable · {l.deliverable}
                            </p>
                          )}
                        </li>
                      ))}
                    </ol>
                  </div>

                  <div className="space-y-5">
                    <div>
                      <h4 className="font-display text-base font-bold">What you walk away with</h4>
                      <ul className="mt-3 space-y-2.5">
                        {c.outcomes.map((o) => (
                          <li key={o} className="flex gap-2.5 text-sm leading-relaxed">
                            <span className="mt-1.5 h-2 w-2 rounded-full bg-[color:var(--accent-blue-deep)] shrink-0" />
                            <span>{o}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-display text-base font-bold">Tools used</h4>
                      <div className="mt-3 flex flex-wrap gap-2">
                        {c.tools.map((t) => (
                          <span key={t} className={`pill-tag ${softToneClass(track.color)} text-xs`}>{t}</span>
                        ))}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setEnquiryCourse(c.title)}
                      data-cursor="enroll"
                      className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
                    >
                      Ask about this course <ArrowUpRight className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              )}
            </li>
          );
        })}
      </ol>
    </Section>
  );
}

function Section({
  id,
  children,
  className = "",
}: {
  id?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section
      id={id}
      className={`scroll-mt-[142px] border-t border-border/60 px-4 md:px-10 py-10 md:py-14 ${className}`}
    >
      <div className="mx-auto w-full max-w-6xl">{children}</div>
    </section>
  );
}

function SectionHeading({
  eyebrow,
  title,
  intro,
}: {
  eyebrow: string;
  title: string;
  intro?: string;
}) {
  return (
    <header className="max-w-2xl mb-7 md:mb-9">
      <p className="pill-tag bg-muted text-muted-foreground mb-3"># {eyebrow}</p>
      <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tight">{title}</h2>
      {intro && <p className="mt-2.5 text-muted-foreground leading-relaxed">{intro}</p>}
    </header>
  );
}

export const NAV_OFFSET = 142; // sticky TopNav + section nav

export function scrollToSection(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  const top = el.getBoundingClientRect().top + window.scrollY - NAV_OFFSET;
  window.scrollTo({ top: Math.max(top, 0), behavior: "smooth" });
}

function SectionNav() {
  const [active, setActive] = useState(SECTIONS[0].id);

  useEffect(() => {
    const onScroll = () => {
      const probe = NAV_OFFSET + 24;
      let current = SECTIONS[0].id;
      for (const s of SECTIONS) {
        const el = document.getElementById(s.id);
        if (!el) continue;
        if (el.getBoundingClientRect().top <= probe) current = s.id;
      }
      // Last section wins when the page is scrolled to the very bottom.
      if (window.innerHeight + window.scrollY >= document.body.scrollHeight - 4) {
        const last = SECTIONS.filter((s) => document.getElementById(s.id)).pop();
        if (last) current = last.id;
      }
      setActive(current);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  return (
    <div className="sticky top-[88px] z-30 border-y border-border/60 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/85">
      <nav
        aria-label="Program sections"
        className="mx-auto flex w-full max-w-6xl items-center gap-1 overflow-x-auto px-4 md:px-10 py-2"
      >


        {SECTIONS.map((s) => (
          <a
            key={s.id}
            href={`#${s.id}`}
            onClick={(e) => {
              e.preventDefault();
              setActive(s.id);
              scrollToSection(s.id);
            }}
            aria-current={active === s.id ? "page" : undefined}
            className={`whitespace-nowrap rounded-full px-4 py-1.5 text-sm font-semibold transition-colors ${
              active === s.id
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:bg-muted hover:text-foreground"
            }`}
          >
            {s.label}
          </a>
        ))}
      </nav>
    </div>
  );
}


function StickyEnroll({ track }: { track: FlagshipTrack }) {
  const [show, setShow] = useState(false);
  const [enrollOpen, setEnrollOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 700);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div
      className={`fixed inset-x-0 bottom-0 z-40 transition-transform duration-300 ${
        show ? "translate-y-0" : "translate-y-full"
      }`}
    >
      <div className="bg-primary text-primary-foreground shadow-[0_-10px_30px_rgba(0,0,0,0.15)]">
        <div className="mx-auto flex w-full max-w-6xl flex-wrap items-center gap-3 px-4 md:px-10 py-3">
          <span className="text-sm font-semibold">
            {track.title} ·{" "}
            <span className="opacity-60 line-through">₹{track.price.original.toLocaleString("en-IN")}</span>{" "}
            ₹{track.price.total.toLocaleString("en-IN")}
          </span>
          <span className="rounded-full bg-white/12 px-3 py-1 text-xs">
            Pay in EMI
          </span>
          <span className="hidden sm:inline-flex items-center gap-1.5 rounded-full bg-white/12 px-3 py-1 text-xs">
            <Users className="h-3.5 w-3.5" /> {track.seatsLeft} seats left · {track.nextCohort}
          </span>
          <button
            type="button"
            onClick={() => setEnrollOpen(true)}
            data-cursor="enroll"
            className="ml-auto rounded-full bg-white text-primary px-5 py-2.5 text-sm font-semibold whitespace-nowrap"
          >
            Enroll now
          </button>
          <LeadModal
            open={enrollOpen}
            onClose={() => setEnrollOpen(false)}
            badge={track.title}
            title="Reserve your seat"
            subtitle="Share your details and our admissions team will confirm your seat and payment options."
            interest={track.title}
            institutionType={track.title}
            cta="Reserve my seat"
          />
        </div>
      </div>
    </div>
  );
}


function ProgramTrack() {
  const { track } = Route.useLoaderData() as { track: FlagshipTrack };
  const others = FLAGSHIP_TRACKS.filter(
    (t) => t.slug !== track.slug && t.slug !== "future-engineering"
  );
  const [demoOpen, setDemoOpen] = useState(false);
  const [reserveOpen, setReserveOpen] = useState(false);

  if (track.slug === "future-engineering") return <FutureEngineeringPage track={track} />;



  return (
    <Shell>
      {/* ── HERO ─────────────────────────────────────────── */}
      <section className="relative overflow-hidden px-4 md:px-10 pt-6 pb-10 md:pb-12">
        <Squiggle className="pointer-events-none absolute right-8 top-4 h-20 w-48 opacity-40" />

        <div className="mx-auto grid w-full max-w-6xl gap-8 lg:gap-10 lg:grid-cols-[1.05fr_1fr] items-center">
          <div>
            <span className={`pill-tag ${toneClass(track.color)} text-xs mb-4 inline-flex`}>
              # {track.eyebrow}
            </span>
            <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold leading-[0.95] tracking-tight">
              {track.title.split(" ").map((word, i, arr) => (
                <span key={i}>
                  {i === arr.length - 1 ? (
                    <span className="bg-gradient-to-br from-[color:var(--accent-blue)] to-[color:var(--accent-blue-deep)] bg-clip-text text-transparent">
                      {word}
                    </span>
                  ) : (
                    word
                  )}
                  {i < arr.length - 1 ? " " : ""}
                </span>
              ))}
            </h1>
            <p className="mt-4 text-muted-foreground max-w-xl leading-relaxed">
              {track.tagline}
            </p>

            <dl className="mt-6 grid gap-px overflow-hidden rounded-2xl border bg-border sm:grid-cols-3">
              {[
                { label: "Duration", value: track.duration },
                { label: "Format", value: track.format },
                { label: "Next cohort", value: track.nextCohort },
              ].map((m) => (
                <div key={m.label} className="bg-white px-4 py-3">
                  <dt className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    {m.label}
                  </dt>
                  <dd className="mt-0.5 text-sm font-semibold leading-snug">{m.value}</dd>
                </div>
              ))}
            </dl>

            <div className="mt-6 flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={() => setDemoOpen(true)}
                data-cursor="enroll"
                className="inline-flex items-center gap-2 rounded-full bg-primary text-primary-foreground px-6 py-3 text-sm font-semibold hover:bg-primary/90"
              >
                Register for free demo <ArrowUpRight className="h-4 w-4" />
              </button>
              <a
                href="#curriculum"
                className="inline-flex items-center gap-2 rounded-full border px-6 py-3 text-sm font-semibold hover:bg-muted"
              >
                See curriculum <ChevronDown className="h-4 w-4" />
              </a>
              <span className="pill-tag bg-[color:var(--coral)] text-[color:var(--coral-foreground)]">
                <Users className="h-3.5 w-3.5" /> {track.seatsLeft} of {track.seatsTotal} seats left
              </span>
            </div>

            <p className="mt-4 text-xs text-muted-foreground">
              Join 5,000+ students who found their dream job · 100+ developer-trainers · 200+ industry mentors
            </p>
          </div>

          <SignatureMockup track={track} />
        </div>
      </section>

      <SectionNav />

      {/* ── OVERVIEW: promise + stats ────────────────────── */}
      <Section id="overview">
        <div
          className={`rounded-[2rem] px-6 md:px-8 py-6 md:py-7 flex flex-col md:flex-row items-start md:items-center gap-5 ${toneClass(
            track.color
          )}`}
        >
          <Quote className="h-8 w-8 shrink-0 opacity-70" />
          <p className="font-display text-2xl md:text-[1.7rem] font-bold leading-tight">
            {track.signaturePromise}
          </p>
        </div>

        <div className="mt-4 grid gap-4 md:grid-cols-3">
          <StatCard label={track.statLabels?.placement ?? "Job placement"} value={track.stats.placement} tone="coral" />
          <StatCard label={track.statLabels?.salary ?? "Starting salary range"} value={track.stats.salary} tone="blue" />
          <StatCard label={track.statLabels?.partners ?? "Hiring partners / support"} value={track.stats.partners} tone="lavender" />
        </div>

        <div className="mt-4 grid gap-3 md:grid-cols-3">
          {[
            {
              title: "AI-powered learning platform",
              desc: "Self-paced modules blended with expert mentorship for a personalised, job-ready path.",
            },
            {
              title: "Industry-driven curriculum",
              desc: "Designed with working tech experts — live projects, hands-on labs, real case studies.",
            },
            {
              title: "Internship & placement support",
              desc: "Career coaching, profile reviews, and exclusive openings with hiring partners.",
            },
          ].map((p) => (
            <div key={p.title} className="rounded-2xl border bg-white p-5">
              <h3 className="font-display text-base font-bold leading-snug">{p.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">{p.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-8">
          <h3 className="font-display text-xl font-bold">What's included</h3>
          <div className="mt-3 grid gap-3 md:grid-cols-2">
            {track.highlights.map((h) => (
              <div key={h} className="rounded-2xl border bg-white p-4 flex items-start gap-3">
                <span className="mt-1.5 h-2 w-2 rounded-full bg-[color:var(--accent-blue-deep)] shrink-0" />
                <p className="text-sm leading-relaxed">{h}</p>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* ── FIT + TRANSFORMATION ─────────────────────────── */}
      <Section id="fit">
        <SectionHeading
          eyebrow="Honest filter"
          title="Is this the right room for you?"
          intro="We'd rather you self-select out now than three months in."
        />
        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-[2rem] border bg-white p-6">
            <span className={`pill-tag ${toneClass(track.color)} text-xs`}># Perfect if</span>
            <ul className="mt-5 space-y-3.5">
              {track.perfectFor.map((p) => (
                <li key={p} className="flex gap-3 text-sm leading-relaxed">
                  <span className="mt-1.5 h-2 w-2 rounded-full bg-[color:var(--accent-blue-deep)] shrink-0" />
                  <span>{p}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-[2rem] border bg-muted/40 p-6">
            <span className="pill-tag bg-white text-muted-foreground text-xs border">
              # Not for you if
            </span>
            <ul className="mt-5 space-y-3.5">
              {track.notForYou.map((n) => (
                <li key={n} className="flex gap-3 text-sm leading-relaxed">
                  <X className="h-5 w-5 text-muted-foreground mt-0.5 shrink-0" />
                  <span>{n}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

      </Section>

      {/* ── COURSES IN THIS TRACK ───────────────────────── */}
      <CoursesSection track={track} />



      {/* ── CURRICULUM ──────────────────────────────────── */}
      <Section id="curriculum">
        <SectionHeading
          eyebrow="Curriculum"
          title={`How the ${track.duration.split(" +")[0]} flows.`}
          intro="Four phases, each ending in something you can show."
        />

        <div className="mb-6 grid gap-4 md:grid-cols-[1fr_auto_1fr] items-stretch">
          <div className="rounded-[2rem] border bg-white p-6 flex min-h-40 flex-col justify-between">
            <span className="pill-tag bg-muted text-muted-foreground text-xs">Start</span>
            <p className="font-display text-xl md:text-2xl font-bold leading-snug mt-4">
              {track.weekTransformation.before}
            </p>
          </div>
          <div className="hidden md:flex items-center justify-center">
            <Arrow className="h-20 w-20" />
          </div>
          <div className={`rounded-[2rem] p-6 min-h-40 flex flex-col justify-between ${toneClass(track.color)}`}>
            <span className="pill-tag bg-white/25 text-current text-xs">Finish</span>
            <p className="font-display text-xl md:text-2xl font-bold leading-snug mt-4">
              {track.weekTransformation.after}
            </p>
          </div>
        </div>

        <ol className="grid gap-4">
          {track.curriculum.map((c, i) => (
            <li
              key={c.phase}
              className="rounded-3xl border bg-white p-6 grid md:grid-cols-[minmax(0,1fr)_2fr] gap-6"
            >
              <div>
                <span className={`pill-tag ${toneClass(track.color)} text-xs`}>Phase 0{i + 1}</span>
                <h3 className="font-display text-2xl font-bold mt-3">{c.phase}</h3>
                <p className="text-sm text-muted-foreground mt-1">{c.weeks}</p>
              </div>
              <ul className="grid sm:grid-cols-2 gap-2.5 text-sm self-center">
                {c.topics.map((t) => (
                  <li key={t} className="flex items-start gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-[color:var(--accent-blue-deep)] shrink-0" />
                    <span>{t}</span>
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ol>

        <div className="mt-8">
          <h3 className="font-display text-xl font-bold">Stack you'll master</h3>
          <div className="mt-3 grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
            {track.tools.map((t) => (
              <span key={t} className={`pill-tag ${softToneClass(track.color)} text-sm justify-center`}>
                {t}
              </span>
            ))}
          </div>
        </div>
      </Section>

      {/* ── PROJECTS + OUTCOMES ─────────────────────────── */}
      <Section id="projects">
        <SectionHeading
          eyebrow="What you'll ship"
          title="Real projects. Real users. Real receipts."
        />
        <div className="grid gap-4 md:grid-cols-3">
          {track.sampleProjects.map((p, i) => (
            <article key={p.title} className="rounded-[2rem] border bg-white p-6 flex flex-col">
              <span className={`pill-tag ${softToneClass(track.color)} text-xs self-start`}>
                Project 0{i + 1}
              </span>
              <h3 className="font-display text-xl font-bold mt-4 leading-snug">{p.title}</h3>
              <p className="text-sm text-muted-foreground mt-3 leading-relaxed">{p.desc}</p>
              <p className="mt-auto pt-5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                {p.stack}
              </p>
            </article>
          ))}
        </div>

      </Section>

      {/* ── HIRING PARTNERS ─────────────────────────────── */}
      <Section id="partners">
        <div className="rounded-[2rem] bg-primary text-primary-foreground p-7 md:p-9 relative overflow-hidden">
          <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full gradient-blue opacity-40 blur-2xl" />
          <div className="relative">
            <p className="pill-tag bg-white/15 text-white/90 mb-3">
              {track.partners?.eyebrow ?? "# Where graduates go"}
            </p>
            <h3 className="font-display text-2xl md:text-3xl font-bold max-w-xl">
              {track.partners?.heading ?? "Cohort '25 placed into teams like these."}
            </h3>
            <div className="mt-6 flex flex-wrap gap-2.5">
              {track.outcomeCompanies.map((co) => (
                <span
                  key={co}
                  className="pill-tag bg-white/12 text-white border border-white/15 text-sm px-4 py-2"
                >
                  {co}
                </span>
              ))}
            </div>
            <p className="text-xs text-white/60 mt-6">
              {track.partners?.note ??
                "Hiring partners on record. Exact placements vary by cohort and role fit."}
            </p>
          </div>
        </div>

      </Section>

      {/* ── PRICING ─────────────────────────────────────── */}
      <Section id="pricing">
        <SectionHeading eyebrow="Pricing" title="One fee. No surprises." />
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Light card — original fee */}
          <div className="relative rounded-[2rem] bg-[color:var(--lavender)] text-[color:var(--lavender-foreground)] p-7 overflow-hidden">
            <div className="absolute -right-10 -bottom-10 h-48 w-48 rounded-full gradient-blue opacity-20" />
            <div className="relative">
            <p className="text-sm font-semibold opacity-70">Original program fee</p>
            <p className="font-display text-5xl md:text-6xl font-bold mt-2">
              ₹{track.price.original.toLocaleString("en-IN")}
            </p>
            <p className="mt-2 text-sm opacity-80">
              Pay the full program fee upfront. No hidden charges.
            </p>
            <div className="mt-6 space-y-2 text-sm opacity-90">
              <p className="flex items-start gap-2">
                <span className="mt-1.5 h-2 w-2 rounded-full bg-[color:var(--accent-blue-deep)] shrink-0" />
                Includes internship placement
              </p>
              <p className="flex items-start gap-2">
                <span className="mt-1.5 h-2 w-2 rounded-full bg-[color:var(--accent-blue-deep)] shrink-0" />
                12-month placement support
              </p>
              <p className="flex items-start gap-2">
                <span className="mt-1.5 h-2 w-2 rounded-full bg-[color:var(--accent-blue-deep)] shrink-0" />
                All exam vouchers and cloud credits
              </p>
            </div>
            </div>
          </div>

          {/* Dark card — offer fee */}
          <div className="relative rounded-[2rem] bg-primary text-primary-foreground p-7 overflow-hidden">
            {/* price-tag discount badge */}
            <div className="absolute -top-3 -right-3 z-10 drop-shadow-[0_10px_20px_rgba(0,0,0,0.3)]">
              <svg width="110" height="145" viewBox="0 0 120 160" fill="none" aria-hidden="true" className="rotate-[24deg]">
                {/* tag body */}
                <path
                  d="M60 4c5 0 9 2 12 6l38 50a8 8 0 0 1 1 7l-26 74a8 8 0 0 1-7 5H42a8 8 0 0 1-7-5L9 67a8 8 0 0 1 1-7l38-50c3-4 7-6 12-6Z"
                  fill="#E8262D"
                />
                {/* tag outline */}
                <path
                  d="M60 4c5 0 9 2 12 6l38 50a8 8 0 0 1 1 7l-26 74a8 8 0 0 1-7 5H42a8 8 0 0 1-7-5L9 67a8 8 0 0 1 1-7l38-50c3-4 7-6 12-6Z"
                  stroke="#C41E24"
                  strokeWidth="1.5"
                />
                {/* string hole */}
                <circle cx="60" cy="22" r="7" fill="#1a1a2e" />
                <circle cx="60" cy="22" r="3.5" fill="#E8262D" />
                {/* string loop */}
                <path
                  d="M60 15c0-8 6-13 10-13s8 5 8 11c0 5-3 9-6 10"
                  stroke="#4a4a55"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  fill="none"
                />
                {/* highlight sheen */}
                <path
                  d="M35 30c8-4 18-6 28-6s20 2 28 6l-8 22c-6-3-13-4-20-4s-14 1-20 4L35 30Z"
                  fill="#fff"
                  opacity="0.12"
                />
                <text
                  x="60" y="90" fill="#fff" fontSize="34" fontWeight="900"
                  textAnchor="middle" fontFamily="inherit"
                >
                  {track.price.discountPct}%
                </text>
                <text
                  x="60" y="118" fill="#fff" fontSize="20" fontWeight="800"
                  textAnchor="middle" fontFamily="inherit" letterSpacing="0.06em"
                >
                  OFF
                </text>
              </svg>
            </div>


            <div className="absolute -right-10 -bottom-10 h-48 w-48 rounded-full gradient-blue opacity-60" />
            <div className="relative">
              <p className="text-sm opacity-70">Limited offer fee</p>
              <p className="font-display text-5xl md:text-6xl font-bold mt-2">
                ₹{track.price.total.toLocaleString("en-IN")}
              </p>

              <p className="text-sm font-semibold text-[color:var(--coral)] mt-1">
                You save ₹{(track.price.original - track.price.total).toLocaleString("en-IN")}
              </p>
              <p className="text-sm opacity-80 mt-1">Offer valid till {track.price.offerEnds}</p>
              <div className="mt-6 space-y-1 text-sm opacity-90">
                <p>✓ Includes internship placement</p>
                <p>✓ 12-month placement support</p>
                <p>✓ All exam vouchers and cloud credits</p>
              </div>
              <button
                type="button"
                onClick={() => setReserveOpen(true)}
                data-cursor="enroll"
                className="mt-6 inline-flex items-center gap-2 rounded-full bg-white text-primary px-6 py-3 text-sm font-semibold"
              >
                Reserve your seat <ArrowUpRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </Section>

      {/* ── FAQ ─────────────────────────────────────────── */}
      <Section id="faq">
        <SectionHeading eyebrow="FAQ" title="Answers to the real questions." />
        <div className="max-w-3xl divide-y border-y">
          {track.faqs.map((f, i) => (
            <FAQItem key={i} q={f.q} a={f.a} />
          ))}
        </div>
      </Section>

      {/* ── CROSS-LINK ──────────────────────────────────── */}
      <Section>
        <SectionHeading eyebrow="Other flagship tracks" title="Compare the other paths." />
        <div className="grid gap-4 md:grid-cols-2">
          {others.map((o) => (
            <Link
              key={o.slug}
              to="/programs/$track"
              params={{ track: o.slug }}
              data-cursor="view"
              className="group rounded-3xl border bg-white p-6 hover:border-primary transition-colors"
            >
              <span className={`pill-tag ${toneClass(o.color)} text-xs`}>{o.eyebrow}</span>
              <h3 className="font-display text-2xl font-bold mt-3">{o.title}</h3>
              <p className="text-sm text-muted-foreground mt-2">{o.tagline}</p>
              <p className="mt-4 text-sm font-semibold inline-flex items-center gap-1">
                View program{" "}
                <ArrowUpRight className="h-4 w-4 group-hover:translate-x-0.5 transition-transform" />
              </p>
            </Link>
          ))}
        </div>
      </Section>

      {/* Sticky enroll */}
      <StickyEnroll track={track} />

      <BookDemoDrawer
        open={demoOpen}
        onClose={() => setDemoOpen(false)}
        variant="modal"
        presetProgram={track.title}
        heading="Register for free demo"
        workshopTitle={track.title}
      />

      <LeadModal
        open={reserveOpen}
        onClose={() => setReserveOpen(false)}
        badge={track.title}
        title="Reserve your seat"
        subtitle="Share your details and our admissions team will confirm your seat and payment options."
        interest={track.title}
        institutionType={track.title}
        cta="Reserve my seat"
      />

    </Shell>
  );
}


/* ─────────────────────────────────────────────────────── */
/*  Per-track SIGNATURE MOCKUP — this is the hero visual   */
/* ─────────────────────────────────────────────────────── */
function SignatureMockup({ track }: { track: FlagshipTrack }) {
  return (
    <div className="relative">
      {/* Layered shadow stack for depth */}
      <div
        className="absolute inset-0 rounded-[2rem] bg-primary/20 translate-x-3 translate-y-4 blur-xl"
        aria-hidden
      />
      <div
        className="absolute inset-0 rounded-[2rem] bg-[color:var(--accent-blue)]/10 -translate-x-2 -translate-y-2"
        aria-hidden
      />

      <div
        className="relative rounded-[2rem] bg-primary text-primary-foreground p-4 md:p-5 overflow-hidden"
        style={{ clipPath: "polygon(0 0, 100% 0, 100% 88%, 88% 100%, 0 100%)" }}
      >
        {/* Fake window chrome */}
        <div className="flex items-center gap-2 px-2 py-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-[color:var(--coral)]" />
          <span className="h-2.5 w-2.5 rounded-full bg-[color:var(--lavender)]" />
          <span className="h-2.5 w-2.5 rounded-full bg-[color:var(--accent-blue)]" />
          <span className="ml-3 text-[11px] font-mono text-white/50 truncate">
            {track.slug === "ai-engineering"
              ? "~/tekschool/rag-legal-assistant"
              : track.slug === "cloud-engineering"
              ? "~/tekschool/prod-cluster · kubectl"
              : "~/tekschool/collab-editor · main"}
          </span>
        </div>

        <div className="mt-2 rounded-2xl bg-black/25 p-4 md:p-5 min-h-[22rem] backdrop-blur-sm">
          {track.slug === "ai-engineering" && <AIMock />}
          {track.slug === "cloud-engineering" && <CloudMock />}
          {track.slug === "software-engineering" && <SWEMock />}
        </div>

        {/* Floating sticker */}
        <span
          className={`pill-tag absolute right-6 top-6 -rotate-6 bg-white text-primary shadow-lg`}
        >
          # {track.title}
        </span>
      </div>

      {/* Floating stat sticker */}
      <div
        className="absolute -bottom-4 -left-4 rounded-2xl bg-white border p-3 shadow-lg -rotate-3"
        aria-hidden
      >
        <p className="text-[10px] font-semibold uppercase text-muted-foreground">
          {track.proofSticker?.label ?? "Cohort '25"}
        </p>
        <p className="font-display text-lg font-bold">
          {track.proofSticker?.value ?? `${track.stats.placement} placed`}
        </p>
      </div>
    </div>
  );
}

function AIMock() {
  return (
    <div className="space-y-3 font-mono text-[12px]">
      <div className="flex items-center gap-2 text-[color:var(--accent-blue)]">
        <Terminal className="h-3.5 w-3.5" />
        <span>chain.invoke("Summarise clause 4 of the MSA")</span>
      </div>
      <div className="rounded-xl bg-white/8 p-3 space-y-2">
        <p className="text-[11px] text-white/50">
          Retrieving from pinecone · 4 matches · avg score 0.87
        </p>
        <div className="grid grid-cols-4 gap-1.5">
          {[0.94, 0.89, 0.83, 0.81].map((s, i) => (
            <div key={i} className="rounded-md bg-[color:var(--accent-blue)]/25 px-2 py-1.5 text-center">
              <p className="text-[9px] text-white/60">chunk_{i + 1}</p>
              <p className="text-white font-semibold">{s}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="rounded-xl bg-white/10 p-3 text-white/90 leading-relaxed">
        <span className="text-[color:var(--coral)]">assistant ›</span> Clause 4 caps liability at fees
        paid in the prior 12 months, excluding gross negligence. See §4.2 for carve-outs
        <span className="ml-1 inline-block w-1.5 h-3 bg-white/80 align-middle animate-pulse" />
      </div>
      <div className="flex gap-2 text-[10px] text-white/50">
        <span className="rounded-full bg-white/10 px-2 py-0.5">latency 412ms</span>
        <span className="rounded-full bg-white/10 px-2 py-0.5">tokens 284</span>
        <span className="rounded-full bg-white/10 px-2 py-0.5">cost $0.0021</span>
      </div>
    </div>
  );
}

function CloudMock() {
  return (
    <div className="space-y-3 font-mono text-[12px]">
      <div className="flex items-center gap-2 text-[color:var(--accent-blue)]">
        <Server className="h-3.5 w-3.5" />
        <span>kubectl get pods -n prod --watch</span>
      </div>
      <div className="rounded-xl bg-white/8 p-3 space-y-1.5">
        {[
          { name: "api-gw-7d9c", status: "Running", age: "3d", cpu: "42%" },
          { name: "worker-a1f2", status: "Running", age: "3d", cpu: "68%" },
          { name: "worker-b3e4", status: "Running", age: "3d", cpu: "71%" },
          { name: "cache-2d1c", status: "Running", age: "5d", cpu: "18%" },
          { name: "canary-8f0e", status: "Pending", age: "12s", cpu: "—" },
        ].map((p) => (
          <div key={p.name} className="grid grid-cols-4 gap-2 text-[11px] text-white/80">
            <span className="truncate">{p.name}</span>
            <span
              className={
                p.status === "Running"
                  ? "text-[color:var(--accent-blue)]"
                  : "text-[color:var(--coral)]"
              }
            >
              {p.status}
            </span>
            <span className="text-white/50">{p.age}</span>
            <span className="text-white/70">{p.cpu}</span>
          </div>
        ))}
      </div>
      <div className="rounded-xl bg-white/10 p-3">
        <p className="text-[10px] text-white/50 mb-1.5">SLO burn (last 1h)</p>
        <div className="h-8 flex items-end gap-1">
          {[3, 5, 4, 7, 6, 4, 8, 12, 9, 6, 5, 4].map((h, i) => (
            <div
              key={i}
              className="flex-1 rounded-t bg-[color:var(--accent-blue)]/70"
              style={{ height: `${h * 6}%` }}
            />
          ))}
        </div>
      </div>
      <p className="text-[10px] text-white/50">
        99.94% availability · error budget 68% remaining
      </p>
    </div>
  );
}

function SWEMock() {
  return (
    <div className="space-y-2 font-mono text-[12px]">
      <div className="flex items-center gap-2 text-[color:var(--accent-blue)]">
        <Code2 className="h-3.5 w-3.5" />
        <span>src/booking/create.ts</span>
      </div>
      <div className="rounded-xl bg-white/8 p-3 space-y-0.5 text-[11px] leading-relaxed">
        <p className="text-white/40">
          <span className="mr-3">1</span>
          <span className="text-[color:var(--lavender)]">export async function</span>{" "}
          <span className="text-[color:var(--accent-blue)]">createBooking</span>(input: BookingInput) &#123;
        </p>
        <p className="text-white/40">
          <span className="mr-3">2</span>{" "}
          <span className="text-white/70">const key = idempotencyKey(input);</span>
        </p>
        <p className="text-white/40">
          <span className="mr-3">3</span>{" "}
          <span className="text-white/70">
            const existing = <span className="text-[color:var(--coral)]">await</span> db.bookings.byKey(key);
          </span>
        </p>
        <p className="bg-[color:var(--accent-blue)]/15 -mx-3 px-3 text-white">
          <span className="mr-3 text-white/40">4</span>{" "}
          if (existing) return existing;{" "}
          <span className="text-[color:var(--coral)] ml-2">// dedupe retries</span>
        </p>
        <p className="text-white/40">
          <span className="mr-3">5</span>{" "}
          <span className="text-white/70">
            return db.transaction(() =&gt; charge(input) &amp;&amp; hold(input));
          </span>
        </p>
        <p className="text-white/40">
          <span className="mr-3">6</span>&#125;
        </p>
      </div>
      <div className="grid grid-cols-3 gap-2 text-[10px] text-white/60">
        <div className="rounded-lg bg-white/10 px-2 py-1.5">
          <p className="text-white/40">tests</p>
          <p className="text-white font-semibold">42 / 42 ✓</p>
        </div>
        <div className="rounded-lg bg-white/10 px-2 py-1.5">
          <p className="text-white/40">coverage</p>
          <p className="text-white font-semibold">96%</p>
        </div>
        <div className="rounded-lg bg-white/10 px-2 py-1.5">
          <p className="text-white/40">CI</p>
          <p className="text-[color:var(--accent-blue)] font-semibold">deploy → prod</p>
        </div>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone: "coral" | "blue" | "lavender";
}) {
  const cls =
    tone === "coral"
      ? "bg-[color:var(--coral)] text-[color:var(--coral-foreground)]"
      : tone === "blue"
      ? "gradient-blue text-white"
      : "bg-[color:var(--lavender)] text-[color:var(--lavender-foreground)]";
  return (
    <div className={`rounded-3xl p-6 ${cls}`}>
      <p className="text-xs font-semibold opacity-80 uppercase tracking-wide">{label}</p>
      <p className="font-display text-4xl md:text-5xl font-bold mt-2">{value}</p>
    </div>
  );
}

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="py-5">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between gap-4 text-left"
        aria-expanded={open}
      >
        <span className="font-display text-lg font-bold">{q}</span>
        <ChevronDown className={`h-5 w-5 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{a}</p>
      )}
    </div>
  );
}
