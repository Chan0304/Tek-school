import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell, NavyCard, SectionTitle } from "@/components/mobile/AppShell";
import { CLASSES, formatDate } from "@/lib/dashboard-data";
import { Play, CheckCircle2, Calendar, List } from "lucide-react";

export const Route = createFileRoute("/app/classes")({
  head: () => ({ meta: [{ title: "Classes — TekSchool" }, { name: "robots", content: "noindex" }] }),
  component: ClassesScreen,
});

function ClassesScreen() {
  const [view, setView] = useState<"list" | "calendar">("list");
  const upcoming = CLASSES.filter((c) => c.status === "upcoming").sort((a, b) => a.date.localeCompare(b.date));
  const past = CLASSES.filter((c) => c.status !== "upcoming");

  return (
    <AppShell title="Classes">
      <div className="mx-5 mt-4 inline-flex rounded-full bg-slate-200/70 p-1 text-xs font-semibold">
        <button onClick={() => setView("list")} className={`inline-flex items-center gap-1 rounded-full px-3 py-1.5 ${view === "list" ? "bg-white text-slate-900 shadow" : "text-slate-500"}`}><List className="h-3 w-3" /> List</button>
        <button onClick={() => setView("calendar")} className={`inline-flex items-center gap-1 rounded-full px-3 py-1.5 ${view === "calendar" ? "bg-white text-slate-900 shadow" : "text-slate-500"}`}><Calendar className="h-3 w-3" /> Calendar</button>
      </div>

      {view === "calendar" ? (
        <div className="mx-5 mt-4 rounded-3xl bg-white p-5">
          <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">This week</p>
          <div className="mt-3 grid grid-cols-7 gap-1 text-center">
            {["M","T","W","T","F","S","S"].map((d, i) => (
              <div key={i}>
                <p className="text-[10px] font-semibold text-slate-400">{d}</p>
                <div className={`mx-auto mt-1 grid h-9 w-9 place-items-center rounded-full text-xs font-bold ${i === 2 ? "bg-[#1E1B4B] text-white" : "text-slate-700"}`}>{10 + i}</div>
                {upcoming[i] && <span className="mx-auto mt-1 block h-1 w-1 rounded-full bg-[#F4A261]" />}
              </div>
            ))}
          </div>
        </div>
      ) : null}

      <div className="mt-6">
        <SectionTitle title="Upcoming & Live" />
        <div className="space-y-3 px-5">
          {upcoming.map((c, i) => (
            <Link key={c.id} to="/app/class/$id" params={{ id: c.id }} className="block">
              <NavyCard
                live={i === 0}
                eyebrow={i === 0 ? "Next Class · Today" : c.module}
                title={c.topic}
                subtitle={`with ${c.instructor} · ${formatDate(c.date)}`}
                action={<span className="inline-flex items-center gap-1.5 rounded-full bg-white px-4 py-2 text-xs font-bold text-[#1E1B4B]"><Play className="h-3 w-3 fill-current" /> Join</span>}
              />
            </Link>
          ))}
        </div>
      </div>

      <div className="mt-6">
        <SectionTitle title="Recorded" />
        <div className="space-y-3 px-5">
          {past.map((c) => (
            <Link key={c.id} to="/app/class/$id" params={{ id: c.id }} className="block rounded-3xl bg-white p-5 shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)]">
              <div className="flex items-center gap-2">
                {c.status === "completed" ? <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" /> : <span className="h-1.5 w-1.5 rounded-full bg-[#F4A261]" />}
                <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">{c.status === "completed" ? "Watched" : "Missed · recording ready"}</p>
              </div>
              <h3 className="mt-2 font-display text-base font-bold leading-snug text-slate-900">{c.topic}</h3>
              <p className="mt-1 text-[11px] text-slate-500">{c.instructor} · {c.duration}</p>
              {c.progress !== undefined && (
                <div className="mt-3 h-1.5 rounded-full bg-slate-100">
                  <div className="h-full rounded-full bg-[#1E1B4B]" style={{ width: `${c.progress}%` }} />
                </div>
              )}
            </Link>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
