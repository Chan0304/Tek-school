import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Shell } from "@/components/Shell";
import {
  ArrowUpRight, ArrowLeft, GraduationCap, Briefcase, Cpu, Rocket,
  LineChart, Users, Clock, CheckCircle2, Quote, Building2,
} from "lucide-react";
import collegeCoding from "@/assets/real-college-coding.jpg";
import collegeTeam from "@/assets/real-college-team.jpg";
import collegeLab from "@/assets/real-college-lab.jpg";
import { LeadModal } from "@/components/LeadModal";

const TRACKS = [
  {
    title: "AI & applied ML",
    body: "RAG systems, model fine-tuning and agentic workflows — students ship a working AI product, not a notebook.",
    icon: Cpu,
    tone: "blue" as const,
  },
  {
    title: "Cloud & DevOps",
    body: "AWS, Docker, Kubernetes and CI/CD, with certification prep folded into the semester plan.",
    icon: Rocket,
    tone: "lavender" as const,
  },
  {
    title: "Full-stack engineering",
    body: "Modern web stack, code review discipline and a deployed portfolio project per student.",
    icon: Briefcase,
    tone: "coral" as const,
  },
  {
    title: "Placement readiness",
    body: "DSA sprints, mock interviews, resume and portfolio reviews, plus intros to hiring partners.",
    icon: LineChart,
    tone: "blue" as const,
  },
];

const OUTCOMES = [
  "Students graduate with a deployed portfolio, not just a transcript.",
  "Campus internships on real client briefs, supervised by working engineers.",
  "Placement metrics your department can report with confidence.",
  "Faculty upskilling sessions included with every partner cohort.",
];

const HOW = [
  { step: "01", title: "Department alignment", body: "We map modules to your semester calendar and credit structure with the HOD and placement cell." },
  { step: "02", title: "Cohort onboarding", body: "Diagnostic assessment, cohort split by level, and lab setup inside your existing infrastructure." },
  { step: "03", title: "Build semester", body: "Weekly mentor-led builds, code reviews and sprint demos — hybrid or on campus." },
  { step: "04", title: "Placement bridge", body: "Mock rounds, portfolio audits and direct introductions to our hiring partner network." },
];

const STATS = [
  { v: "40+", l: "Partner campuses" },
  { v: "400+", l: "Students placed" },
  { v: "94%", l: "Completion rate" },
  { v: "6 mo", l: "Typical cohort" },
];

const toneBg = (t: "blue" | "coral" | "lavender") =>
  t === "blue"
    ? "bg-[color:var(--sky)] text-[color:var(--accent-blue-deep)]"
    : t === "coral"
    ? "bg-[color:var(--coral)] text-[color:var(--coral-foreground)]"
    : "bg-[color:var(--lavender)] text-[color:var(--lavender-foreground)]";

export const Route = createFileRoute("/campus_/college")({
  head: () => ({
    meta: [
      { title: "Tek Campus at College — Industry programs for engineering campuses" },
      { name: "description", content: "Tek Campus at College runs AI, cloud and full-stack cohorts inside your institution, with campus internships, faculty upskilling and placement readiness." },
      { property: "og:title", content: "Tek Campus at College — Industry programs for engineering campuses" },
      { property: "og:description", content: "AI, cloud and full-stack cohorts delivered on your campus, with internships and placement support." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CampusCollege,
});

function CampusCollege() {
  const [proposal, setProposal] = useState(false);

  return (
    <Shell>
      {/* Hero */}
      <section className="px-4 md:px-10 pt-10 pb-12">
        <div className="mx-auto max-w-6xl">
          <Link to="/campus" className="inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Back to Tek Campus
          </Link>

          <div className="mt-6 grid gap-8 lg:grid-cols-[1.05fr_1fr] lg:items-center">
            <div>
              <span className="pill-tag bg-[color:var(--sky)]/25 text-[color:var(--accent-blue-deep)] text-xs inline-flex items-center gap-1.5">
                <GraduationCap className="h-3.5 w-3.5" /> Tek Campus at College
              </span>
              <h1 className="mt-5 font-display text-4xl md:text-6xl font-bold leading-[1.05] tracking-tight">
                From syllabus to <span className="text-[color:var(--accent-blue-deep)]">shipped software</span>.
              </h1>
              <p className="mt-5 max-w-xl text-base md:text-lg leading-relaxed text-muted-foreground">
                Industry cohorts in AI, cloud and full-stack engineering — run inside your college, mapped to your
                semester calendar, with internships and placement support built in.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={() => setProposal(true)}
                  data-cursor="enroll"
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors"
                >
                  Partner with Tek Campus <ArrowUpRight className="h-4 w-4" />
                </button>

              </div>
              <div className="mt-8 flex flex-wrap gap-6 text-sm text-muted-foreground">
                <span className="flex items-center gap-2"><Users className="h-4 w-4" /> 2nd year to final year</span>
                <span className="flex items-center gap-2"><Clock className="h-4 w-4" /> Semester-aligned</span>
                <span className="flex items-center gap-2"><Building2 className="h-4 w-4" /> On campus or hybrid</span>
              </div>
            </div>

            <div className="relative overflow-hidden rounded-[3rem] bg-gradient-to-br from-primary to-[color:var(--accent-blue-deep)] p-4 shadow-2xl shadow-primary/20">
              <img
                src={collegeCoding}
                alt="College students collaborating on a Tek Campus project"
                loading="lazy"
                className="h-full max-h-[420px] w-full rounded-[2.2rem] object-cover"
              />
            </div>
          </div>

          <div className="mt-12 grid grid-cols-2 gap-4 md:grid-cols-4">
            {STATS.map((s) => (
              <div key={s.l} className="rounded-[1.75rem] border border-border bg-white p-6 text-center shadow-sm">
                <p className="font-display text-3xl font-bold">{s.v}</p>
                <p className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">{s.l}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Tracks */}
      <section className="px-4 md:px-10 py-10">
        <div className="mx-auto max-w-6xl">
          <div className="max-w-2xl">
            <p className="pill-tag bg-muted text-muted-foreground mb-3"># What we run</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold leading-tight">
              Four tracks, one placement outcome.
            </h2>
          </div>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {TRACKS.map((t, i) => (
              <div
                key={t.title}
                className="tek-tile-in flex h-full flex-col rounded-[2rem] border border-border bg-white p-6 shadow-lg shadow-primary/5 transition-transform duration-300 hover:-translate-y-1.5"
                style={{ animationDelay: `${i * 80}ms` }}
              >
                <span className={`grid h-12 w-12 place-items-center rounded-2xl ${toneBg(t.tone)}`}>
                  <t.icon className="h-5 w-5" />
                </span>
                <p className="mt-5 font-display text-lg font-bold">{t.title}</p>
                <p className="mt-2.5 text-sm leading-relaxed text-muted-foreground">{t.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Internships */}
      <section className="px-4 md:px-10 py-10">
        <div className="mx-auto max-w-6xl grid gap-6 lg:grid-cols-2 lg:items-stretch">
          <div className="flex flex-col justify-center rounded-[2.5rem] border border-border bg-white p-8 md:p-10 shadow-lg shadow-primary/5">
            <span className="pill-tag bg-[color:var(--lavender)]/30 text-[color:var(--lavender-foreground)] mb-4 inline-flex w-fit"># Internships on campus</span>
            <h2 className="font-display text-3xl md:text-4xl font-bold leading-tight">
              Real client briefs, shipped from your own labs.
            </h2>
            <p className="mt-4 text-base leading-relaxed text-muted-foreground">
              Selected students join live internship sprints inside their campus. They work on real products under working engineers, build shipped portfolio pieces, and earn internship certificates that hiring partners recognise.
            </p>
            <ul className="mt-6 space-y-3 text-sm leading-relaxed text-muted-foreground">
              <li className="flex gap-3">
                <CheckCircle2 className="mt-0.5 h-4.5 w-4.5 shrink-0 text-[color:var(--accent-blue-deep)]" />
                <span>Real projects sourced from Tek School's partner network.</span>
              </li>
              <li className="flex gap-3">
                <CheckCircle2 className="mt-0.5 h-4.5 w-4.5 shrink-0 text-[color:var(--accent-blue-deep)]" />
                <span>Dedicated mentors review code, run standups and set deadlines.</span>
              </li>
              <li className="flex gap-3">
                <CheckCircle2 className="mt-0.5 h-4.5 w-4.5 shrink-0 text-[color:var(--accent-blue-deep)]" />
                <span>Internship certificates + LinkedIn portfolio support.</span>
              </li>
              <li className="flex gap-3">
                <CheckCircle2 className="mt-0.5 h-4.5 w-4.5 shrink-0 text-[color:var(--accent-blue-deep)]" />
                <span>Direct pathway to placement interviews with partner companies.</span>
              </li>
            </ul>
            <button
              type="button"
              onClick={() => setProposal(true)}
              data-cursor="enroll"
              className="mt-8 inline-flex w-fit items-center gap-2 rounded-full bg-[color:var(--lavender)] px-6 py-3 text-sm font-semibold text-[color:var(--lavender-foreground)] hover:bg-[color:var(--lavender)]/90"
            >
              Request internship details <ArrowUpRight className="h-4 w-4" />
            </button>
          </div>
          <div className="rounded-[2.5rem] overflow-hidden bg-[color:var(--lavender)]/20 p-4 md:p-6">
            <img
              src={collegeTeam}
              alt="Students collaborating on a Tek Campus internship sprint"
              loading="lazy"
              className="h-full w-full rounded-[2rem] object-cover"
            />
          </div>
        </div>
      </section>

      {/* Outcomes + how it runs */}
      <section className="px-4 md:px-10 py-10">
        <div className="mx-auto max-w-6xl grid gap-6 lg:grid-cols-2 lg:items-stretch">
          <div className="rounded-[2.5rem] bg-[color:var(--lavender)] p-8 md:p-10 text-[color:var(--lavender-foreground)]">
            <p className="font-display text-2xl font-bold">What your department gets</p>
            <ul className="mt-6 space-y-4 text-sm leading-relaxed">
              {OUTCOMES.map((o) => (
                <li key={o} className="flex gap-3">
                  <CheckCircle2 className="mt-0.5 h-4.5 w-4.5 shrink-0" />
                  <span>{o}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-[2.5rem] border border-border bg-white p-8 md:p-10 shadow-lg shadow-primary/5">
            <p className="font-display text-2xl font-bold">How a semester runs</p>
            <ol className="mt-6 space-y-5">
              {HOW.map((h) => (
                <li key={h.step} className="flex gap-4">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-muted text-xs font-bold">{h.step}</span>
                  <span>
                    <span className="block font-display font-bold">{h.title}</span>
                    <span className="mt-1 block text-sm leading-relaxed text-muted-foreground">{h.body}</span>
                  </span>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      {/* Gallery + voice */}
      <section className="px-4 md:px-10 py-10">
        <div className="mx-auto max-w-6xl grid gap-6 lg:grid-cols-3">
          {[collegeTeam, collegeLab].map((src) => (
            <div key={src} className="rounded-[2rem] border border-border bg-slate-50 p-4">
              <img src={src} alt="Work shipped from a Tek Campus college cohort" loading="lazy" className="mx-auto aspect-[4/3] w-full rounded-2xl object-cover" />
            </div>
          ))}
          <figure className="flex flex-col justify-center rounded-[2rem] border border-border bg-white p-8 shadow-lg shadow-primary/5">
            <Quote className="h-6 w-6 text-[color:var(--sky)]" />
            <blockquote className="mt-4 text-sm leading-relaxed text-muted-foreground">
              "Placement conversations changed completely. Our students now talk about what they built instead of what they studied."
            </blockquote>
            <figcaption className="mt-5">
              <p className="font-display font-bold">Prof. K. Srinivas</p>
              <p className="text-xs text-muted-foreground">HOD, Computer Science</p>
            </figcaption>
          </figure>
        </div>
      </section>

      {/* CTA */}
      <section className="px-4 md:px-10 py-14">
        <div className="mx-auto max-w-6xl overflow-hidden rounded-[3rem] bg-primary p-10 md:p-14 text-center text-white shadow-2xl shadow-primary/20">
          <h2 className="font-display text-3xl md:text-4xl font-bold leading-tight">
            Run the next cohort on your campus.
          </h2>
          <p className="mt-4 mx-auto max-w-xl text-sm md:text-base opacity-90">
            Send us your semester calendar and student count — we'll design the cohort, pricing and internship plan around it.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
            <button
              type="button"
              onClick={() => setProposal(true)}
              data-cursor="enroll"
              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-[color:var(--coral)] px-8 py-4 text-sm font-bold text-[color:var(--coral-foreground)] transition-transform hover:scale-105 active:scale-95"
            >
              Request a college proposal
            </button>
            <Link
              to="/campus/school"
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/20 bg-white/10 px-8 py-4 text-sm font-bold text-white hover:bg-white/20"
              >
                Looking for school? →
              </Link>
          </div>
        </div>
      </section>


      <LeadModal
        open={proposal}
        onClose={() => setProposal(false)}
        badge="College partnerships"
        title="Bring Tek Campus to your institute"
        subtitle="Share your details and we'll send a cohort, pricing and internship plan for your campus."
        interest="Tek Campus at college"
        institutionType="College / University"
        locationLabel="University name"
        locationPlaceholder="Name of your university / college"
        cta="Send my proposal request"
      />
    </Shell>
  );
}
