import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell, SectionTitle } from "@/components/mobile/AppShell";
import { MobileModal, SheetPrimary } from "@/components/mobile/MobileModal";
import { Toast } from "@/components/mobile/Nudges";
import { COHORT, MENTORS, ACTIVITY } from "@/lib/dashboard-data";
import { MessageCircle, Sparkles, Flame, Trophy, Check, Send } from "lucide-react";


export const Route = createFileRoute("/app/cohort")({
  head: () => ({ meta: [{ title: "Cohort — TekSchool" }, { name: "robots", content: "noindex" }] }),
  component: CohortScreen,
});

function Ava({ name, photo, online }: { name: string; photo?: string; online?: boolean }) {
  const initials = name.split(" ").map((n) => n[0]).slice(0, 2).join("");
  return (
    <div className="relative">
      <div className="grid h-12 w-12 place-items-center overflow-hidden rounded-full bg-[#E8E0F5] text-sm font-bold text-[#5B3E9B]">
        {photo ? <img src={photo} alt={name} className="h-full w-full object-cover" /> : initials}
      </div>
      {online && <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full bg-emerald-500 ring-2 ring-white" />}
    </div>
  );
}

function ActivityIcon({ type }: { type: string }) {
  if (type === "badge") return <Trophy className="h-3.5 w-3.5" />;
  if (type === "kudos") return <Sparkles className="h-3.5 w-3.5" />;
  if (type === "streak") return <Flame className="h-3.5 w-3.5" />;
  return <Sparkles className="h-3.5 w-3.5" />;
}

function CohortScreen() {
  const [msgTo, setMsgTo] = useState<string | null>(null);
  const [text, setText] = useState("");
  const [toast, setToast] = useState<string | null>(null);
  function flash(m: string) { setToast(m); setTimeout(() => setToast(null), 1800); }

  return (
    <AppShell title="Cohort">
      <div className="mt-5">
        <SectionTitle title="Mentors" />
        <div className="flex gap-4 overflow-x-auto px-5 pb-2">
          {MENTORS.map((m) => (
            <button key={m.name} onClick={() => setMsgTo(m.name)} className="flex w-20 flex-col items-center gap-2 text-center active:scale-95">
              <Ava name={m.name} photo={m.photo} online={m.online} />
              <p className="text-[11px] font-semibold leading-tight">{m.name}</p>
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6">
        <SectionTitle title="Your cohort" />
        <div className="space-y-2 px-5">
          {COHORT.map((c) => (
            <div key={c.name} className="flex items-center gap-3 rounded-3xl bg-white p-3 shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)]">
              <Ava name={c.name} photo={c.photo} online={c.online} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold text-slate-900">{c.name}</p>
                <p className="truncate text-[11px] text-slate-500">{c.role}</p>
              </div>
              <button onClick={() => setMsgTo(c.name)} aria-label="Message" className="grid h-9 w-9 place-items-center rounded-full bg-slate-100 active:scale-95">
                <MessageCircle className="h-4 w-4 text-slate-600" />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-6">
        <SectionTitle title="Activity" />
        <div className="space-y-3 px-5">
          {ACTIVITY.map((a) => (
            <div key={a.id} className="rounded-3xl bg-white p-4 shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)]">
              <div className="flex items-center gap-2">
                <span className="grid h-6 w-6 place-items-center rounded-lg bg-slate-100 text-slate-500"><ActivityIcon type={a.type} /></span>
                <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">{a.type} · {a.when}</p>
              </div>
              <p className="mt-2 text-sm font-semibold leading-snug text-slate-900">{a.text}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-6 px-5">
        <a href="https://discord.com" target="_blank" rel="noreferrer" className="block rounded-3xl bg-[#5865F2] p-5 text-white active:scale-[0.99]">
          <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-white/80">Community</p>
          <h3 className="mt-2 font-display text-lg font-bold">Open Discord →</h3>
          <p className="mt-1 text-sm text-white/80">14 unread in #applied-ai, 3 mentions.</p>
        </a>
      </div>

      <MobileModal open={msgTo !== null} onClose={() => setMsgTo(null)} eyebrow="Direct message" title={`Message ${msgTo ?? ""}`}
        footer={<SheetPrimary onClick={() => { if (text.trim()) { const to = msgTo; setMsgTo(null); setText(""); flash(`Sent to ${to?.split(" ")[0]}`); } }}><Send className="h-4 w-4 mr-1" /> Send</SheetPrimary>}>
        <textarea autoFocus value={text} onChange={(e) => setText(e.target.value)} rows={4} placeholder="Say hi…" className="w-full rounded-2xl bg-slate-100 p-3 text-sm focus:outline-none" />
      </MobileModal>

      <Toast show={!!toast} message={toast ?? ""} icon={Check} />
    </AppShell>
  );
}

