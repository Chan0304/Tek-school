import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { ArrowUpRight, GraduationCap, School, Cpu } from "lucide-react";

const ENTRY_POINTS = [
  {
    icon: GraduationCap,
    title: "Tek Campus at college",
    body: "Industry-aligned cohorts in AI, Cloud, Full-stack and internships — delivered on your campus.",
    tone: "blue" as const,
    to: "/campus/college" as const,
    cta: "Explore college",
  },
  {
    icon: School,
    title: "Tek Campus at school",
    body: "Foundational coding, robotics and AI for young learners — taught inside your school.",
    tone: "coral" as const,
    to: "/campus/school" as const,
    cta: "Explore school",
  },
  {
    icon: Cpu,
    title: "AI Lab Set up",
    body: "End-to-end AI lab infrastructure, hardware kits, curriculum and trainer enablement for your institution.",
    tone: "lavender" as const,
    to: "/campus/ai-lab" as const,
    cta: "View details",
  },
];

const toneIconBg = (t: "blue" | "coral" | "lavender") => {
  if (t === "blue") return "bg-[color:var(--sky)] text-[color:var(--accent-blue-deep)]";
  if (t === "coral") return "bg-[color:var(--coral)] text-[color:var(--coral-foreground)]";
  return "bg-[color:var(--lavender)] text-[color:var(--lavender-foreground)]";
};

const toneCorner = (t: "blue" | "coral" | "lavender") => {
  if (t === "blue") return "bg-[color:var(--sky)]/20";
  if (t === "coral") return "bg-[color:var(--coral)]/20";
  return "bg-[color:var(--lavender)]/20";
};

const toneButton = (t: "blue" | "coral" | "lavender") => {
  if (t === "blue") return "bg-[color:var(--accent-blue-deep)] text-white hover:bg-[color:var(--accent-blue-deep)]/90";
  if (t === "coral") return "bg-[color:var(--coral)] text-[color:var(--coral-foreground)] hover:bg-[color:var(--coral)]/90";
  return "bg-[color:var(--lavender)] text-[color:var(--lavender-foreground)] hover:bg-[color:var(--lavender)]/90";
};

export const Route = createFileRoute("/campus")({
  head: () => ({
    meta: [
      { title: "Tek Campus — Coding programs for schools & colleges" },
      { name: "description", content: "Tek Campus brings AI-based learning, real-world coding and industry mentorship into your school or college." },
      { property: "og:title", content: "Tek Campus — Coding programs for schools & colleges" },
      { property: "og:description", content: "Bridging school and college education with real-world tech skills, taught on your campus." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Campus,
});

function Campus() {
  const cardClasses =
    "group relative flex flex-col overflow-hidden rounded-[2.25rem] border border-border/70 bg-white p-8 md:p-10 text-left shadow-[var(--shadow-card)] transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[var(--shadow-card-hover)]";

  return (
    <Shell>
      <section className="relative px-4 md:px-10 pt-16 pb-24 md:pb-28 overflow-hidden">
        <div aria-hidden className="pointer-events-none absolute left-1/2 top-[-14rem] h-[30rem] w-[52rem] -translate-x-1/2 rounded-full bg-[color:var(--sky)] opacity-[0.16] blur-3xl" />
        <div aria-hidden className="pointer-events-none absolute right-[-6rem] bottom-[-8rem] h-[22rem] w-[22rem] rounded-full bg-[color:var(--coral)] opacity-[0.12] blur-3xl" />
        <div className="relative mx-auto max-w-5xl text-center">
          <span className="pill-tag bg-muted text-muted-foreground text-xs"># Tek Campus</span>
          <h1 className="font-display text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight leading-[1.05] mt-6">
            Empowering the <span className="text-[color:var(--coral)]">future</span> of academic excellence.
          </h1>
          <p className="mt-6 mx-auto max-w-2xl text-base md:text-lg text-muted-foreground leading-relaxed">
            Tek Campus provides a seamless ecosystem for schools and colleges to bridge foundational learning with real-world tech skills.
          </p>
        </div>

        <div className="relative mt-14 md:mt-16 mx-auto grid gap-6 sm:grid-cols-2 lg:grid-cols-3 max-w-6xl">
          {ENTRY_POINTS.map((e, i) => (
            <Link
              key={e.title}
              to={e.to}
              data-cursor="view"
              className={cardClasses}
              style={{ animationDelay: `${i * 90}ms` }}
            >
              <div
                className={`absolute -right-16 -top-16 h-40 w-40 rounded-bl-full transition-transform duration-700 group-hover:scale-150 ${toneCorner(e.tone)}`}
              />
              <span className={`relative grid h-14 w-14 place-items-center rounded-2xl shadow-inner ${toneIconBg(e.tone)}`}>
                <e.icon className="h-6 w-6" />
              </span>
              <p className="relative mt-6 font-display text-xl md:text-2xl font-bold">{e.title}</p>
              <p className="relative mt-3 text-sm leading-relaxed text-muted-foreground">{e.body}</p>
              <span className={`relative mt-8 inline-flex items-center justify-center gap-1.5 rounded-full px-5 py-2.5 text-sm font-semibold transition-transform ${toneButton(e.tone)}`}>
                {e.cta} <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </span>
            </Link>
          ))}
        </div>
      </section>
    </Shell>
  );
}
