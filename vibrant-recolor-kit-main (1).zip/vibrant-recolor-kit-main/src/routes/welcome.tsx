import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useSession, useHydrated, markReturning } from "@/lib/auth";
import { Sparkles, ArrowRight, Circle, CheckCircle2 } from "lucide-react";
import { Squiggle, Flower, Asterisk } from "@/components/Doodles";
import { LogoLockup } from "@/components/Logo";

export const Route = createFileRoute("/welcome")({
  head: () => ({ meta: [{ title: "Welcome — TekSchool" }, { name: "robots", content: "noindex" }] }),
  component: WelcomePage,
});

function WelcomePage() {
  const session = useSession();
  const hydrated = useHydrated();
  const navigate = useNavigate();
  const [countdown, setCountdown] = useState(5);

  useEffect(() => {
    if (!hydrated) return;
    if (!session) {
      navigate({ to: "/" });
      return;
    }
    const t = setInterval(() => setCountdown((c) => c - 1), 1000);
    return () => clearInterval(t);
  }, [hydrated, session, navigate]);

  useEffect(() => {
    if (countdown <= 0 && session) {
      markReturning();
      navigate({ to: "/dashboard" });
    }
  }, [countdown, session, navigate]);

  if (!hydrated || !session) return null;

  const isFirst = session.isFirstTime;

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-[#1E1B4B] via-[#2D5FA8] to-[#5BA4E8] text-white">
      {/* Doodles */}
      <Squiggle className="absolute left-[-40px] top-24 h-20 w-64 opacity-30" color="#ffffff" />
      <Flower className="absolute right-16 top-24 h-20 w-20 opacity-40" color="var(--coral)" />
      <Asterisk className="absolute bottom-32 left-24 h-16 w-16 opacity-40" color="var(--lavender)" />
      <Squiggle className="absolute right-[-60px] bottom-16 h-24 w-72 opacity-25" color="#ffffff" />

      <div className="absolute left-8 top-8 z-10">
        <Link to="/" className="inline-block">
          <LogoLockup className="h-9 [&_*]:!fill-white [&_*]:!text-white" />
        </Link>
      </div>

      <div className="relative z-10 mx-auto flex min-h-screen max-w-3xl flex-col items-center justify-center px-6 py-24 text-center">
        <span className="pill-tag mb-6 -rotate-3 bg-coral text-coral-foreground">
          <Sparkles className="h-3.5 w-3.5" /> {isFirst ? "First day" : `Week ${session.weekCurrent}`}
        </span>

        <h1 className="font-display text-5xl font-bold tracking-tight md:text-7xl">
          {isFirst ? "Welcome to TekSchool," : "Welcome back,"}
          <br />
          <span className="italic text-[var(--coral)]">{session.name}</span> <span aria-hidden>👋</span>
        </h1>

        <p className="mt-5 max-w-lg text-lg text-white/80">
          {isFirst
            ? "You're joining the AI Engineering cohort. Let's get you set up in three quick steps."
            : `You're on Week ${session.weekCurrent} of ${session.weekTotal} — right in the middle of Applied AI. Let's pick up.`}
        </p>

        {/* Next-step card */}
        <div className="mt-10 w-full rounded-3xl bg-white p-6 text-left text-foreground shadow-[0_20px_60px_-20px_rgba(0,0,0,0.4)]">
          {isFirst ? (
            <div>
              <p className="mb-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground">3-step setup</p>
              <ul className="space-y-3">
                {[
                  "Complete your profile — so mentors know who you are",
                  "Confirm your track (AI Engineering)",
                  "Join your first cohort session on Zoom",
                ].map((step, i) => (
                  <li key={i} className="flex items-center gap-3 text-sm">
                    <Circle className="h-5 w-5 shrink-0 text-accent-blue-deep" />
                    <span>{step}</span>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <div>
              <p className="mb-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Continue where you left off</p>
              <h3 className="font-display text-xl font-bold">Applied AI · Week {session.weekCurrent}</h3>
              <p className="mt-1 text-sm text-muted-foreground">Transformers from scratch — attention head walkthrough with Ananya Rao.</p>
              <div className="mt-4 h-2 w-full rounded-full bg-muted">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[var(--accent-blue)] to-[var(--accent-blue-deep)]"
                  style={{ width: `${Math.round((session.weekCurrent / session.weekTotal) * 100)}%` }}
                />
              </div>
              <p className="mt-2 text-xs text-muted-foreground">
                Week {session.weekCurrent} of {session.weekTotal} · {Math.round((session.weekCurrent / session.weekTotal) * 100)}% complete
              </p>
              <div className="mt-3 flex items-center gap-2 text-sm">
                <CheckCircle2 className="h-4 w-4 text-accent-blue-deep" />
                <span>Streak: {session.streak} days</span>
              </div>
            </div>
          )}

          <button
            onClick={() => {
              markReturning();
              navigate({ to: "/dashboard" });
            }}
            className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-white hover:bg-primary/90"
          >
            Go to Dashboard <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        <p className="mt-6 text-xs text-white/60">Auto-continuing in {Math.max(countdown, 0)}s…</p>
      </div>
    </div>
  );
}
