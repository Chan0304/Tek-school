import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AdminShell } from "@/components/admin/AdminShell";
import { getActiveCampaign } from "@/lib/campaigns";
import { openAction } from "@/lib/action-bus";
import { ActionModals } from "@/components/ActionModals";
import { Megaphone, MousePointerClick, Target } from "lucide-react";

export const Route = createFileRoute("/admin/marketing")({
  head: () => ({ meta: [{ title: "Marketing — Admin" }, { name: "robots", content: "noindex" }] }),
  component: MarketingAdmin,
});

const CAMPAIGN_STATS = [
  { id: "monsoon-2026", name: "Monsoon 2026 · MONSOON26", impressions: 24800, clicks: 1740, conversions: 92, active: true, range: "Jun 1 – Sep 30" },
  { id: "diwali-2025", name: "Diwali 2025 · DIWALI25", impressions: 31200, clicks: 2210, conversions: 148, active: false, range: "Oct 1 – Nov 15, 2025" },
  { id: "yearEnd-2025", name: "Year-End 2025 · NEW26", impressions: 18400, clicks: 1050, conversions: 76, active: false, range: "Dec 1 – 31, 2025" },
];

function MarketingAdmin() {
  const [items, setItems] = useState(CAMPAIGN_STATS);
  const active = useMemo(() => getActiveCampaign(), []);

  return (
    <AdminShell title="Marketing / Campaigns">
      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <div className="space-y-3">
          {items.map((c) => {
            const ctr = ((c.clicks / c.impressions) * 100).toFixed(2);
            const conv = ((c.conversions / c.clicks) * 100).toFixed(1);
            return (
              <div key={c.id} className="rounded-xl border border-slate-200 bg-white p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className={`rounded-md px-2 py-0.5 text-[10px] font-bold ${c.active ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>{c.active ? "Active" : "Ended"}</span>
                    <h3 className="mt-1 font-display text-base font-bold">{c.name}</h3>
                    <p className="text-[11px] text-slate-500">{c.range}</p>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => openAction({ kind: "toast", message: `Editing ${c.name}` })} className="rounded-lg border border-slate-200 px-3 py-1.5 text-[11px] font-semibold hover:bg-slate-50">Edit</button>
                    <button onClick={() => setItems((arr) => arr.map((x) => x.id === c.id ? { ...x, active: !x.active } : x))} className="rounded-lg bg-[#1E1B4B] px-3 py-1.5 text-[11px] font-semibold text-white">{c.active ? "Pause" : "Activate"}</button>
                  </div>
                </div>
                <div className="mt-3 grid grid-cols-4 gap-2 text-[11px]">
                  <Metric icon={Megaphone} label="Impressions" value={c.impressions.toLocaleString()} />
                  <Metric icon={MousePointerClick} label="Clicks" value={c.clicks.toLocaleString()} />
                  <Metric icon={Target} label="CTR" value={`${ctr}%`} />
                  <Metric icon={Target} label="Conversions" value={`${c.conversions} · ${conv}%`} />
                </div>
              </div>
            );
          })}
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-[10px] font-semibold uppercase tracking-widest text-slate-400">Currently live on site</p>
          {active ? (
            <>
              <h3 className="mt-1 font-display text-sm font-bold">{active.badge}</h3>
              <p className="mt-1 text-[11px] text-slate-500">{active.headline}</p>
              <p className="mt-2 rounded-md bg-slate-50 px-2 py-1 text-[11px] font-mono">{active.code}</p>
              <p className="mt-3 text-[10px] text-slate-400">Auto-selected by season. Edit the config in <code>src/lib/campaigns.ts</code> or use the button above to override.</p>
            </>
          ) : <p className="text-xs text-slate-500">No active seasonal campaign right now.</p>}
        </div>
      </div>
      <ActionModals />
    </AdminShell>
  );
}

function Metric({ icon: Icon, label, value }: { icon: typeof Megaphone; label: string; value: string }) {
  return <div className="rounded-lg bg-slate-50 p-2"><p className="flex items-center gap-1 text-[10px] font-semibold uppercase tracking-widest text-slate-400"><Icon className="h-3 w-3" /> {label}</p><p className="mt-0.5 text-sm font-bold tabular-nums">{value}</p></div>;
}
