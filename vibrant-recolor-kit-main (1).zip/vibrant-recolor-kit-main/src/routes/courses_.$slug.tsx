import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { CourseCard } from "./courses";
import { COURSES_DATA } from "@/lib/courses-data";
import { Asterisk, Squiggle, Loop } from "@/components/Doodles";
import { ArrowUpRight, Clock, Users, CheckCircle2 } from "lucide-react";
import instructor1 from "@/assets/instructor-1.jpg";
import instructor2 from "@/assets/instructor-2.jpg";
import instructor3 from "@/assets/instructor-3.jpg";
import instructor4 from "@/assets/instructor-4.jpg";
import heroStudents from "@/assets/course-hero-students.jpg";
import { useState } from "react";
import { LeadModal } from "@/components/LeadModal";

const AVATARS = [instructor1, instructor2, instructor3, instructor4];

export const Route = createFileRoute("/courses_/$slug")({
  loader: ({ params }) => {
    const course = COURSES_DATA.find((c) => c.slug === params.slug);
    if (!course) throw notFound();
    return { course };
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.course.title} — TekSchool` },
          { name: "description", content: loaderData.course.blurb },
          { property: "og:title", content: `${loaderData.course.title} — TekSchool` },
          { property: "og:description", content: loaderData.course.blurb },
        ]
      : [],
  }),
  component: CourseDetail,
  notFoundComponent: () => (
    <Shell>
      <div className="px-6 py-20 text-center">
        <Asterisk className="mx-auto h-20 w-20" color="var(--coral)" />
        <h1 className="font-display text-4xl font-bold mt-6">Course not found.</h1>
        <Link to="/courses" className="mt-6 inline-block rounded-full bg-primary px-5 py-2 text-primary-foreground text-sm font-semibold">Browse catalog</Link>
      </div>
    </Shell>
  ),
});

const SYLLABUS = [
  { w: "Week 01", t: "Foundations", d: "Set up the stack, tour the toolbox, meet your cohort." },
  { w: "Week 02", t: "Core concepts", d: "The vocabulary and mental models you'll use daily." },
  { w: "Week 03", t: "First build", d: "Ship a scoped project end-to-end. Get real feedback." },
  { w: "Week 05", t: "Systems", d: "Composition, patterns, and the shape of larger work." },
  { w: "Week 07", t: "Craft & polish", d: "Details, edge cases, accessibility. The 10% that makes it feel real." },
  { w: "Week 10", t: "Capstone", d: "A public artifact — portfolio-ready and shipped to production." },
];

function CourseDetail() {
  const { course } = Route.useLoaderData();
  const avatar = AVATARS[course.slug.length % AVATARS.length];
  const instructorName = ["Sarah Chen", "David Park", "Maya Rodriguez", "Alex Foster"][course.slug.length % 4];
  const related = COURSES_DATA.filter((c) => c.slug !== course.slug).slice(0, 3);
  const [enrollOpen, setEnrollOpen] = useState(false);

  return (
    <Shell>
      {/* HERO */}
      <section className="relative px-4 md:px-10 pt-4 pb-14">
        <Squiggle className="pointer-events-none absolute right-10 top-4 h-24 w-56 opacity-60" />
        <div className="grid gap-8 lg:grid-cols-[1.1fr_1fr] items-center">
          <div>
            <Link to="/courses" className="pill-tag bg-muted text-muted-foreground text-xs mb-6"># {course.category}</Link>
            <h1 className="font-display text-5xl md:text-6xl font-bold leading-[0.95] tracking-tight">
              {course.title}
            </h1>
            <p className="mt-5 text-muted-foreground max-w-lg">{course.blurb}</p>

            <div className="mt-8 flex flex-wrap gap-3">
              <div className="rounded-full bg-primary text-primary-foreground pl-1 pr-4 py-1 flex items-center gap-2">
                <img src={avatar} alt="" className="h-9 w-9 rounded-full object-cover" />
                <div className="text-left leading-tight">
                  <p className="text-xs opacity-70">Instructor</p>
                  <p className="text-sm font-semibold">{instructorName}</p>
                </div>
              </div>
              <span className="pill-tag bg-[color:var(--lavender)] text-[color:var(--lavender-foreground)]">
                <Clock className="h-3.5 w-3.5" /> {course.duration}
              </span>
              <span className="pill-tag bg-[color:var(--coral)] text-[color:var(--coral-foreground)]">
                <Users className="h-3.5 w-3.5" /> {course.students} enrolled
              </span>
              <span className="pill-tag gradient-blue text-white">{course.level}</span>
            </div>
          </div>

          {/* Photo banner */}
          <div className="relative rounded-[2rem] bg-primary p-4 overflow-hidden"
               style={{ clipPath: "polygon(0 0, 100% 0, 100% 88%, 88% 100%, 0 100%)" }}>
            <img src={heroStudents} alt="" className="h-72 md:h-96 w-full rounded-[1.5rem] object-cover" loading="lazy" width={1200} height={1200} />
            <span className="pill-tag absolute right-6 top-6 bg-white text-primary -rotate-3">
              # {course.category}
            </span>
          </div>
        </div>
      </section>

      {/* SYLLABUS TIMELINE */}
      <section className="relative px-4 md:px-10 py-14">
        <Loop className="pointer-events-none absolute left-2 top-10 h-64 w-64 opacity-40" />
        <div className="max-w-3xl relative">
          <p className="pill-tag bg-muted text-muted-foreground mb-3"># Syllabus</p>
          <h2 className="font-display text-4xl md:text-5xl font-bold">How the cohort flows</h2>
        </div>

        <div className="relative mt-12 max-w-3xl mx-auto">
          {/* connecting squiggle line */}
          <svg className="absolute left-6 top-0 h-full w-6 hidden md:block" viewBox="0 0 40 800" preserveAspectRatio="none" fill="none">
            <path d="M20 0 C 40 100, 0 200, 20 300 S 40 500, 20 600 S 0 750, 20 800" stroke="var(--sky)" strokeWidth="2.5" fill="none" />
          </svg>
          <ol className="space-y-6">
            {SYLLABUS.map((s, i) => (
              <li key={i} className="flex gap-5 relative">
                <div className={`shrink-0 grid h-12 w-12 place-items-center rounded-full font-display font-bold text-sm ${
                  i % 3 === 0 ? "bg-[color:var(--coral)] text-[color:var(--coral-foreground)]"
                    : i % 3 === 1 ? "bg-[color:var(--lavender)] text-[color:var(--lavender-foreground)]"
                    : "gradient-blue text-white"
                }`}>
                  0{i + 1}
                </div>
                <div className="flex-1 rounded-3xl border p-5 bg-white">
                  <p className="text-xs font-semibold text-muted-foreground">{s.w}</p>
                  <h3 className="font-display text-xl font-bold mt-1">{s.t}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{s.d}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* WHAT'S INCLUDED + PRICE */}
      <section className="px-4 md:px-10 py-10">
        <div className="grid gap-6 lg:grid-cols-[1.2fr_1fr]">
          <div className="rounded-[2rem] border p-8">
            <h3 className="font-display text-2xl font-bold mb-6">What&apos;s included</h3>
            <ul className="grid sm:grid-cols-2 gap-3 text-sm">
              {["Live weekly cohort sessions", "1:1 mentor check-ins", "Real project portfolio", "Community Slack access", "Lifetime alumni network", "Career support & reviews"].map((f) => (
                <li key={f} className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[color:var(--accent-blue-deep)] mt-0.5 shrink-0" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-[2rem] bg-primary text-primary-foreground p-8 relative overflow-hidden">
            <div className="absolute -right-10 -bottom-10 h-48 w-48 rounded-full gradient-blue opacity-60" />
            <p className="text-sm opacity-70">Starting from</p>
            <p className="font-display text-5xl font-bold mt-1">${course.price.toLocaleString()}</p>
            <p className="text-sm opacity-70 mt-1">or 4× ${course.priceMonthly}/month</p>
            <div className="relative mt-6 space-y-1 text-sm">
              <p className="opacity-90">Next cohort: <span className="font-semibold">{course.nextCohort}</span></p>
              <p className="opacity-90">
                {course.seatsLeft === 0
                  ? "Cohort is full — join the waitlist."
                  : `${course.seatsLeft} of ${course.seatsTotal} seats left`}
              </p>
            </div>
            <button type="button" onClick={() => setEnrollOpen(true)} data-cursor="enroll" className="mt-6 relative inline-flex items-center gap-2 rounded-full bg-white text-primary px-5 py-3 text-sm font-semibold">
              {course.seatsLeft === 0 ? "Join waitlist" : "Enroll now"} <ArrowUpRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </section>

      {/* RELATED */}
      <section className="px-4 md:px-10 py-14">
        <h2 className="font-display text-3xl md:text-4xl font-bold mb-8">Keep exploring</h2>
        <div className="grid gap-6 md:grid-cols-3">
          {related.map((c) => <CourseCard key={c.slug} course={c} />)}
        </div>
      </section>

      {/* Sticky enroll */}
      <div className="sticky bottom-4 z-40 px-4 md:px-10 pb-4">
        <div className="mx-auto max-w-3xl rounded-full bg-primary text-primary-foreground pl-6 pr-2 py-2 flex items-center gap-4 shadow-xl">
          <span className="font-semibold text-sm truncate">Ready for {course.title}?</span>
          <button type="button" onClick={() => setEnrollOpen(true)} className="ml-auto rounded-full bg-white text-primary px-5 py-2.5 text-sm font-semibold whitespace-nowrap">
            Enroll now
          </button>
        </div>
      </div>
      <LeadModal
        open={enrollOpen}
        onClose={() => setEnrollOpen(false)}
        badge={course.title}
        title={course.seatsLeft === 0 ? "Join the waitlist" : "Enroll in this course"}
        subtitle="Share your details and our admissions team will get back to you with the next steps."
        interest={course.title}
        institutionType="Course enquiry"
        cta={course.seatsLeft === 0 ? "Join waitlist" : "Request a callback"}
      />
    </Shell>
  );
}
