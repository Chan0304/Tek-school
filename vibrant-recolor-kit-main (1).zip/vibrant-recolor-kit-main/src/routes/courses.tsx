import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { Squiggle, Asterisk } from "@/components/Doodles";
import { Search, ArrowUpRight, Clock, Users } from "lucide-react";
import { useLayoutEffect, useRef, useState } from "react";
import { Reveal } from "@/components/Reveal";
import { COURSES_DATA, type CourseData } from "@/lib/courses-data";

export const Route = createFileRoute("/courses")({
  component: CoursesPage,
  head: () => ({
    meta: [
      { title: "Catalog — TekSchool" },
      { name: "description", content: "Browse the full TekSchool course catalog. Filter by category, level, and duration." },
      { property: "og:title", content: "Catalog — TekSchool" },
      { property: "og:description", content: "Browse the full TekSchool course catalog." },
    ],
  }),
});

const CATEGORIES = ["All", "Web Dev", "Design", "Data & AI", "Product", "Mobile"] as const;
const LEVELS = ["Any level", "Beginner", "Intermediate", "Advanced"] as const;
const DURATIONS = ["Any length", "≤ 8 weeks", "9–12 weeks", "13+ weeks"] as const;

function CoursesPage() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<(typeof CATEGORIES)[number]>("All");
  const [lvl, setLvl] = useState<(typeof LEVELS)[number]>("Any level");
  const [dur, setDur] = useState<(typeof DURATIONS)[number]>("Any length");

  const filtered = COURSES_DATA.filter((c) => {
    if (cat !== "All" && c.category !== cat) return false;
    if (lvl !== "Any level" && c.level !== lvl) return false;
    if (dur === "≤ 8 weeks" && c.weeks > 8) return false;
    if (dur === "9–12 weeks" && (c.weeks < 9 || c.weeks > 12)) return false;
    if (dur === "13+ weeks" && c.weeks < 13) return false;
    if (q && !c.title.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  });

  return (
    <Shell>
      <section className="relative px-4 md:px-10 pt-6 pb-10">
        <Squiggle className="pointer-events-none absolute right-10 top-4 h-24 w-56 opacity-60" />
        <div className="flex items-center gap-3 mb-4">
          <Asterisk className="h-8 w-8" color="var(--coral)" />
          <p className="pill-tag bg-muted text-muted-foreground"># Catalog</p>
        </div>
        <h1 className="font-display text-5xl md:text-6xl font-bold tracking-tight max-w-2xl leading-[0.95]">
          Find your path.
        </h1>
        <p className="mt-4 text-muted-foreground max-w-lg">
          Nine live cohorts. Real projects. Mentors who&apos;ve done it.
        </p>

        {/* Search */}
        <div className="mt-8 flex items-center gap-2 rounded-full border bg-white pl-5 pr-2 py-2 max-w-xl">
          <Search className="h-4 w-4 text-muted-foreground shrink-0" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search courses…"
            className="flex-1 bg-transparent py-2 text-sm outline-none min-w-0"
            maxLength={80}
          />
        </div>

        <div className="mt-6 space-y-3">
          <FilterRow label="Category" value={cat} options={CATEGORIES} onChange={setCat} accent="navy" />
          <FilterRow label="Level" value={lvl} options={LEVELS} onChange={setLvl} accent="coral" />
          <FilterRow label="Duration" value={dur} options={DURATIONS} onChange={setDur} accent="lavender" />
        </div>
      </section>

      <section className="px-4 md:px-10 pb-16">
        <p className="text-sm text-muted-foreground mb-6">{filtered.length} {filtered.length === 1 ? "course" : "courses"}</p>
        {filtered.length === 0 ? (
          <EmptyResults />
        ) : (
          // Key on filter signature so Reveal remounts and re-staggers on filter change.
          <div key={`${cat}|${lvl}|${dur}|${q}`} className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((c, i) => (
              <Reveal key={c.slug} index={i} y={16}><CourseCard course={c} /></Reveal>
            ))}
          </div>
        )}
      </section>
    </Shell>
  );
}

function FilterRow<T extends string>({
  label, value, options, onChange, accent,
}: {
  label: string;
  value: T;
  options: readonly T[];
  onChange: (v: T) => void;
  accent: "navy" | "coral" | "lavender";
}) {
  const activeBg =
    accent === "navy" ? "var(--primary)" :
    accent === "coral" ? "var(--coral)" :
    "var(--lavender)";
  const activeFg =
    accent === "navy" ? "var(--primary-foreground)" :
    accent === "coral" ? "var(--coral-foreground)" :
    "var(--lavender-foreground)";

  const rowRef = useRef<HTMLDivElement>(null);
  const [rect, setRect] = useState<{ left: number; width: number; height: number; top: number } | null>(null);

  useLayoutEffect(() => {
    const row = rowRef.current;
    if (!row) return;
    const active = row.querySelector<HTMLElement>(`[data-opt="${value}"]`);
    if (!active) return;
    const rr = row.getBoundingClientRect();
    const ar = active.getBoundingClientRect();
    setRect({ left: ar.left - rr.left, top: ar.top - rr.top, width: ar.width, height: ar.height });
  }, [value, options]);

  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className="text-xs font-semibold text-muted-foreground w-20 shrink-0">{label}</span>
      <div ref={rowRef} className="relative flex flex-wrap items-center gap-2">
        {rect && (
          <span
            aria-hidden
            className="absolute rounded-full pointer-events-none z-0"
            style={{
              left: rect.left,
              top: rect.top,
              width: rect.width,
              height: rect.height,
              background: activeBg,
              transition: "left 320ms var(--ease-out-soft), top 320ms var(--ease-out-soft), width 320ms var(--ease-out-soft)",
            }}
          />
        )}
        {options.map((o) => (
          <button
            key={o}
            data-opt={o}
            onClick={() => onChange(o)}
            className="pill-tag border border-transparent text-xs relative z-10 transition-colors"
            style={value === o
              ? { color: activeFg, background: "transparent" }
              : { background: "white", color: "var(--foreground)" }}
          >
            {o}
          </button>
        ))}
      </div>
    </div>
  );
}

export function CourseCard({ course }: { course: CourseData }) {
  const bg =
    course.color === "coral" ? "bg-[color:var(--coral)] text-[color:var(--coral-foreground)]"
      : course.color === "lavender" ? "bg-[color:var(--lavender)] text-[color:var(--lavender-foreground)]"
      : course.color === "blue" ? "gradient-blue text-white"
      : "bg-primary text-primary-foreground";
  const soldOut = course.seatsLeft === 0;
  return (
    <Link
      to="/courses/$slug"
      params={{ slug: course.slug }}
      data-cursor="enroll"
      className={`group rounded-[2rem] p-6 ${bg} flex flex-col min-h-[300px]`}
    >
      <div className="flex items-center justify-between">
        <span className="pill-tag bg-white/40 backdrop-blur-sm rotate-[-3deg]">
          # {course.category}
        </span>
        <span className="grid h-9 w-9 place-items-center rounded-full bg-white text-primary group-hover:rotate-45 transition-transform">
          <ArrowUpRight className="h-4 w-4" />
        </span>
      </div>
      <h3 className="font-display text-2xl font-bold mt-6 leading-tight">{course.title}</h3>
      <p className="mt-2 text-sm opacity-85">{course.blurb}</p>
      <div className="mt-4 flex items-baseline gap-2">
        <span className="font-display text-3xl font-bold">${course.price.toLocaleString()}</span>
        <span className="text-xs opacity-75">or ${course.priceMonthly}/mo</span>
      </div>
      <div className="mt-auto pt-4 flex items-center gap-3 text-xs font-medium flex-wrap">
        <span className="inline-flex items-center gap-1.5"><Clock className="h-3.5 w-3.5" />{course.duration}</span>
        <span className="inline-flex items-center gap-1.5"><Users className="h-3.5 w-3.5" />{course.students}</span>
        <span className="pill-tag bg-white/25 text-current text-[10px] py-0.5 px-2">{course.level}</span>
        <span className={`ml-auto pill-tag text-[10px] py-0.5 px-2 ${soldOut ? "bg-black/70 text-white" : "bg-white text-primary"}`}>
          {soldOut ? "Waitlist" : `${course.seatsLeft} seats`}
        </span>
      </div>
    </Link>
  );
}

function EmptyResults() {
  return (
    <div className="rounded-[2rem] border p-12 text-center">
      <Asterisk className="mx-auto h-16 w-16 mb-4" color="var(--accent-blue-deep)" />
      <h3 className="font-display text-2xl font-bold">Nothing matches — yet.</h3>
      <p className="mt-2 text-muted-foreground text-sm">Try a broader filter or clear your search.</p>
    </div>
  );
}
