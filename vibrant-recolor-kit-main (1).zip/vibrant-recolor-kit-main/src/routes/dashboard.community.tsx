import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { COHORT } from "@/lib/dashboard-data";
import { pushToast } from "@/lib/action-bus";
import { Avatar } from "@/components/Avatar";
import { MessageCircle, Users, Sparkles, TrendingUp, Award, Plus, Radio, Flame, X, Lock, Send, Smile, Hash, BadgeCheck } from "lucide-react";

export const Route = createFileRoute("/dashboard/community")({
  head: () => ({ meta: [{ title: "Community — Dashboard" }, { name: "robots", content: "noindex" }] }),
  component: CommunityPage,
});

type Room = { name: string; topic: string; desc: string; createdAt: string };

const STORAGE_KEY = "tek-community-room";

const TOPICS = ["AI & ML", "Placements", "Web & Cloud", "Study group", "Show & tell"];

const HIGHLIGHTS = [
  { who: "Meera S.", initials: "MS", photo: "https://randomuser.me/api/portraits/women/44.jpg", text: "walked everyone through her mini-RAG over the arXiv dataset", when: "12m", tag: "Live demo" },
  { who: "Karan V.", initials: "KV", photo: "https://randomuser.me/api/portraits/men/32.jpg", text: "asked how to handle class imbalance before the Module 3 test", when: "38m", tag: "Question" },
  { who: "Ananya (mentor)", initials: "AR", photo: "https://randomuser.me/api/portraits/women/65.jpg", text: "pinned the transformer cheat-sheet for tonight's session", when: "1h", tag: "Pinned" },
  { who: "Rohit D.", initials: "RD", photo: "https://randomuser.me/api/portraits/men/45.jpg", text: "shared a Razorpay interview experience — 3 rounds, DSA heavy", when: "2h", tag: "Placements" },
];

const TALKING_POINTS = [
  { label: "Model evaluation metrics", weight: 34 },
  { label: "Interview prep & referrals", weight: 27 },
  { label: "Module 3 doubts", weight: 21 },
  { label: "Project showcases", weight: 18 },
];

const OFFICIAL_ROOMS: (Room & { members: string; today: string })[] = [
  { name: "tek-announcements", topic: "Official", desc: "Cohort schedules, exam dates and everything TekSchool ships. Read-first channel for every batch.", createdAt: "Jan 2026", members: "3,412", today: "12" },
  { name: "placement-desk", topic: "Placements", desc: "Referrals, hiring drives and interview experiences posted by the TekSchool placement team.", createdAt: "Jan 2026", members: "2,180", today: "34" },
  { name: "doubt-clinic", topic: "Study group", desc: "Mentors on-call every evening 7–10 PM. Drop your blockers with code and get unstuck.", createdAt: "Feb 2026", members: "1,905", today: "58" },
  { name: "ai-lab", topic: "AI & ML", desc: "Paper reads, model releases and weekend build challenges run by the AI faculty.", createdAt: "Feb 2026", members: "1,244", today: "27" },
  { name: "show-and-tell", topic: "Show & tell", desc: "Ship something? Post it here. Best projects get featured on the TekSchool showcase.", createdAt: "Mar 2026", members: "986", today: "9" },
  { name: "career-guidance", topic: "Placements", desc: "Resume reviews, LinkedIn teardowns and 1:1 guidance slots from the careers team.", createdAt: "Mar 2026", members: "1,530", today: "16" },
];

function CommunityPage() {
  const [room, setRoom] = useState<Room | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [inRoom, setInRoom] = useState(false);
  const [official, setOfficial] = useState<Room | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setRoom(JSON.parse(raw) as Room);
    } catch { /* ignore */ }
  }, []);

  function createRoom(r: Room) {
    setRoom(r);
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(r)); } catch { /* ignore */ }
    setShowForm(false);
    pushToast(`Room “${r.name}” is live — invite your cohort.`);
  }

  return (
    <div className="space-y-8">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#5865F2] via-[#4752C4] to-[#3B458A] p-8 md:p-10 text-white">
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute -bottom-20 -left-10 h-56 w-56 rounded-full bg-[#F4A261]/20 blur-3xl" />
        <div className="relative grid gap-6 md:grid-cols-[1fr_auto] md:items-center">
          <div>
            <span className="pill-tag -rotate-2 bg-white/15 text-white backdrop-blur"><Sparkles className="h-3 w-3" /> Your cohort · Mar 2026</span>
            <h1 className="mt-3 font-display text-3xl md:text-4xl font-bold leading-tight">The room where it happens.</h1>
            <p className="mt-2 max-w-lg text-sm text-white/80">1,240 builders online right now. Spin up your own room, invite your cohort and keep the conversation in one place.</p>
            <div className="mt-5 flex flex-wrap items-center gap-3">
              <button
                onClick={() => (room ? pushToast("You can only create one room. Manage the one you have below.") : setShowForm(true))}
                disabled={!!room}
                className={`inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold transition-colors ${
                  room ? "cursor-not-allowed bg-white/20 text-white/70" : "bg-white text-[#5865F2] hover:bg-white/90"
                }`}
              >
                {room ? <><Lock className="h-4 w-4" /> Room created</> : <><Plus className="h-4 w-4" /> Create a room</>}
              </button>
              <div className="flex -space-x-2">
                {COHORT.slice(0, 5).map((m) => (
                  <div key={m.name} className="rounded-full ring-2 ring-[#4752C4]">
                    <Avatar name={m.name} initials={m.initials} photo={m.photo} size={36} />
                  </div>
                ))}
                <div className="grid h-9 w-9 place-items-center rounded-full border-2 border-[#4752C4] bg-white text-[10px] font-bold text-[#4752C4]">+42</div>
              </div>
            </div>
          </div>
          <div className="hidden md:block">
            <div className="grid grid-cols-2 gap-2">
              <MiniPill icon={Users} value="1,240" label="Online now" />
              <MiniPill icon={MessageCircle} value="86" label="Threads today" />
              <MiniPill icon={TrendingUp} value="+18" label="Wins this week" />
              <MiniPill icon={Award} value="12" label="Mentors on-call" />
            </div>
          </div>
        </div>
      </section>

      {/* Your room */}
      <section>
        <h2 className="mb-3 font-display text-xl font-bold">Your room</h2>
        {room ? (
          <div className="grid gap-4 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
            <div className="rounded-3xl border border-border bg-white p-6">
              <div className="flex flex-wrap items-start gap-4">
                <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-[var(--accent-blue-deep)] text-white"><Radio className="h-5 w-5" /></div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-display text-lg font-bold">{room.name}</h3>
                    <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-green-700">
                      <span className="h-1.5 w-1.5 rounded-full bg-green-500" /> Live
                    </span>
                    <span className="rounded-full bg-slate-100 px-2.5 py-0.5 text-[10px] font-semibold text-slate-600">{room.topic}</span>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{room.desc || "No description yet."}</p>
                  <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                    <span className="inline-flex items-center gap-1"><Users className="h-3 w-3" /> 24 members</span>
                    <span className="inline-flex items-center gap-1"><MessageCircle className="h-3 w-3" /> 86 messages today</span>
                    <span className="inline-flex items-center gap-1"><Flame className="h-3 w-3" /> 4 active threads</span>
                    <span>Created {room.createdAt}</span>
                  </div>
                </div>
                <button
                  onClick={() => setInRoom(true)}
                  className="rounded-full bg-[var(--accent-blue-deep)] px-5 py-2.5 text-sm font-bold text-white hover:opacity-90"
                >
                  Enter room
                </button>
              </div>

              <div className="mt-6 border-t border-border pt-5">
                <h4 className="font-display text-sm font-bold uppercase tracking-wide text-slate-500">Highlights — what's being talked about</h4>
                <ul className="mt-3 divide-y divide-border">
                  {HIGHLIGHTS.map((h, i) => (
                    <li key={i} className="flex items-center gap-3 py-3">
                      <Avatar name={h.who} initials={h.initials} photo={h.photo} size={36} />
                      <p className="min-w-0 flex-1 text-sm"><span className="font-semibold">{h.who}</span> <span className="text-muted-foreground">{h.text}</span></p>
                      <span className="shrink-0 rounded-full bg-slate-50 px-2.5 py-1 text-[10px] font-semibold text-slate-500">{h.tag}</span>
                      <span className="shrink-0 text-xs text-slate-400">{h.when}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="space-y-4">
              <div className="rounded-3xl border border-border bg-white p-5">
                <h4 className="font-display text-base font-bold">Top talking points</h4>
                <ul className="mt-4 space-y-3">
                  {TALKING_POINTS.map((t) => (
                    <li key={t.label}>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-slate-600">{t.label}</span>
                        <span className="font-bold text-slate-900">{t.weight}%</span>
                      </div>
                      <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-slate-200">
                        <div className="h-full rounded-full bg-[var(--accent-blue-deep)]" style={{ width: `${t.weight}%` }} />
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-3xl border border-border bg-white p-5">
                <h4 className="font-display text-base font-bold">Most active today</h4>
                <div className="mt-3 space-y-3">
                  {COHORT.slice(0, 4).map((m) => (
                    <div key={m.name} className="flex items-center gap-3">
                      <Avatar name={m.name} initials={m.initials} photo={m.photo} size={32} />
                      <p className="min-w-0 flex-1 truncate text-sm font-semibold">{m.name}</p>
                      <span className="text-xs text-muted-foreground">{12 - COHORT.indexOf(m) * 2} msgs</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="rounded-3xl border border-dashed border-border bg-white p-10 text-center">
            <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-slate-100 text-slate-500"><Radio className="h-5 w-5" /></div>
            <h3 className="mt-3 font-display text-lg font-bold">You haven't created a room yet</h3>
            <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">Every builder can create one room. Pick a topic, invite your cohort and the highlights of your conversations will show up here.</p>
            <button onClick={() => setShowForm(true)} className="mt-5 inline-flex items-center gap-2 rounded-full bg-[var(--accent-blue-deep)] px-5 py-2.5 text-sm font-bold text-white hover:opacity-90">
              <Plus className="h-4 w-4" /> Create a room
            </button>
          </div>
        )}
      </section>


      {/* Official channels */}
      <section>
        <div className="mb-3 flex items-center gap-2">
          <h2 className="font-display text-xl font-bold">Official channels</h2>
          <span className="inline-flex items-center gap-1 rounded-full bg-[var(--accent-blue-deep)]/10 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-[var(--accent-blue-deep)]">
            <BadgeCheck className="h-3 w-3" /> By TekSchool
          </span>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {OFFICIAL_ROOMS.map((r) => (
            <div key={r.name} className="flex flex-col rounded-3xl border border-border bg-white p-5">
              <div className="flex items-start gap-3">
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-[var(--accent-blue-deep)]/10 text-[var(--accent-blue-deep)]"><Hash className="h-4 w-4" /></div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <h3 className="truncate font-display text-base font-bold">{r.name}</h3>
                    <BadgeCheck className="h-4 w-4 shrink-0 text-[var(--accent-blue-deep)]" />
                  </div>
                  <p className="text-xs text-muted-foreground">{r.topic}</p>
                </div>
              </div>
              <p className="mt-3 flex-1 text-sm text-muted-foreground">{r.desc}</p>
              <div className="mt-4 flex items-center justify-between">
                <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1"><Users className="h-3 w-3" /> {r.members}</span>
                  <span className="inline-flex items-center gap-1"><MessageCircle className="h-3 w-3" /> {r.today} today</span>
                </div>
                <button
                  onClick={() => setOfficial(r)}
                  className="rounded-full bg-[var(--accent-blue-deep)] px-4 py-2 text-xs font-bold text-white hover:opacity-90"
                >
                  Enter
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {showForm && <CreateRoomModal onClose={() => setShowForm(false)} onCreate={createRoom} />}
      {inRoom && room && <RoomChat room={room} onClose={() => setInRoom(false)} />}
      {official && <RoomChat room={official} onClose={() => setOfficial(null)} />}
    </div>
  );
}

function CreateRoomModal({ onClose, onCreate }: { onClose: () => void; onCreate: (r: Room) => void }) {
  const [name, setName] = useState("");
  const [topic, setTopic] = useState(TOPICS[0]);
  const [desc, setDesc] = useState("");

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-slate-900/50 p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-display text-xl font-bold">Create your room</h3>
            <p className="mt-1 text-sm text-muted-foreground">One room per builder. You can rename it later.</p>
          </div>
          <button onClick={onClose} aria-label="Close" className="grid h-9 w-9 place-items-center rounded-full hover:bg-slate-100"><X className="h-4 w-4" /></button>
        </div>
        <form
          className="mt-5 space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            if (!name.trim()) return;
            onCreate({
              name: name.trim(),
              topic,
              desc: desc.trim(),
              createdAt: new Date().toLocaleDateString("en-IN", { day: "numeric", month: "short" }),
            });
          }}
        >
          <Field label="Room name">
            <input value={name} onChange={(e) => setName(e.target.value)} required placeholder="e.g. Weekend ML builders" className="h-11 w-full rounded-xl border border-border px-4 text-sm outline-none focus:border-[var(--accent-blue-deep)]" />
          </Field>
          <Field label="Topic">
            <select value={topic} onChange={(e) => setTopic(e.target.value)} className="h-11 w-full rounded-xl border border-border bg-white px-4 text-sm outline-none focus:border-[var(--accent-blue-deep)]">
              {TOPICS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="What's it about?">
            <textarea value={desc} onChange={(e) => setDesc(e.target.value)} rows={3} placeholder="A short description for people joining" className="w-full rounded-xl border border-border p-3 text-sm outline-none focus:border-[var(--accent-blue-deep)]" />
          </Field>
          <button type="submit" className="w-full rounded-full bg-[var(--accent-blue-deep)] px-5 py-3 text-sm font-bold text-white hover:opacity-90">Create room</button>
        </form>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-500">{label}</span>
      {children}
    </label>
  );
}

function MiniPill({ icon: Icon, value, label }: { icon: React.ElementType; value: string; label: string }) {
  return (
    <div className="rounded-2xl bg-white/10 p-3 backdrop-blur min-w-[120px]">
      <div className="flex items-center gap-1.5"><Icon className="h-3.5 w-3.5 opacity-80" /> <p className="font-display text-lg font-bold">{value}</p></div>
      <p className="text-[10px] font-semibold uppercase tracking-wider text-white/70">{label}</p>
    </div>
  );
}

type Msg = { id: number; who: string; initials: string; photo?: string; text: string; time: string; me?: boolean };

const SEED_MSGS: Msg[] = [
  { id: 1, who: "Ananya (mentor)", initials: "AR", photo: "https://randomuser.me/api/portraits/women/65.jpg", text: "Morning everyone 👋 pinned the transformer cheat-sheet at the top — read it before tonight's session.", time: "09:12" },
  { id: 2, who: "Karan V.", initials: "KV", photo: "https://randomuser.me/api/portraits/men/32.jpg", text: "Anyone hitting CUDA OOM on the LoRA notebook? batch 16 kills my colab.", time: "09:15" },
  { id: 3, who: "Meera S.", initials: "MS", photo: "https://randomuser.me/api/portraits/women/44.jpg", text: "Drop batch to 8 + grad accumulation 2. Same effective batch, half the memory.", time: "09:16" },
  { id: 4, who: "Arjun N.", initials: "AN", photo: "https://randomuser.me/api/portraits/men/41.jpg", text: "That worked for me yesterday. Also fp16 if you're not already.", time: "09:17" },
  { id: 5, who: "Divya P.", initials: "DP", photo: "https://randomuser.me/api/portraits/women/68.jpg", text: "Quick one — for Module 3 test, is confusion matrix in scope?", time: "09:21" },
  { id: 6, who: "Ananya (mentor)", initials: "AR", photo: "https://randomuser.me/api/portraits/women/65.jpg", text: "Yes. Precision/recall/F1 and when each one matters. Expect a scenario question.", time: "09:22" },
  { id: 7, who: "Faisal K.", initials: "FK", photo: "https://randomuser.me/api/portraits/men/76.jpg", text: "Shipped my mini-RAG over arXiv last night. Repo in the resources tab if anyone wants to poke at it 🙌", time: "09:30" },
  { id: 8, who: "Rhea M.", initials: "RM", photo: "https://randomuser.me/api/portraits/women/25.jpg", text: "Looking at it now — the chunking strategy is neat.", time: "09:33" },
];

const INCOMING: Omit<Msg, "id" | "time">[] = [
  { who: "Karan V.", initials: "KV", photo: "https://randomuser.me/api/portraits/men/32.jpg", text: "grad accumulation fixed it, thanks 🙏" },
  { who: "Meera S.", initials: "MS", photo: "https://randomuser.me/api/portraits/women/44.jpg", text: "Anyone up for a 30-min pair session after the class?" },
  { who: "Arjun N.", initials: "AN", photo: "https://randomuser.me/api/portraits/men/41.jpg", text: "I'm in. Let's do evaluation metrics practice." },
  { who: "Ananya (mentor)", initials: "AR", photo: "https://randomuser.me/api/portraits/women/65.jpg", text: "Great — I'll drop a problem set for you both." },
];

function now() {
  return new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: false });
}

function RoomChat({ room, onClose }: { room: Room; onClose: () => void }) {
  const [msgs, setMsgs] = useState<Msg[]>(SEED_MSGS);
  const [text, setText] = useState("");
  const [typing, setTyping] = useState(false);
  const [feed, setFeed] = useState(0);

  useEffect(() => {
    if (feed >= INCOMING.length) return;
    const t1 = setTimeout(() => setTyping(true), 4000);
    const t2 = setTimeout(() => {
      setTyping(false);
      setMsgs((m) => [...m, { ...INCOMING[feed], id: Date.now(), time: now() }]);
      setFeed((f) => f + 1);
    }, 6500);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [feed]);

  useEffect(() => {
    const el = document.getElementById("room-scroll");
    if (el) el.scrollTop = el.scrollHeight;
  }, [msgs, typing]);

  function send(e: React.FormEvent) {
    e.preventDefault();
    if (!text.trim()) return;
    setMsgs((m) => [...m, { id: Date.now(), who: "You", initials: "YO", text: text.trim(), time: now(), me: true }]);
    setText("");
  }

  const online = COHORT.filter((m) => m.online);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 p-0 backdrop-blur-sm md:p-6" onClick={onClose}>
      <div
        className="mx-auto flex h-full max-h-full w-full max-w-6xl flex-col overflow-hidden rounded-none bg-white md:rounded-3xl md:shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center gap-3 border-b border-border bg-[var(--accent-blue-deep)] px-4 py-3 text-white md:px-6">
          <div className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-white/15"><Hash className="h-4 w-4" /></div>
          <div className="min-w-0 flex-1">
            <h3 className="truncate font-display text-base font-bold">{room.name}</h3>
            <p className="truncate text-xs text-white/70">{online.length + 18} online · {room.topic}</p>
          </div>
          <div className="hidden -space-x-2 sm:flex">
            {COHORT.slice(0, 5).map((m) => (
              <div key={m.name} className="rounded-full ring-2 ring-[var(--accent-blue-deep)]">
                <Avatar name={m.name} initials={m.initials} photo={m.photo} size={28} />
              </div>
            ))}
          </div>
          <button onClick={onClose} aria-label="Leave room" className="grid h-9 w-9 place-items-center rounded-full hover:bg-white/15"><X className="h-4 w-4" /></button>
        </div>

        <div className="flex min-h-0 flex-1">
          {/* Messages */}
          <div className="flex min-w-0 flex-1 flex-col">
            <div id="room-scroll" className="tek-scroll-blue flex-1 space-y-4 overflow-y-auto px-4 py-5 md:px-6">
              {msgs.map((m) => (
                <div key={m.id} className={`flex gap-3 ${m.me ? "flex-row-reverse" : ""}`}>
                  <Avatar name={m.who} initials={m.initials} photo={m.photo} size={34} />
                  <div className={`max-w-[75%] ${m.me ? "text-right" : ""}`}>
                    <div className={`flex items-center gap-2 text-xs text-slate-500 ${m.me ? "justify-end" : ""}`}>
                      <span className="font-bold text-slate-700">{m.who}</span><span>{m.time}</span>
                    </div>
                    <div className={`mt-1 inline-block rounded-2xl px-3.5 py-2 text-sm ${m.me ? "bg-[var(--accent-blue-deep)] text-white" : "bg-slate-100 text-slate-800"}`}>
                      {m.text}
                    </div>
                  </div>
                </div>
              ))}
              {typing && (
                <div className="flex items-center gap-2 pl-1 text-xs text-slate-400">
                  <span className="flex gap-1">
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-400 [animation-delay:0ms]" />
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-400 [animation-delay:120ms]" />
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-400 [animation-delay:240ms]" />
                  </span>
                  someone is typing…
                </div>
              )}
            </div>
            <form onSubmit={send} className="flex items-center gap-2 border-t border-border px-4 py-3 md:px-6">
              <Smile className="h-5 w-5 shrink-0 text-slate-400" />
              <input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder={`Message ${room.name}`}
                className="h-11 min-w-0 flex-1 rounded-full border border-border px-4 text-sm outline-none focus:border-[var(--accent-blue-deep)]"
              />
              <button type="submit" aria-label="Send" className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-[var(--accent-blue-deep)] text-white hover:opacity-90">
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>

          {/* Members */}
          <aside className="hidden w-60 shrink-0 border-l border-border bg-slate-50 p-4 lg:block">
            <p className="text-xs font-bold uppercase tracking-wide text-slate-500">In the room</p>
            <div className="mt-3 space-y-3">
              {COHORT.map((m) => (
                <div key={m.name} className="flex items-center gap-2.5">
                  <div className="relative">
                    <Avatar name={m.name} initials={m.initials} photo={m.photo} size={30} />
                    <span className={`absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full ring-2 ring-slate-50 ${m.online ? "bg-green-500" : "bg-slate-300"}`} />
                  </div>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold">{m.name}</p>
                    <p className="truncate text-[11px] text-muted-foreground">{m.role}</p>
                  </div>
                </div>
              ))}
              <p className="pt-1 text-xs text-muted-foreground">+18 others</p>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
