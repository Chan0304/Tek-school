import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Shell } from "@/components/Shell";
import { Asterisk, Squiggle } from "@/components/Doodles";
import { X, ArrowRight } from "lucide-react";
import { LeadModal } from "@/components/LeadModal";
import instructor1 from "@/assets/instructor-1.jpg";
import instructor2 from "@/assets/instructor-2.jpg";
import instructor3 from "@/assets/instructor-3.jpg";
import instructor4 from "@/assets/instructor-4.jpg";

export const Route = createFileRoute("/instructors")({
  component: InstructorsPage,
  head: () => ({
    meta: [
      { title: "Faculty — TekSchool" },
      { name: "description", content: "Meet the working practitioners who teach at TekSchool." },
      { property: "og:title", content: "Faculty — TekSchool" },
      { property: "og:description", content: "Meet the practitioners teaching at TekSchool." },
    ],
  }),
});

type Dept = "Engineering" | "Design" | "Data & AI" | "Product" | "Mobile";
type Sort = "Featured" | "Name A–Z" | "Years teaching";
type Faculty = {
  name: string;
  title: string;
  department: Dept;
  specialty: string;
  bio: string;
  years: number;
  stat: string;
  quote: string;
  img: string;
  color: "coral" | "lavender" | "blue" | "navy";
};

const FACULTY: Faculty[] = [
  { name: "Sarah Chen", title: "Frontend Lead", department: "Engineering", specialty: "React & TypeScript", bio: "Ex-Stripe. 12 years shipping product UI at scale.", years: 12, stat: "Shipped 40+ product surfaces", quote: "I teach the stuff I wish someone had told me at year three.", img: instructor1, color: "coral" },
  { name: "David Park", title: "Full-Stack Instructor", department: "Engineering", specialty: "Node & Systems", bio: "Ex-Vercel. Builds and teaches production stacks end-to-end.", years: 10, stat: "Mentored 300+ engineers", quote: "The gap between tutorial code and real code is what school should close.", img: instructor2, color: "lavender" },
  { name: "Maya Rodriguez", title: "ML Lead", department: "Data & AI", specialty: "Applied ML", bio: "Applied ML researcher turned educator. Loves messy datasets.", years: 8, stat: "Published in NeurIPS x2", quote: "Models are easy. The problem framing is the whole job.", img: instructor3, color: "blue" },
  { name: "Alex Foster", title: "Design Director", department: "Design", specialty: "UX & Systems", bio: "Design lead across three consumer products.", years: 14, stat: "Led design at 3 startups", quote: "You don't design systems until you've maintained one.", img: instructor4, color: "navy" },
  { name: "Priya Shah", title: "AI Engineer", department: "Data & AI", specialty: "AI Engineering", bio: "Ships models and the apps around them.", years: 6, stat: "Deployed 20+ ML services", quote: "Evaluation is where the honest engineering happens.", img: instructor3, color: "coral" },
  { name: "Jordan Blake", title: "iOS Faculty", department: "Mobile", specialty: "Swift & SwiftUI", bio: "Swift, SwiftUI, and native craft since iOS 8.", years: 9, stat: "10 apps on the App Store", quote: "The platform rewards taste. So does the App Store.", img: instructor2, color: "blue" },
  { name: "Emma Liu", title: "Product Faculty", department: "Product", specialty: "Discovery & Strategy", bio: "Discovery, strategy, and the taste to say no.", years: 11, stat: "Two acquired products", quote: "PM is 80% deciding what not to do this quarter.", img: instructor1, color: "lavender" },
  { name: "Noah Reed", title: "Brand Lead", department: "Design", specialty: "Identity & Systems", bio: "Marks and systems for young companies.", years: 7, stat: "Rebranded 25+ startups", quote: "A brand isn't the logo. It's what people say when you leave the room.", img: instructor4, color: "navy" },
];

const DEPTS: (Dept | "All")[] = ["All", "Engineering", "Design", "Data & AI", "Product", "Mobile"];
const SORTS: Sort[] = ["Featured", "Name A–Z", "Years teaching"];

function InstructorsPage() {
  const [dept, setDept] = useState<(Dept | "All")>("All");
  const [sort, setSort] = useState<Sort>("Featured");
  const [active, setActive] = useState<Faculty | null>(null);
  const [teachOpen, setTeachOpen] = useState(false);
  const [askFaculty, setAskFaculty] = useState<string | null>(null);

  const shown = useMemo(() => {
    const filtered = dept === "All" ? FACULTY : FACULTY.filter((f) => f.department === dept);
    const sorted = [...filtered];
    if (sort === "Name A–Z") sorted.sort((a, b) => a.name.localeCompare(b.name));
    else if (sort === "Years teaching") sorted.sort((a, b) => b.years - a.years);
    return sorted;
  }, [dept, sort]);

  useEffect(() => {
    if (!active) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setActive(null); };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => { document.body.style.overflow = ""; window.removeEventListener("keydown", onKey); };
  }, [active]);

  return (
    <Shell>
      <section className="relative px-4 md:px-10 pt-6 pb-8">
        <Squiggle className="pointer-events-none absolute right-6 top-6 h-24 w-56 opacity-60" />
        <div className="flex items-center gap-3 mb-4">
          <Asterisk className="h-8 w-8" color="var(--accent-blue-deep)" />
          <p className="pill-tag bg-muted text-muted-foreground"># Faculty</p>
        </div>
        <h1 className="font-display text-5xl md:text-6xl font-bold tracking-tight max-w-3xl leading-[0.95]">
          The people behind the programs.
        </h1>
        <p className="mt-5 text-muted-foreground max-w-xl">
          Working practitioners, not lecturers. They&apos;re building the same things you&apos;re here to learn — and they still show up on demo night.
        </p>

        <div className="mt-6 flex flex-wrap items-center gap-3">
          <div className="flex flex-wrap gap-2">
            {DEPTS.map((d) => (
              <button
                key={d}
                onClick={() => setDept(d)}
                className={`pill-tag border transition-colors ${dept === d ? "bg-primary text-primary-foreground border-primary" : "bg-white text-foreground hover:bg-muted"}`}
              >
                {d}
              </button>
            ))}
          </div>
          <div className="ml-auto flex items-center gap-2">
            <label className="text-xs text-muted-foreground">Sort</label>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as Sort)}
              className="rounded-full border border-border bg-white px-3 py-1.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-primary/30"
            >
              {SORTS.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
        </div>
      </section>

      <section className="px-4 md:px-10 pb-12">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {shown.map((f, i) => {
            const bg =
              f.color === "coral" ? "bg-[color:var(--coral)]"
                : f.color === "lavender" ? "bg-[color:var(--lavender)]"
                : f.color === "blue" ? "gradient-blue"
                : "bg-primary";
            const textOnDark = f.color === "blue" || f.color === "navy";
            return (
              <button
                type="button"
                key={f.name}
                data-cursor="view"
                onClick={() => setActive(f)}
                className={`group relative rounded-[2rem] p-5 overflow-hidden min-h-[340px] flex flex-col text-left transition-transform hover:-translate-y-1 ${bg} ${textOnDark ? "text-white" : "text-primary"}`}
              >
                <div className="absolute -right-6 -bottom-6 h-40 w-40 rounded-full overflow-hidden border-4 border-white/80">
                  <img src={f.img} alt={f.name} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110" loading="lazy" />
                </div>
                <p className="text-xs font-semibold opacity-80">{f.department} · {f.specialty}</p>
                <div className="mt-auto max-w-[65%]">
                  <span className={`pill-tag bg-white text-primary shadow-md ${i % 2 ? "-rotate-3" : "rotate-2"} inline-flex`}>
                    {f.name}
                  </span>
                  <p className={`mt-2 text-[11px] font-semibold ${textOnDark ? "opacity-90" : "opacity-80"}`}>{f.title}</p>
                  <p className={`mt-2 text-xs ${textOnDark ? "opacity-85" : "opacity-75"} line-clamp-2`}>{f.bio}</p>
                </div>
              </button>
            );
          })}
        </div>

        {shown.length === 0 && (
          <p className="py-16 text-center text-muted-foreground">No faculty in this department yet.</p>
        )}
      </section>

      <section className="px-4 md:px-10 pb-16">
        <div className="relative overflow-hidden rounded-[2rem] bg-primary text-white p-8 md:p-12">
          <Squiggle className="pointer-events-none absolute -right-4 -bottom-4 h-40 w-72 opacity-30" />
          <p className="pill-tag bg-white/10 text-white/90 border border-white/20"># Teach with us</p>
          <h2 className="mt-4 font-display text-3xl md:text-4xl font-bold max-w-2xl leading-tight">
            Interested in teaching here?
          </h2>
          <p className="mt-3 text-white/80 max-w-xl">
            We hire practitioners who still ship. If that&apos;s you, we&apos;d love to talk.
          </p>
          <button
            type="button"
            onClick={() => setTeachOpen(true)}
            className="mt-6 inline-flex items-center gap-2 rounded-full bg-white text-primary px-5 py-2.5 text-sm font-semibold hover:bg-white/90"
          >
            Get in touch <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </section>

      {active && (
        <div
          className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-sm grid place-items-center p-4"
          onClick={() => setActive(null)}
          role="dialog"
          aria-modal="true"
        >
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); setActive(null); }}
            className="absolute top-4 right-4 grid h-11 w-11 place-items-center rounded-full bg-white text-primary"
            aria-label="Close"
          >
            <X className="h-5 w-5" />
          </button>
          <div
            className="w-full max-w-2xl rounded-[1.75rem] overflow-hidden bg-white"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="grid sm:grid-cols-[220px_1fr]">
              <div className="relative bg-muted min-h-[220px]">
                <img src={active.img} alt={active.name} className="absolute inset-0 h-full w-full object-cover" />
              </div>
              <div className="p-6">
                <p className="text-xs font-semibold text-muted-foreground">{active.department} · {active.specialty}</p>
                <h3 className="mt-1 font-display font-bold text-2xl">{active.name}</h3>
                <p className="text-sm text-muted-foreground">{active.title}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  <span className="pill-tag bg-[color:var(--lavender)] text-[color:var(--lavender-foreground)] text-xs">{active.years} yrs teaching</span>
                  <span className="pill-tag bg-[color:var(--coral)] text-[color:var(--coral-foreground)] text-xs">{active.stat}</span>
                </div>
                <p className="mt-4 text-sm text-foreground">{active.bio}</p>
                <blockquote className="mt-4 rounded-2xl bg-muted p-4 text-sm italic text-foreground">
                  “{active.quote}”
                </blockquote>
                <button
                  type="button"
                  onClick={() => { setAskFaculty(active.name); setActive(null); }}
                  className="mt-5 inline-flex items-center gap-2 rounded-full bg-primary text-white px-4 py-2 text-sm font-semibold hover:bg-primary/90"
                >
                  Ask about their class <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      <LeadModal
        open={teachOpen}
        onClose={() => setTeachOpen(false)}
        badge="Teach with us"
        title="Interested in teaching here?"
        subtitle="Tell us how to reach you and we'll set up a conversation."
        interest="Teaching enquiry"
        institutionType="Faculty application"
        cta="Send details"
      />
      <LeadModal
        open={askFaculty !== null}
        onClose={() => setAskFaculty(null)}
        badge="Faculty"
        title={`Ask about ${askFaculty ?? "this class"}`}
        subtitle="Share your details and we'll send class timings, syllabus, and seat availability."
        interest={askFaculty ?? "Faculty class enquiry"}
        institutionType="Class enquiry"
        cta="Send enquiry"
      />
    </Shell>
  );
}
