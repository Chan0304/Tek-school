import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell, NavyCard, WhiteTaskCard, SectionTitle } from "@/components/mobile/AppShell";
import { MobileModal, SheetPrimary, SheetGhost } from "@/components/mobile/MobileModal";
import { Toast } from "@/components/mobile/Nudges";
import { FileText, Check } from "lucide-react";

export const Route = createFileRoute("/app/exams")({
  head: () => ({ meta: [{ title: "Exams — TekSchool" }, { name: "robots", content: "noindex" }] }),
  component: ExamsScreen,
});

const UPCOMING = [
  { title: "Applied AI — Midterm", when: "Tomorrow · 6:00 PM IST", hours: 22, syllabus: ["Attention & transformers", "RAG pipelines", "Evaluation harnesses"] },
  { title: "Core ML — Quiz 4", when: "Fri · 8:00 PM IST", hours: 60, syllabus: ["Backprop derivation", "Optimizer trade-offs", "Regularization"] },
];

function ExamsScreen() {
  const [open, setOpen] = useState<number | null>(null);
  const [openMock, setOpenMock] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  function flash(m: string) { setToast(m); setTimeout(() => setToast(null), 1800); }

  return (
    <AppShell title="Exams">
      <div className="mt-5 space-y-3 px-5">
        {UPCOMING.map((e, i) => (
          <NavyCard
            key={e.title}
            live={e.hours < 48}
            eyebrow={e.hours < 48 ? `EXAM · IN ${e.hours}h` : "UPCOMING EXAM"}
            title={e.title}
            subtitle={e.when}
            action={<button onClick={() => setOpen(i)} className="inline-flex items-center gap-1.5 rounded-full bg-white px-4 py-2 text-xs font-bold text-[#1E1B4B] active:scale-95">View syllabus</button>}
          />
        ))}
      </div>

      <div className="mt-6">
        <SectionTitle title="Practice sets" />
        <div className="space-y-3 px-5">
          <WhiteTaskCard onClick={() => setOpenMock(true)} icon={<FileText className="h-3.5 w-3.5" />} eyebrow="Applied AI · 30 questions" title="Mock midterm — attention, RAG, evaluation" progress={0} caption="Not started · 45 min" />
          <WhiteTaskCard onClick={() => setOpenMock(true)} icon={<FileText className="h-3.5 w-3.5" />} eyebrow="Core ML · 20 questions" title="Backprop & optimization quick check" progress={60} caption="12 of 20 answered" />
        </div>
      </div>

      <MobileModal open={open !== null} onClose={() => setOpen(null)} eyebrow="Exam" title={open !== null ? UPCOMING[open].title : ""}
        footer={<><SheetPrimary onClick={() => { setOpen(null); flash("Added to your calendar"); }}>Add to calendar</SheetPrimary><SheetGhost onClick={() => setOpen(null)}>Close</SheetGhost></>}>
        {open !== null && (
          <>
            <p className="text-xs text-slate-500">{UPCOMING[open].when}</p>
            <ul className="mt-3 space-y-1.5">
              {UPCOMING[open].syllabus.map((s) => (
                <li key={s} className="rounded-xl bg-slate-100 px-3 py-2 text-sm font-medium text-slate-800">{s}</li>
              ))}
            </ul>
          </>
        )}
      </MobileModal>

      <MobileModal open={openMock} onClose={() => setOpenMock(false)} eyebrow="Practice" title="Start practice set"
        footer={<SheetPrimary onClick={() => { setOpenMock(false); flash("Practice started — good luck"); }}>Begin now</SheetPrimary>}>
        Untimed. Auto-saves after every answer. Review key after you submit.
      </MobileModal>

      <Toast show={!!toast} message={toast ?? ""} icon={Check} />
    </AppShell>
  );
}
