import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell, Greeting, NavyCard, WhiteTaskCard, PastelStat, SectionTitle } from "@/components/mobile/AppShell";
import { CLASSES, ASSIGNMENTS, formatDate } from "@/lib/dashboard-data";
import { Flame, Zap, FileText, ChevronRight, Play } from "lucide-react";

export const Route = createFileRoute("/app/")({
  head: () => ({ meta: [{ title: "Home — TekSchool" }, { name: "robots", content: "noindex" }] }),
  component: HomeScreen,
});

function HomeScreen() {
  const nextClass = CLASSES.filter((c) => c.status === "upcoming").sort((a, b) => a.date.localeCompare(b.date))[0];
  const dueTomorrow = ASSIGNMENTS.filter((a) => a.status === "due").sort((a, b) => a.dueDate.localeCompare(b.dueDate))[0];
  const startsIn = nextClass ? Math.round((new Date(nextClass.date).getTime() - Date.now()) / 60000) : 999;
  const canJoin = startsIn <= 15 && startsIn >= -90;
  const startTime = nextClass ? new Date(nextClass.date).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" }) : "";

  return (
    <AppShell>
      <Greeting />

      <div className="mt-5 flex gap-3 px-5">
        <PastelStat tone="peach" label="Streak" icon={<Flame className="h-3.5 w-3.5" />} value={12} unit="days" />
        <PastelStat tone="sky" label="XP · Week" icon={<Zap className="h-3.5 w-3.5" />} value={"420"} />
      </div>

      {nextClass && (
        <div className="mt-4 px-5">
          <NavyCard
            live
            eyebrow="Next Class · Today"
            title={nextClass.topic}
            subtitle={`with ${nextClass.instructor}`}
            action={
              <Link to="/app/class/$id" params={{ id: nextClass.id }} className={`inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-bold ${canJoin ? "bg-white text-[#1E1B4B]" : "bg-white/10 text-white/70"}`}>
                {canJoin ? <><Play className="h-3 w-3 fill-current" /> Join</> : `Starts at ${startTime}`}
              </Link>
            }
          />
        </div>
      )}

      {dueTomorrow && (
        <div className="mt-4 px-5">
          <p className="mb-3 text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">Due Tomorrow</p>
          <Link to="/app/task/$id" params={{ id: dueTomorrow.id }} className="block">
            <WhiteTaskCard
              icon={<FileText className="h-3.5 w-3.5" />}
              eyebrow={dueTomorrow.module}
              title={dueTomorrow.title}
              progress={35}
              caption="Draft saved · 35% complete"
            />
          </Link>
        </div>
      )}

      <div className="mt-6">
        <SectionTitle
          title="Keep going"
          action={<Link to="/app/tasks" className="text-xs font-semibold text-[#1E1B4B]">See all <ChevronRight className="inline h-3 w-3" /></Link>}
        />
        <div className="space-y-3 px-5">
          {ASSIGNMENTS.filter((a) => a.status === "due").slice(1, 3).map((a) => (
            <Link key={a.id} to="/app/task/$id" params={{ id: a.id }}>
              <WhiteTaskCard icon={<FileText className="h-3.5 w-3.5" />} eyebrow={a.module} title={a.title} progress={0} caption="Not started" />
            </Link>
          ))}
        </div>
      </div>

      <div className="mt-6 px-5">
        <NavyCard
          eyebrow="Daily Challenge"
          title="Explain LoRA rank vs alpha in 3 sentences"
          subtitle="+80 XP · reset in 6h 12m"
          action={<Link to="/app/challenge" className="inline-flex items-center gap-1 rounded-full bg-white/10 px-4 py-2 text-xs font-bold text-white">Take it <ChevronRight className="h-3 w-3" /></Link>}
        />
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3 px-5">
        <Link to="/app/placements" className="rounded-3xl bg-white p-4 shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)]">
          <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">Placements</p>
          <p className="mt-2 font-display text-lg font-bold">Razorpay · Interview</p>
          <p className="mt-0.5 text-[11px] text-slate-500">Round 2 · Tue</p>
        </Link>
        <Link to="/app/leaderboard" className="rounded-3xl bg-white p-4 shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)]">
          <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">Leaderboard</p>
          <p className="mt-2 font-display text-lg font-bold">#4 this week</p>
          <p className="mt-0.5 text-[11px] text-slate-500">210 XP to #3</p>
        </Link>
      </div>

      {nextClass && (
        <p className="mt-6 px-5 text-[11px] text-slate-400">
          Next class {formatDate(nextClass.date)}
        </p>
      )}
    </AppShell>
  );
}
