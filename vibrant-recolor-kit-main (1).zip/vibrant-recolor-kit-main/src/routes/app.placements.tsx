import { createFileRoute } from "@tanstack/react-router";
import { AppShell, SectionTitle } from "@/components/mobile/AppShell";
import { JOBS, APPLICATIONS } from "@/lib/dashboard-data";
import { Briefcase } from "lucide-react";

export const Route = createFileRoute("/app/placements")({
  head: () => ({ meta: [{ title: "Placements — TekSchool" }, { name: "robots", content: "noindex" }] }),
  component: PlacementsScreen,
});

const STAGES = ["Applied", "Screening", "Interview", "Offer"] as const;

function PlacementsScreen() {
  const readiness = 72;
  return (
    <AppShell title="Placements">
      <div className="mx-5 mt-5 rounded-3xl bg-white p-5 shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)]">
        <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">Readiness</p>
        <div className="mt-3 flex items-center gap-4">
          <div className="relative h-24 w-24">
            <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
              <circle cx="50" cy="50" r="42" stroke="#E5E7EB" strokeWidth="10" fill="none" />
              <circle cx="50" cy="50" r="42" stroke="#1E1B4B" strokeWidth="10" fill="none" strokeDasharray={`${(readiness / 100) * 264} 264`} strokeLinecap="round" />
            </svg>
            <div className="absolute inset-0 grid place-items-center font-display text-2xl font-black">{readiness}%</div>
          </div>
          <div className="flex-1 text-xs text-slate-600">
            <p><b className="text-slate-900">Portfolio</b> · complete</p>
            <p><b className="text-slate-900">Resume</b> · reviewed</p>
            <p><b className="text-slate-900">Mock interviews</b> · 2 of 4 done</p>
          </div>
        </div>
      </div>

      <div className="mt-6">
        <SectionTitle title="Your pipeline" />
        <div className="space-y-3 px-5">
          {APPLICATIONS.map((app) => {
            const idx = STAGES.indexOf(app.stage);
            return (
              <div key={app.id} className="rounded-3xl bg-white p-4 shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)]">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-display text-sm font-bold">{app.company}</p>
                    <p className="text-[11px] text-slate-500">{app.role} · {app.lastUpdate}</p>
                  </div>
                  <span className="rounded-full bg-[#DCEBFA] px-2.5 py-0.5 text-[10px] font-bold text-[#1F4E8A]">{app.stage}</span>
                </div>
                <div className="mt-3 flex items-center gap-1">
                  {STAGES.map((s, i) => (
                    <div key={s} className={`h-1.5 flex-1 rounded-full ${i <= idx ? "bg-[#1E1B4B]" : "bg-slate-200"}`} />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="mt-6">
        <SectionTitle title="Opportunities" />
        <div className="space-y-3 px-5">
          {JOBS.map((j) => (
            <div key={j.id} className="rounded-3xl bg-white p-4 shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)]">
              <div className="flex items-start gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-slate-100"><Briefcase className="h-4 w-4 text-slate-500" /></span>
                <div className="min-w-0 flex-1">
                  <p className="font-display text-sm font-bold leading-snug">{j.role}</p>
                  <p className="text-[11px] text-slate-500">{j.company} · {j.location}</p>
                  <p className="mt-1 text-[11px] font-semibold text-[#1F4E8A]">{j.salary} · {j.postedDays}d ago</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
