// Legacy route — redirects to the new Creative Studio.
import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/admin/canvas")({
  beforeLoad: () => {
    throw redirect({ to: "/admin/studio" });
  },
});
