import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell, PastelStat, SectionTitle } from "@/components/mobile/AppShell";
import { MobileModal, SheetPrimary, SheetGhost } from "@/components/mobile/MobileModal";
import { Toast } from "@/components/mobile/Nudges";
import { BADGES, GAMIFICATION } from "@/lib/dashboard-data";
import { useSession, signOut } from "@/lib/auth";
import { Flame, Zap, Settings, HelpCircle, Bell, Shield, ChevronRight, Trophy, Camera, Edit3, Award, Sparkles, Check } from "lucide-react";

export const Route = createFileRoute("/app/you")({
  head: () => ({ meta: [{ title: "You — TekSchool" }, { name: "robots", content: "noindex" }] }),
  component: YouScreen,
});

function YouScreen() {
  const session = useSession();
  const name = session?.name ?? "Aditi Sharma";
  const initials = session?.avatarInitials ?? name.split(" ").map((n) => n[0]).slice(0, 2).join("");
  const track = session?.track ?? "AI Engineering";
  const earned = BADGES.filter((b) => b.earned);
  const [openEdit, setOpenEdit] = useState(false);
  const [openSetting, setOpenSetting] = useState<string | null>(null);
  const [openSignOut, setOpenSignOut] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  function flash(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 1800);
  }

  const xpPct = Math.min(100, Math.round((GAMIFICATION.xp / GAMIFICATION.xpForNext) * 100));

  return (
    <AppShell title="You">
      {/* Hero profile card */}
      <div className="relative mx-5 mt-5 overflow-hidden rounded-[28px] p-6 text-white" style={{ background: "linear-gradient(160deg,#1E1B4B 0%,#2D5FA8 100%)" }}>
        <div className="absolute -right-14 -top-14 h-48 w-48 rounded-full bg-[#5BA4E8]/25 blur-3xl" />
        <div className="absolute -bottom-12 -left-10 h-40 w-40 rounded-full bg-[#F4A261]/20 blur-3xl" />
        <div className="relative flex items-center gap-4">
          <div className="relative">
            <div className="grid h-20 w-20 place-items-center rounded-full bg-white/15 text-2xl font-black backdrop-blur ring-4 ring-white/20">{initials}</div>
            <button onClick={() => flash("Photo upload coming soon")} className="absolute -bottom-1 -right-1 grid h-8 w-8 place-items-center rounded-full bg-[#F4A261] text-white shadow-lg" aria-label="Change photo">
              <Camera className="h-3.5 w-3.5" />
            </button>
          </div>
          <div className="min-w-0 flex-1">
            <p className="font-display text-xl font-black leading-tight">{name}</p>
            <p className="text-xs text-white/70">{session?.cohort ?? "March '26"} · Week {session?.weekCurrent ?? 5}/{session?.weekTotal ?? 12}</p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              <span className="rounded-full bg-white/15 px-2.5 py-0.5 text-[10px] font-bold backdrop-blur">{track}</span>
              <span className="rounded-full bg-[#F4A261]/25 px-2.5 py-0.5 text-[10px] font-bold text-[#FFD8B5] backdrop-blur">Level {GAMIFICATION.level}</span>
            </div>
          </div>
        </div>

        <div className="relative mt-5">
          <div className="flex items-baseline justify-between text-xs">
            <span className="font-bold">{GAMIFICATION.xp} XP</span>
            <span className="text-white/70">{GAMIFICATION.xpForNext - GAMIFICATION.xp} XP to Level {GAMIFICATION.level + 1}</span>
          </div>
          <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-white/15">
            <div className="h-full rounded-full bg-gradient-to-r from-[#F4A261] to-[#F7C99B]" style={{ width: `${xpPct}%` }} />
          </div>
        </div>

        <button onClick={() => setOpenEdit(true)} className="relative mt-5 inline-flex items-center gap-1.5 rounded-full bg-white/15 px-4 py-2 text-xs font-bold backdrop-blur active:scale-95">
          <Edit3 className="h-3 w-3" /> Edit profile
        </button>
      </div>

      {/* Stat pair */}
      <div className="mt-4 flex gap-3 px-5">
        <PastelStat tone="peach" label="Streak" icon={<Flame className="h-3.5 w-3.5" />} value={GAMIFICATION.streak} unit="days" />
        <PastelStat tone="sky" label="XP · Week" icon={<Zap className="h-3.5 w-3.5" />} value={"420"} />
      </div>

      {/* Progress ring row */}
      <div className="mx-5 mt-4 grid grid-cols-3 gap-2 rounded-3xl bg-white p-4 shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)]">
        <StatRing label="Attendance" value={92} tone="#1E5B33" />
        <StatRing label="Assignments" value={78} tone="#1E1B4B" />
        <StatRing label="Readiness" value={72} tone="#B45613" />
      </div>

      {/* Badges */}
      <div className="mt-6">
        <SectionTitle title={`Badges · ${earned.length}/${BADGES.length}`} action={<Link to="/app/leaderboard" className="text-xs font-semibold text-[#1E1B4B]">Leaderboard <ChevronRight className="inline h-3 w-3" /></Link>} />
        <div className="grid grid-cols-4 gap-3 px-5">
          {BADGES.slice(0, 8).map((b) => (
            <div key={b.id} className={`flex flex-col items-center gap-1 rounded-2xl p-2 ${b.earned ? "bg-white shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)]" : "bg-slate-100/60 opacity-50"}`}>
              <span className={`grid h-10 w-10 place-items-center rounded-full ${b.earned ? "bg-[#FCE5D0] text-[#B45613]" : "bg-slate-200 text-slate-400"}`}>
                <Trophy className="h-4 w-4" />
              </span>
              <span className="text-center text-[9px] font-bold leading-tight text-slate-700">{b.name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Achievements banner */}
      <div className="mx-5 mt-6 rounded-3xl bg-[#DEF2E4] p-4">
        <div className="flex items-start gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-white text-[#1E5B33]"><Award className="h-4 w-4" /></span>
          <div className="flex-1">
            <p className="font-display text-sm font-bold text-[#1E5B33]">You're on a roll</p>
            <p className="mt-0.5 text-xs text-[#1E5B33]/80">Ship this week's RAG assignment to unlock <b>Mentor Magnet</b>.</p>
          </div>
        </div>
      </div>

      {/* Settings */}
      <div className="mt-6">
        <SectionTitle title="Settings" />
        <div className="mx-5 divide-y divide-slate-100 overflow-hidden rounded-3xl bg-white shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)]">
          {[
            { key: "notif", icon: Bell, label: "Notifications", meta: "On · 4 types" },
            { key: "privacy", icon: Shield, label: "Privacy", meta: "Cohort only" },
            { key: "help", icon: HelpCircle, label: "Help & support" },
            { key: "account", icon: Settings, label: "Account settings" },
          ].map((r) => (
            <button key={r.key} onClick={() => setOpenSetting(r.key)} className="flex w-full items-center gap-3 px-4 py-3 text-left active:bg-slate-50">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-slate-100"><r.icon className="h-4 w-4 text-slate-600" /></span>
              <div className="flex-1">
                <p className="text-sm font-semibold text-slate-900">{r.label}</p>
                {r.meta && <p className="text-[11px] text-slate-500">{r.meta}</p>}
              </div>
              <ChevronRight className="h-4 w-4 text-slate-400" />
            </button>
          ))}
        </div>
        <button onClick={() => setOpenSignOut(true)} className="mx-5 mt-4 w-[calc(100%-2.5rem)] rounded-full border border-slate-200 bg-white py-3 text-sm font-semibold text-slate-700 active:scale-[0.99]">Sign out</button>
        <p className="mt-3 text-center text-[10px] text-slate-400">TekSchool · v1.0 · March '26 cohort</p>
      </div>

      {/* Modals */}
      <MobileModal open={openEdit} onClose={() => setOpenEdit(false)} eyebrow="Profile" title="Edit profile"
        footer={<><SheetPrimary onClick={() => { setOpenEdit(false); flash("Profile updated"); }}>Save changes</SheetPrimary><SheetGhost onClick={() => setOpenEdit(false)}>Cancel</SheetGhost></>}>
        <div className="space-y-3">
          <label className="block">
            <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-slate-500">Display name</span>
            <input defaultValue={name} className="mt-1.5 w-full rounded-2xl bg-slate-100 px-4 py-3 text-sm font-medium focus:outline-none" />
          </label>
          <label className="block">
            <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-slate-500">Bio</span>
            <textarea defaultValue="Switching from analytics to applied AI. Loves RAG systems and long walks." rows={3} className="mt-1.5 w-full rounded-2xl bg-slate-100 px-4 py-3 text-sm focus:outline-none" />
          </label>
        </div>
      </MobileModal>

      <MobileModal open={openSetting !== null} onClose={() => setOpenSetting(null)} eyebrow="Settings"
        title={openSetting === "notif" ? "Notifications" : openSetting === "privacy" ? "Privacy" : openSetting === "help" ? "Help & support" : "Account"}>
        {openSetting === "notif" && (
          <div className="space-y-2">
            {["Class starting soon","Assignment due tomorrow","Mentor kudos","Leaderboard changes"].map((t) => (
              <label key={t} className="flex items-center justify-between rounded-2xl bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-800">
                {t}<input type="checkbox" defaultChecked className="h-5 w-5 accent-[#1E1B4B]" />
              </label>
            ))}
          </div>
        )}
        {openSetting === "privacy" && (
          <p>Your profile, streak, and XP are visible to your cohort only. Mentors see your submissions and progress. Nothing is shared outside TekSchool.</p>
        )}
        {openSetting === "help" && (
          <div className="space-y-2">
            <button className="w-full rounded-2xl bg-slate-50 px-4 py-3 text-left text-sm font-semibold">Message the placements team</button>
            <button className="w-full rounded-2xl bg-slate-50 px-4 py-3 text-left text-sm font-semibold">Report an issue</button>
            <button className="w-full rounded-2xl bg-slate-50 px-4 py-3 text-left text-sm font-semibold">FAQ</button>
          </div>
        )}
        {openSetting === "account" && (
          <div className="space-y-2 text-sm">
            <div className="rounded-2xl bg-slate-50 p-3"><p className="text-[11px] font-bold uppercase text-slate-500">Email</p><p>{session?.email ?? "aditi.sharma@tekschool.in"}</p></div>
            <div className="rounded-2xl bg-slate-50 p-3"><p className="text-[11px] font-bold uppercase text-slate-500">Cohort</p><p>{session?.cohort ?? "March '26"}</p></div>
            <button className="w-full rounded-2xl bg-[#FCE5D0] px-4 py-3 text-left text-sm font-semibold text-[#B45613]">Change password</button>
          </div>
        )}
      </MobileModal>

      <MobileModal open={openSignOut} onClose={() => setOpenSignOut(false)} eyebrow="Sign out" title="Ready to leave?"
        footer={<>
          <SheetPrimary onClick={() => { signOut(); setOpenSignOut(false); }}>Yes, sign me out</SheetPrimary>
          <SheetGhost onClick={() => setOpenSignOut(false)}>Stay signed in</SheetGhost>
        </>}>
        You'll need to sign in again to pick up where you left off.
      </MobileModal>

      <Toast show={!!toast} message={toast ?? ""} icon={Check} />
    </AppShell>
  );
}

function StatRing({ label, value, tone }: { label: string; value: number; tone: string }) {
  return (
    <div className="flex flex-col items-center">
      <div className="relative h-16 w-16">
        <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
          <circle cx="50" cy="50" r="42" stroke="#E5E7EB" strokeWidth="10" fill="none" />
          <circle cx="50" cy="50" r="42" stroke={tone} strokeWidth="10" fill="none" strokeDasharray={`${(value / 100) * 264} 264`} strokeLinecap="round" />
        </svg>
        <div className="absolute inset-0 grid place-items-center text-sm font-black text-slate-900">{value}%</div>
      </div>
      <p className="mt-1 text-[10px] font-bold uppercase tracking-[0.1em] text-slate-500">{label}</p>
    </div>
  );
}
