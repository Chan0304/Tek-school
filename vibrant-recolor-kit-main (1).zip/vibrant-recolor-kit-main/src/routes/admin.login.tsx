// Split-screen admin login. Left: form. Right: rotating product-shot showcase.
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { LogoLockup } from "@/components/Logo";
import { signInDemo } from "@/lib/auth";
import { Sparkles, ArrowRight, Loader2, Lock, Mail, ShieldCheck } from "lucide-react";
import { pushToast } from "@/lib/action-bus";

export const Route = createFileRoute("/admin/login")({
  head: () => ({
    meta: [
      { title: "Sign in — TekSchool Admin" },
      { name: "robots", content: "noindex" },
      { name: "description", content: "Sign in to the TekSchool admin workspace." },
    ],
  }),
  component: AdminLogin,
});

const SLIDES = [
  { badge: "Overview", title: "Every KPI, one glance.", copy: "168 active students. Attendance, enrolments, revenue — live." },
  { badge: "Placements", title: "Pipeline that moves itself.", copy: "AI sources verified HRs. You just drag cards to close." },
  { badge: "Creative Studio", title: "A design tool that ships.", copy: "Drag, resize, AI-generate. Publish straight to WhatsApp and the site." },
];

function AdminLogin() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<"super" | "admissions" | "instructor" | "finance">("super");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [slide, setSlide] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setSlide((s) => (s + 1) % SLIDES.length), 4200);
    return () => clearInterval(t);
  }, []);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!/^\S+@\S+\.\S+$/.test(email)) return setError("Enter a valid work email.");
    if (password.length < 4) return setError("Password must be at least 4 characters.");
    setLoading(true);
    setTimeout(() => {
      signInDemo(email);
      if (typeof window !== "undefined") localStorage.setItem("tek-admin-role", role);
      pushToast("Welcome back to the admin workspace");
      navigate({ to: "/admin" });
    }, 500);
  };

  return (
    <div className="grid min-h-screen w-full grid-cols-1 lg:grid-cols-[45fr_55fr]">
      {/* LEFT — form */}
      <div className="flex min-h-screen flex-col justify-between bg-white px-6 py-8 sm:px-12 lg:px-16">
        <div className="flex items-center justify-between">
          <LogoLockup className="h-8" />
          <span className="rounded-md bg-slate-100 px-2 py-1 text-[10px] font-bold uppercase tracking-widest text-slate-500">Internal</span>
        </div>

        <div className="mx-auto w-full max-w-sm py-10">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-lavender/40 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-[#1E1B4B]">
            <ShieldCheck className="h-3 w-3" /> Admin workspace
          </span>
          <h1 className="mt-4 font-display text-4xl font-bold tracking-tight sm:text-5xl">Welcome back.</h1>
          <p className="mt-2 text-sm text-slate-500">Everything TekSchool, in one place — programs, students, placements, campaigns.</p>

          <form onSubmit={submit} className="mt-8 space-y-4" noValidate>
            <FloatField id="email" label="Work email" type="email" icon={Mail} value={email} onChange={setEmail} autoFocus />
            <FloatField id="password" label="Password" type="password" icon={Lock} value={password} onChange={setPassword} />

            <div>
              <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-widest text-slate-400">Signing in as</p>
              <div className="grid grid-cols-2 gap-1.5">
                {([
                  ["super", "Super admin"],
                  ["admissions", "Admissions"],
                  ["instructor", "Instructor"],
                  ["finance", "Finance"],
                ] as const).map(([k, l]) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => setRole(k)}
                    className={`rounded-xl px-3 py-2 text-left text-[11px] font-semibold transition-colors ${role === k ? "bg-[#1E1B4B] text-white shadow-[0_10px_25px_-12px_#1E1B4B]" : "bg-slate-50 text-slate-600 hover:bg-slate-100"}`}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>

            {error && <div className="rounded-xl bg-coral/15 px-3 py-2 text-xs font-medium text-coral tek-shake">{error}</div>}

            <button
              type="submit"
              disabled={loading}
              className="group inline-flex w-full items-center justify-center gap-2 rounded-full bg-[#1E1B4B] px-5 py-3.5 text-sm font-semibold text-white shadow-[0_16px_40px_-16px_#1E1B4B] transition-all hover:-translate-y-0.5 hover:bg-[#141238] disabled:opacity-70"
            >
              {loading ? <><Loader2 className="h-4 w-4 animate-spin" /> Signing you in…</> : <>Sign in <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" /></>}
            </button>

            <div className="flex items-center justify-between text-xs">
              <button type="button" className="font-semibold text-[var(--accent-blue-deep)] hover:underline">Forgot password?</button>
              <span className="text-slate-400">SSO available for owners</span>
            </div>
          </form>
        </div>

        <p className="text-center text-[11px] text-slate-400">
          Demo · any email + 4+ char password unlocks the workspace. No real credentials are stored.
        </p>
      </div>

      {/* RIGHT — showcase (hidden on mobile) */}
      <div className="relative hidden overflow-hidden bg-gradient-to-br from-[#1E1B4B] via-[#2D5FA8] to-[#0F3460] lg:block">
        <div className="absolute inset-0 opacity-40" style={{ backgroundImage: "radial-gradient(circle at 30% 20%, rgba(244,162,97,0.35), transparent 45%), radial-gradient(circle at 70% 80%, rgba(212,196,232,0.4), transparent 40%)" }} />
        <div className="absolute inset-0 grid place-items-center">
          <div className="relative w-[85%] max-w-[640px]">
            {SLIDES.map((s, i) => (
              <div
                key={s.title}
                className={`absolute inset-0 transition-all duration-700 ${i === slide ? "translate-y-0 opacity-100" : i < slide ? "-translate-y-6 opacity-0" : "translate-y-6 opacity-0"}`}
                style={{ transitionTimingFunction: "cubic-bezier(0.16,1,0.3,1)" }}
              >
                <MockCard slideKey={i} slide={s} />
              </div>
            ))}
            <div className="mt-[520px] flex items-center justify-center gap-1.5">
              {SLIDES.map((_, i) => (
                <button key={i} onClick={() => setSlide(i)} className={`h-1.5 rounded-full transition-all ${i === slide ? "w-8 bg-white" : "w-1.5 bg-white/40"}`} />
              ))}
            </div>
          </div>
        </div>

        <div className="absolute bottom-10 left-10 right-10 text-white">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-3 py-1 text-[10px] font-bold uppercase tracking-widest backdrop-blur">
            <Sparkles className="h-3 w-3" /> Everything, in one place
          </span>
          <p className="mt-2 font-display text-2xl font-bold leading-tight">Everything TekSchool, in one place.</p>
          <p className="mt-1 max-w-md text-sm text-white/70">Programs, students, placements, campaigns, and a real creative studio — one workspace, zero switching.</p>
        </div>
      </div>
    </div>
  );
}

function FloatField({ id, label, type, icon: Icon, value, onChange, autoFocus }: {
  id: string; label: string; type: string; icon: typeof Mail; value: string; onChange: (v: string) => void; autoFocus?: boolean;
}) {
  const [focused, setFocused] = useState(false);
  const active = focused || value.length > 0;
  return (
    <div className={`relative rounded-2xl bg-slate-50 px-3.5 pb-2 pt-5 transition-colors ${focused ? "ring-2 ring-[#1E1B4B]/20 bg-white" : ""}`}>
      <label htmlFor={id} className={`pointer-events-none absolute left-11 transition-all ${active ? "top-1.5 text-[10px] font-bold uppercase tracking-widest text-slate-500" : "top-1/2 -translate-y-1/2 text-sm text-slate-400"}`}>{label}</label>
      <Icon className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
      <input
        id={id}
        type={type}
        autoFocus={autoFocus}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        className="w-full bg-transparent pl-8 text-sm outline-none"
        autoComplete={type === "password" ? "current-password" : "email"}
      />
    </div>
  );
}

function MockCard({ slide, slideKey }: { slide: (typeof SLIDES)[number]; slideKey: number }) {
  return (
    <div className="rounded-3xl bg-white p-5 shadow-[0_40px_100px_-30px_rgba(15,23,42,0.5)]">
      <div className="flex items-center justify-between">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-[#1E1B4B]/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-[#1E1B4B]">{slide.badge}</span>
        <div className="flex gap-1">{[0,1,2].map(i => <span key={i} className="h-1.5 w-1.5 rounded-full bg-slate-200" />)}</div>
      </div>
      <h3 className="mt-3 font-display text-xl font-bold">{slide.title}</h3>
      <p className="text-[11px] text-slate-500">{slide.copy}</p>
      {slideKey === 0 && (
        <div className="mt-4 grid grid-cols-4 gap-2">
          {[
            ["168", "Students"], ["₹48L", "Revenue"], ["87%", "Placement"], ["+38%", "YoY"],
          ].map(([v, l]) => (
            <div key={l} className="rounded-xl bg-slate-50 p-2">
              <p className="font-display text-lg font-bold tabular-nums">{v}</p>
              <p className="text-[9px] uppercase tracking-widest text-slate-400">{l}</p>
            </div>
          ))}
        </div>
      )}
      {slideKey === 1 && (
        <div className="mt-4 grid grid-cols-5 gap-1.5 text-[9px] font-semibold">
          {["Applied","Screen","Interview","Offer","Placed"].map((s, i) => (
            <div key={s} className="rounded-lg p-1.5" style={{ background: ["#94A3B8","#5BA4E8","#2D5FA8","#F4A261","#10B981"][i] + "22" }}>
              <p className="uppercase tracking-wider text-slate-500">{s}</p>
              <p className="text-sm font-bold text-slate-800">{[9,7,5,3,2][i]}</p>
            </div>
          ))}
        </div>
      )}
      {slideKey === 2 && (
        <div className="mt-4 grid grid-cols-3 gap-1.5">
          <div className="aspect-square rounded-xl bg-gradient-to-br from-[#1E1B4B] to-[#5BA4E8] p-2 text-white">
            <p className="text-[8px] font-bold uppercase">Cohort 08</p>
            <p className="mt-4 text-[10px] font-black leading-tight">AI ENG</p>
          </div>
          <div className="aspect-square rounded-xl bg-coral p-2 text-[#1E1B4B]">
            <p className="text-[8px] font-bold uppercase">Placement</p>
            <p className="mt-3 text-[10px] font-black leading-tight">₹22 LPA</p>
          </div>
          <div className="aspect-square rounded-xl bg-lavender p-2 text-[#1E1B4B]">
            <p className="text-[8px] font-bold uppercase">Workshop</p>
            <p className="mt-3 text-[10px] font-black leading-tight">Sat 10 AM</p>
          </div>
        </div>
      )}
    </div>
  );
}
