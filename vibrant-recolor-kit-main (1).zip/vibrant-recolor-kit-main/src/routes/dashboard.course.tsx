import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ClassesPage } from "@/routes/dashboard.classes";
import { LiveRoomPage } from "@/routes/dashboard.live-room";
import { AssignmentsPage } from "@/routes/dashboard.assignments";
import { BookOpen, Video, ClipboardList } from "lucide-react";

export const Route = createFileRoute("/dashboard/course")({
  head: () => ({ meta: [{ title: "Course — Dashboard" }, { name: "robots", content: "noindex" }] }),
  component: CoursePage,
});

type Tab = "live-room" | "classes" | "assignments";

const TABS: { key: Tab; label: string; icon: typeof BookOpen }[] = [
  { key: "live-room", label: "Live class", icon: Video },
  { key: "classes", label: "Classes", icon: BookOpen },
  { key: "assignments", label: "Assignment", icon: ClipboardList },
];


function CoursePage() {
  const [tab, setTab] = useState<Tab>("live-room");

  return (
    <div className="fixed inset-x-0 bottom-0 top-16 z-20 flex flex-col bg-[#F6F7FB] lg:left-12">
      {/* Mobile horizontal tabs — stuck to top, flush left */}
      <div className="no-scrollbar flex shrink-0 overflow-x-auto border-b border-slate-200 bg-white py-2 pl-0 pr-2 lg:hidden">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex shrink-0 items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition-colors first:ml-0 ${
              tab === t.key ? "bg-[var(--accent-blue-deep)] text-white" : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Desktop vertical tabs — fixed flush to left edge of viewport */}
      <div className="fixed left-0 top-16 z-30 hidden w-12 flex-col gap-1.5 overflow-hidden rounded-r-3xl bg-white py-2 shadow-[2px_0_12px_-4px_rgba(15,23,42,0.08)] lg:flex">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`group relative flex shrink-0 items-center justify-center rounded-r-2xl py-4 text-[11px] font-bold uppercase tracking-wide transition-all ${
              tab === t.key
                ? "bg-[var(--accent-blue-deep)] text-white shadow-[0_6px_16px_-6px_rgba(15,23,42,0.45)]"
                : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
            }`}
          >
            <span className="flex flex-col-reverse items-center gap-[3px] leading-none">
              {t.label
                .toUpperCase()
                .split("")
                .map((ch, i) => (
                  <span key={`${t.key}-${i}`}>{ch === " " ? "\u00A0" : ch}</span>
                ))}
            </span>
          </button>
        ))}
      </div>

      {/* Content — fills remaining fixed viewport area and scrolls internally */}
      <div className="flex-1 overflow-y-auto p-4 lg:p-6">
        {tab === "classes" && <ClassesPage />}
        {tab === "live-room" && <LiveRoomPage />}
        {tab === "assignments" && <AssignmentsPage />}
      </div>

    </div>
  );
}
