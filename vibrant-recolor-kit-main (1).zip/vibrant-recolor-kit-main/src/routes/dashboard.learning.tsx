import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { TekGuru } from "@/components/TekGuru";
import { TestRunner, type TestMeta } from "@/components/dashboard/TestRunner";
import { CodeRunner } from "@/components/dashboard/CodeRunner";
import { HomeOverview } from "@/components/dashboard/HomeOverview";
import { useSession } from "@/lib/auth";
import { Sparkles, Dumbbell, FileCheck2, Clock, Play, Check, Gauge, TrendingUp, Target, BookOpen, Code2, Trophy, Flame, Terminal } from "lucide-react";

export const Route = createFileRoute("/dashboard/learning")({
  head: () => ({
    meta: [
      { title: "Learning — TekSchool Dashboard" },
      { name: "description", content: "Practice sets, mock tests and assessments with Tek Guru, your always-on learning mentor." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: LearningPage,
});

type Item = {
  id: string;
  title: string;
  meta: string;
  duration: string;
  status: "not-started" | "in-progress" | "done";
  score?: string;
  questions: number;
  attempts: number;
  weight: string;
  attemptedOn?: string;
  due?: string;
  progress?: number;
  topics: string[];
};

const DEFAULT_PRACTICE: TestMeta = {
  id: "practice-lab",
  title: "Daily coding lab",
  meta: "Practice",
  duration: "Unlimited",
  mode: "practice",
};

const ASSESSMENTS: Item[] = [
  {
    id: "a1",
    title: "Module 1 test — Python foundations",
    meta: "Module 1",
    duration: "60 min",
    status: "done",
    score: "91%",
    questions: 30,
    attempts: 1,
    weight: "10%",
    attemptedOn: "29 Jul",
    topics: ["Data structures", "Functions", "OOP basics"],
  },
  {
    id: "a2",
    title: "Module 2 test — Statistics for ML",
    meta: "Module 2",
    duration: "60 min",
    status: "done",
    score: "78%",
    questions: 30,
    attempts: 2,
    weight: "10%",
    attemptedOn: "12 Aug",
    topics: ["Distributions", "Hypothesis testing", "Bayes"],
  },
  {
    id: "a3",
    title: "Module 3 test — Supervised learning",
    meta: "Module 3",
    duration: "75 min",
    status: "in-progress",
    questions: 30,
    attempts: 1,
    weight: "15%",
    due: "Due in 2 days",
    progress: 50,
    topics: ["Regression", "Classification", "Model metrics"],
  },
  {
    id: "a4",
    title: "Module 4 test — Deep learning basics",
    meta: "Module 4",
    duration: "75 min",
    status: "not-started",
    questions: 30,
    attempts: 0,
    weight: "15%",
    due: "Opens 04 Sep",
    topics: ["Neural nets", "Backprop", "Regularisation"],
  },
  {
    id: "a5",
    title: "Capstone assessment",
    meta: "Final evaluation",
    duration: "120 min",
    status: "not-started",
    questions: 45,
    attempts: 0,
    weight: "30%",
    due: "Opens 22 Sep",
    topics: ["End-to-end ML", "Case study", "Deployment"],
  },
];

const TOPIC_PERFORMANCE = [
  { name: "Python & data structures", score: 91 },
  { name: "Descriptive statistics", score: 84 },
  { name: "Probability & Bayes", score: 62 },
  { name: "Hypothesis testing", score: 58 },
  { name: "Supervised learning", score: 71 },
];

const ASSESSMENT_HISTORY = [
  { id: "h1", title: "Module 2 test — attempt 2", score: 78, date: "12 Aug", delta: 11, time: "54 min" },
  { id: "h2", title: "Module 2 test — attempt 1", score: 67, date: "09 Aug", delta: -24, time: "60 min" },
  { id: "h3", title: "Module 1 test", score: 91, date: "29 Jul", delta: 9, time: "47 min" },
];


const MODULES = [
  {
    id: "m1",
    name: "Python foundations",
    lessonsDone: 12,
    lessons: 12,
    score: 91,
    strengths: ["Data structures", "Functions & scope"],
    improve: ["Comprehension chaining", "Error handling edge cases"],
  },
  {
    id: "m2",
    name: "Statistics for ML",
    lessonsDone: 10,
    lessons: 10,
    score: 78,
    strengths: ["Descriptive stats", "Distributions"],
    improve: ["Hypothesis testing", "Confidence intervals", "Bayes reasoning"],
  },
  {
    id: "m3",
    name: "Supervised learning",
    lessonsDone: 6,
    lessons: 11,
    score: null,
    strengths: [],
    improve: [],
  },
  {
    id: "m4",
    name: "Deep learning basics",
    lessonsDone: 0,
    lessons: 14,
    score: null,
    strengths: [],
    improve: [],
  },
] as const;

const PRACTICE_STATS = {
  totalProblems: 86,
  solvedProblems: 54,
  successRate: 78,
  streakDays: 6,
  languages: [
    { name: "Python", solved: 32, color: "bg-sky-500" },
    { name: "SQL", solved: 12, color: "bg-amber-500" },
    { name: "JavaScript", solved: 10, color: "bg-violet-500" },
  ],
  weakTopics: ["Recursion", "Dynamic programming", "Joins & subqueries"],
  recent: [
    { id: "p1", title: "Two-sum variant", status: "solved", language: "Python", difficulty: "Easy" },
    { id: "p2", title: "Balanced brackets", status: "solved", language: "Python", difficulty: "Medium" },
    { id: "p3", title: "Longest increasing subsequence", status: "attempted", language: "Python", difficulty: "Hard" },
    { id: "p4", title: "Customer churn query", status: "solved", language: "SQL", difficulty: "Medium" },
  ],
};

const WEEKLY_ACTIVITY = [
  { day: "Mon", minutes: 65 },
  { day: "Tue", minutes: 40 },
  { day: "Wed", minutes: 95 },
  { day: "Thu", minutes: 25 },
  { day: "Fri", minutes: 80 },
  { day: "Sat", minutes: 120 },
  { day: "Sun", minutes: 35 },
];

const TIME_STATS = {
  thisWeekMins: 460,
  lastWeekMins: 385,
  totalHours: 68,
  avgSessionMins: 42,
  attendance: 92,
  cohortRank: 7,
  cohortSize: 48,
};

const SKILLS = [
  { name: "Python", level: 88 },
  { name: "Statistics", level: 74 },
  { name: "Machine learning", level: 61 },
  { name: "SQL", level: 79 },
  { name: "Problem solving", level: 70 },
];

const UPCOMING = [
  { id: "u1", title: "Module 3 test — Supervised learning", due: "Due in 2 days", type: "Assessment" },
  { id: "u2", title: "Assignment: Regression report", due: "Due in 4 days", type: "Assignment" },
  { id: "u3", title: "Live class — Neural nets intro", due: "Tomorrow, 6:00 pm", type: "Live class" },
];

const RECENT_SCORES = [
  { id: "s1", title: "Module 2 test", score: 78, date: "12 Aug", delta: -13 },
  { id: "s2", title: "Practice quiz — Distributions", score: 84, date: "08 Aug", delta: +6 },
  { id: "s3", title: "Module 1 test", score: 91, date: "29 Jul", delta: +9 },
];


const TABS = [
  { key: "overview", label: "Overview", icon: Gauge },
  { key: "tek-guru", label: "Tek Guru", icon: Sparkles },
  { key: "practice", label: "Practice", icon: Dumbbell },
  { key: "assessment", label: "Assessment", icon: FileCheck2 },
] as const;

function LearningPage() {
  const session = useSession();
  const [tab, setTab] = useState<(typeof TABS)[number]["key"]>("overview");
  const [active, setActive] = useState<TestMeta | null>(null);


  function launch(it: Item) {
    setActive({
      id: it.id,
      title: it.title,
      meta: it.meta,
      duration: it.duration,
      mode: "assessment",
      // Resuming an in-progress test drops the student back in the middle
      startAt: it.status === "in-progress" ? 15 : 0,
    });
  }


  if (active) {
    return (
      <div className="fixed inset-x-0 bottom-0 top-16 z-30 flex flex-col bg-[#F6F7FB] lg:left-20">
        <TestRunner test={active} onExit={() => setActive(null)} className="h-full" />
      </div>
    );
  }

  return (
    <div className="fixed inset-x-0 bottom-0 top-16 z-20 flex flex-col bg-[#F6F7FB] lg:left-12">
      {/* Mobile horizontal tabs — stuck to top, flush left */}
      <div className="no-scrollbar flex shrink-0 overflow-x-auto border-b border-slate-200 bg-white py-2 pl-0 pr-2 lg:hidden">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex shrink-0 items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition-colors first:ml-0 ${
              tab === t.key ? "bg-[var(--accent-blue-deep)] text-white" : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Desktop vertical tabs — fixed flush to left edge of viewport */}
      <div className="fixed left-0 top-16 z-30 hidden w-12 flex-col gap-1.5 overflow-hidden rounded-r-3xl bg-white py-2 shadow-[2px_0_12px_-4px_rgba(15,23,42,0.08)] lg:flex">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`group relative flex shrink-0 items-center justify-center gap-2 rounded-r-2xl py-4 text-[11px] font-bold uppercase tracking-wide transition-all ${
              tab === t.key
                ? "bg-[var(--accent-blue-deep)] text-white shadow-[0_6px_16px_-6px_rgba(15,23,42,0.45)]"
                : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
            }`}
          >
            <span className="flex flex-col-reverse items-center gap-[3px] leading-none">
              {t.label
                .toUpperCase()
                .split("")
                .map((ch, i) => (
                  <span key={`${t.key}-${i}`}>{ch === " " ? "\u00A0" : ch}</span>
                ))}
            </span>
          </button>
        ))}
      </div>



      {/* Content — fills remaining fixed viewport area */}
      <div className="flex-1 overflow-hidden">
        {tab === "overview" && (
          <OverviewPanel
            name={session?.name.split(" ")[0]}
            onGoAssessment={() => setTab("assessment")}
            onGoPractice={() => setTab("practice")}
          />
        )}
        {tab === "tek-guru" && (

          <TekGuru studentName={session?.name.split(" ")[0]} className="h-full rounded-none border-0 shadow-none" />
        )}
        {tab === "practice" && <CodeRunner test={DEFAULT_PRACTICE} onExit={() => {}} className="h-full" />}
        {tab === "assessment" && <AssessmentList onLaunch={launch} className="h-full" />}
      </div>
    </div>
  );
}

function AssessmentList({ onLaunch, className }: { onLaunch: (it: Item) => void; className?: string }) {
  const completed = ASSESSMENTS.filter((i) => i.status === "done").length;
  const weightDone = ASSESSMENTS.filter((i) => i.status === "done").reduce((a, i) => a + parseInt(i.weight, 10), 0);

  return (
    <div className={`flex h-full flex-col gap-5 overflow-y-auto p-4 lg:p-6 ${className ?? ""}`}>
      <div className="grid shrink-0 gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <StatTile label="Avg score" value="85" unit="%" tone="from-violet-500 to-indigo-500" />
        <StatTile label="Completed" value={`${completed}`} unit={`/${ASSESSMENTS.length}`} tone="from-emerald-500 to-teal-500" />
        <StatTile label="Best score" value="91" unit="%" tone="from-sky-500 to-cyan-500" />
        <StatTile label="Time on tests" value="2" unit="h 41m" tone="from-amber-500 to-orange-500" />
        <StatTile label="Grade weight earned" value={`${weightDone}`} unit="% of 80%" tone="from-fuchsia-500 to-pink-500" />
      </div>

      <div className="grid flex-1 gap-5 xl:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
        <div className="flex flex-col overflow-hidden dash-card">
          <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
            <h2 className="font-display text-base font-bold text-slate-900">All assessments</h2>
            <span className="text-xs font-semibold text-slate-500">{ASSESSMENTS.length} scheduled · 1 in progress</span>
          </div>
          <ul className="flex-1 overflow-y-auto">
            {ASSESSMENTS.map((it) => {
              const done = it.status === "done";
              const active = it.status === "in-progress";
              return (
                <li
                  key={it.id}
                  className={`border-b border-slate-100 px-6 py-4 last:border-b-0 ${active ? "bg-sky-50" : "hover:bg-slate-50/60"}`}
                >
                  <div className="flex flex-wrap items-center gap-4">
                    <span
                      className={`grid h-11 w-11 shrink-0 place-items-center rounded-full ${
                        done ? "bg-emerald-100 text-emerald-600" : active ? "bg-sky-100 text-sky-600" : "bg-slate-100 text-slate-400"
                      }`}
                    >
                      {done ? <Check className="h-5 w-5" /> : <Play className="h-4 w-4 fill-current" />}
                    </span>
                    <div className="min-w-[180px] flex-1">
                      <h3 className="truncate font-display text-base font-bold text-slate-900">{it.title.split(" — ")[0]}</h3>
                      <p className="mt-0.5 truncate text-sm text-slate-500">{it.title.split(" — ")[1] ?? it.meta}</p>
                      <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500">
                        <span className="inline-flex items-center gap-1">
                          <Clock className="h-3.5 w-3.5" /> {it.duration}
                        </span>
                        <span>{it.questions} questions</span>
                        <span>Weight {it.weight}</span>
                        <span>{it.attempts} attempt{it.attempts === 1 ? "" : "s"}</span>
                        {it.attemptedOn && <span>Taken {it.attemptedOn}</span>}
                        {it.due && <span className="font-semibold text-amber-600">{it.due}</span>}
                      </div>
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {it.topics.map((tp) => (
                          <span key={tp} className="rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-semibold text-slate-600">
                            {tp}
                          </span>
                        ))}
                      </div>
                      {active && typeof it.progress === "number" && (
                        <div className="mt-3 max-w-xs">
                          <div className="h-1.5 overflow-hidden rounded-full bg-slate-200">
                            <div className="h-full rounded-full bg-sky-500" style={{ width: `${it.progress}%` }} />
                          </div>
                          <p className="mt-1 text-[11px] font-semibold text-sky-700">{it.progress}% answered · resume where you left off</p>
                        </div>
                      )}
                    </div>
                    <div className="flex shrink-0 items-center gap-3">
                      {done ? (
                        <div className="text-right">
                          <p className="font-display text-xl font-extrabold text-emerald-600">{it.score}</p>
                          <p className="text-[11px] text-slate-500">Passed</p>
                        </div>
                      ) : active ? (
                        <button
                          onClick={() => onLaunch(it)}
                          className="inline-flex items-center gap-2 rounded-xl bg-sky-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-sky-700"
                        >
                          Resume <Play className="h-3.5 w-3.5 fill-current" />
                        </button>
                      ) : (
                        <button
                          onClick={() => onLaunch(it)}
                          className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-5 py-2.5 text-sm font-semibold text-slate-800 hover:bg-slate-50"
                        >
                          Start <Play className="h-3.5 w-3.5 fill-current" />
                        </button>
                      )}
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>

        <div className="flex flex-col gap-5">
          <div className="dash-card p-5">
            <h2 className="font-display text-base font-bold text-slate-900">Topic performance</h2>
            <ul className="mt-4 space-y-3">
              {TOPIC_PERFORMANCE.map((t) => (
                <li key={t.name}>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">{t.name}</span>
                    <span className={`font-bold ${t.score >= 80 ? "text-emerald-600" : t.score >= 65 ? "text-amber-600" : "text-rose-600"}`}>
                      {t.score}%
                    </span>
                  </div>
                  <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-slate-200">
                    <div
                      className={`h-full rounded-full ${t.score >= 80 ? "bg-emerald-500" : t.score >= 65 ? "bg-amber-500" : "bg-rose-500"}`}
                      style={{ width: `${t.score}%` }}
                    />
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div className="dash-card p-5">
            <h2 className="font-display text-base font-bold text-slate-900">Attempt history</h2>
            <ul className="mt-4 space-y-3">
              {ASSESSMENT_HISTORY.map((h) => (
                <li key={h.id} className="flex items-center justify-between gap-3 border-b border-slate-100 pb-3 last:border-b-0 last:pb-0">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-slate-800">{h.title}</p>
                    <p className="text-xs text-slate-500">{h.date} · {h.time}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-display text-lg font-extrabold text-slate-900">{h.score}%</p>
                    <p className={`text-[11px] font-bold ${h.delta >= 0 ? "text-emerald-600" : "text-rose-600"}`}>
                      {h.delta >= 0 ? "+" : ""}{h.delta} pts
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div className="dash-card p-5">
            <h2 className="font-display text-base font-bold text-slate-900">Focus before next test</h2>
            <ul className="mt-3 space-y-2 text-sm text-slate-600">
              {["Hypothesis testing — revisit p-values", "Bayes reasoning practice set", "Model metrics: precision vs recall"].map((s) => (
                <li key={s} className="flex items-start gap-2">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--accent-blue-deep)]" />
                  {s}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}


function StatTile({ label, value, unit, tone }: { label: string; value: string; unit: string; tone: string }) {
  return (
    <div className={`rounded-2xl bg-gradient-to-br p-5 text-white ${tone}`}>
      <p className="text-sm font-semibold text-white/75">{label}</p>
      <p className="mt-1 font-display">
        <span className="text-3xl font-extrabold">{value}</span>
        <span className="text-base font-bold">{unit}</span>
      </p>
    </div>
  );
}

function OverviewPanel({ name, onGoAssessment, onGoPractice }: { name?: string; onGoAssessment: () => void; onGoPractice: () => void }) {
  void name; void onGoAssessment; void onGoPractice;
  return (
    <div className="h-full w-full overflow-y-auto p-4 lg:p-6">
      <HomeOverview />
    </div>
  );
}

function MiniStat({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="dash-card p-4">
      <p className="text-[11px] font-bold uppercase tracking-wide text-slate-500">{label}</p>
      <p className="mt-1 font-display text-2xl font-extrabold text-slate-900">{value}</p>
      <p className="text-xs text-slate-500">{sub}</p>
    </div>
  );
}

function Ring({ label, pct, sub }: { label: string; pct: number; sub: string }) {
  return (
    <div className="flex items-center gap-3 rounded-2xl bg-white/10 p-4 backdrop-blur-sm">
      <div
        className="grid h-16 w-16 shrink-0 place-items-center rounded-full"
        style={{ background: `conic-gradient(#fff ${pct * 3.6}deg, rgba(255,255,255,0.22) 0deg)` }}
      >
        <span className="grid h-12 w-12 place-items-center rounded-full bg-[rgba(30,27,75,0.85)] text-sm font-extrabold">
          {pct}%
        </span>
      </div>
      <div className="min-w-0">
        <p className="text-sm font-bold">{label}</p>
        <p className="text-xs text-white/70">{sub}</p>
      </div>
    </div>
  );
}
