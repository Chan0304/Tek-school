import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { PhoneFrame } from "@/components/mobile/PhoneFrame";
import { useSession } from "@/lib/auth";

export const Route = createFileRoute("/app/splash")({
  head: () => ({ meta: [{ title: "TekSchool" }, { name: "robots", content: "noindex" }] }),
  component: SplashScreen,
});

function SplashScreen() {
  const navigate = useNavigate();
  const session = useSession();

  useEffect(() => {
    const t = setTimeout(() => {
      navigate({ to: session ? "/app" : "/app/login" });
    }, 2200);
    return () => clearTimeout(t);
  }, [navigate, session]);

  return (
    <PhoneFrame>
      <div
        className="relative flex min-h-full flex-col items-center justify-center overflow-hidden text-white"
        style={{ background: "linear-gradient(160deg,#0F0D2E 0%,#1E1B4B 40%,#2D5FA8 100%)" }}
      >
        <div className="absolute -left-20 top-16 h-64 w-64 rounded-full bg-[#5BA4E8]/25 blur-3xl animate-pulse" />
        <div className="absolute -right-16 bottom-24 h-56 w-56 rounded-full bg-[#F4A261]/20 blur-3xl animate-pulse" style={{ animationDelay: "0.6s" }} />
        <div className="absolute left-10 bottom-40 h-40 w-40 rounded-full bg-white/5 blur-2xl" />

        <div className="relative z-10 flex flex-col items-center">
          <div className="h-10 w-10 rounded-full border-4 border-white/30 border-t-white animate-spin" />
        </div>

      </div>
    </PhoneFrame>
  );
}
