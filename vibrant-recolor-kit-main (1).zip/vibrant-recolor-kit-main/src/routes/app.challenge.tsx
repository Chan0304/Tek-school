import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell, NavyCard, PastelStat } from "@/components/mobile/AppShell";
import { MobileModal, SheetPrimary } from "@/components/mobile/MobileModal";
import { Toast } from "@/components/mobile/Nudges";
import { Flame, Zap, ArrowLeft, Check } from "lucide-react";
import { QUESTS } from "@/lib/dashboard-data";

export const Route = createFileRoute("/app/challenge")({
  head: () => ({ meta: [{ title: "Challenge — TekSchool" }, { name: "robots", content: "noindex" }] }),
  component: ChallengeScreen,
});

function ChallengeScreen() {
  const [open, setOpen] = useState(false);
  const [answer, setAnswer] = useState("");
  const [toast, setToast] = useState<string | null>(null);
  function flash(m: string) { setToast(m); setTimeout(() => setToast(null), 1800); }

  return (
    <AppShell title="Challenge">
      <div className="px-5 pt-3">
        <Link to="/app" className="inline-flex items-center gap-1 text-xs font-semibold text-slate-500"><ArrowLeft className="h-3.5 w-3.5" /> Back</Link>
      </div>

      <div className="mt-3 px-5">
        <NavyCard
          live
          eyebrow="DAILY CHALLENGE · RESET IN 6H"
          title="Explain LoRA rank vs alpha in 3 sentences"
          subtitle="+80 XP · streak bonus if you keep 5 days"
          action={<button onClick={() => setOpen(true)} className="inline-flex items-center gap-1.5 rounded-full bg-white px-4 py-2 text-xs font-bold text-[#1E1B4B] active:scale-95">Start</button>}
        />
      </div>

      <div className="mt-4 flex gap-3 px-5">
        <PastelStat tone="peach" label="Streak" icon={<Flame className="h-3.5 w-3.5" />} value={12} unit="days" />
        <PastelStat tone="sky" label="Weekly XP" icon={<Zap className="h-3.5 w-3.5" />} value={"420"} />
      </div>

      <div className="mt-6 px-5">
        <h3 className="mb-3 font-display text-base font-bold">Active quests</h3>
        <div className="space-y-3">
          {QUESTS.map((q) => (
            <div key={q.id} className="rounded-3xl bg-white p-4 shadow-[0_2px_8px_-4px_rgba(15,23,42,0.08)]">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-display text-sm font-bold">{q.title}</p>
                  <p className="mt-0.5 text-[11px] text-slate-500">{q.desc} · {q.expires}</p>
                </div>
                <span className="shrink-0 rounded-full bg-[#FCE5D0] px-2 py-0.5 text-[10px] font-bold text-[#B45613]">+{q.xp} XP</span>
              </div>
              <div className="mt-3 h-1.5 rounded-full bg-slate-100"><div className="h-full rounded-full bg-[#1E1B4B]" style={{ width: `${(q.progress / q.total) * 100}%` }} /></div>
              <p className="mt-1 text-[11px] text-slate-500">{q.progress} / {q.total}</p>
            </div>
          ))}
        </div>
      </div>

      <MobileModal open={open} onClose={() => setOpen(false)} eyebrow="Daily challenge · +80 XP" title="Explain LoRA rank vs alpha"
        footer={<SheetPrimary onClick={() => { if (answer.trim().length > 20) { setOpen(false); setAnswer(""); flash("Nice — +80 XP earned"); } else { flash("Answer needs a bit more detail"); } }}>Submit answer</SheetPrimary>}>
        <p className="text-xs text-slate-500">Three sentences. Mentor-reviewed within 24h.</p>
        <textarea autoFocus value={answer} onChange={(e) => setAnswer(e.target.value)} rows={5} placeholder="Rank controls the size of the low-rank update…" className="mt-3 w-full rounded-2xl bg-slate-100 p-3 text-sm focus:outline-none" />
      </MobileModal>

      <Toast show={!!toast} message={toast ?? ""} icon={Check} />
    </AppShell>
  );
}
