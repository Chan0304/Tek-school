# Hosting this app on AWS (Node.js)

## What this project is

A **TanStack Start v1** full-stack React 19 app (Vite 7). It is *not* a static
site: it does server-side rendering, exposes server functions and API routes
(`/api/chat`, `/api/admin-chat`, `/api/ai-copy`, `/api/ai-image`, `/sitemap.xml`)
and talks to a Supabase (Postgres) backend. So it needs a **Node.js runtime**
on AWS — S3 alone will not run it.

Nothing about the app's features, pages, or design changes; only the build
output target changes from a Cloudflare Worker bundle to a Node server bundle.

## Build a Node server bundle

```bash
npm install
npm run build:node          # uses vite.aws.config.ts (Nitro node-server preset)
node .output/server/index.mjs
```

The server listens on `PORT` (default 3000) and `HOST` (use `0.0.0.0` in containers).
Static client assets are served by the same Node process from `.output/public`.

> Note: run this build on your own machine, in CI, or in Docker. Running it
> inside the Lovable sandbox always forces the Cloudflare target.

`npm run build` (the original script) is unchanged so Lovable publishing still works.

## Environment variables

Set these on the AWS side (ECS task definition, App Runner config, EB env, or systemd unit):

Required at **build time** (baked into the browser bundle):
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`
- `VITE_SUPABASE_PROJECT_ID`

Required at **runtime** (server only — store in AWS Secrets Manager / SSM Parameter Store):
- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `LOVABLE_API_KEY` — for the AI chat/copy/image endpoints
- optional: `SLACK_WEBHOOK_URL`, `RESEND_API_KEY`, `RESEND_FROM_EMAIL`

## Option A — Docker on ECS Fargate / App Runner (recommended)

```bash
docker build -t tekschool \
  --build-arg VITE_SUPABASE_URL=... \
  --build-arg VITE_SUPABASE_PUBLISHABLE_KEY=... \
  --build-arg VITE_SUPABASE_PROJECT_ID=... .

aws ecr get-login-password --region ap-south-1 \
  | docker login --username AWS --password-stdin <acct>.dkr.ecr.ap-south-1.amazonaws.com
docker tag tekschool <acct>.dkr.ecr.ap-south-1.amazonaws.com/tekschool:latest
docker push <acct>.dkr.ecr.ap-south-1.amazonaws.com/tekschool:latest
```

Then create an ECS Fargate service (or App Runner service) from that image:
- container port `3000`
- health check path `/`
- put an Application Load Balancer + ACM certificate in front
- point Route 53 at the ALB
- optionally add CloudFront in front for global asset caching

## Option B — EC2 (simplest)

```bash
# on the instance (Amazon Linux 2023)
sudo dnf install -y nodejs git nginx
git clone <your-repo> && cd <repo>
npm install && npm run build:node

sudo tee /etc/systemd/system/tekschool.service >/dev/null <<'EOF'
[Unit]
Description=TekSchool
After=network.target

[Service]
WorkingDirectory=/home/ec2-user/<repo>
Environment=NODE_ENV=production
Environment=PORT=3000
Environment=HOST=0.0.0.0
EnvironmentFile=/etc/tekschool.env
ExecStart=/usr/bin/node .output/server/index.mjs
Restart=always

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl enable --now tekschool
```

Then reverse-proxy port 80/443 to `127.0.0.1:3000` with nginx + certbot.

## Database

The app uses Supabase (hosted Postgres) — it keeps working from AWS with no
changes. If you must move the database into AWS too, migrate the Postgres
schema to RDS and replace the Supabase client calls; that is a separate,
larger piece of work.

## Not recommended

- **S3 + CloudFront only**: static hosting cannot run SSR, the forms, the
  admin area, or the AI endpoints.
- **Lambda@Edge**: streaming AI responses and SSR are awkward there; Fargate or
  App Runner is a better fit for this app.
