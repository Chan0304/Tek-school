// AWS / Node.js build config.
//
// Usage (on your machine, CI, or in Docker — NOT inside Lovable):
//   npm run build:node
//   node .output/server/index.mjs
//
// This produces a plain Node.js server bundle (Nitro "node-server" preset)
// instead of the Cloudflare Worker bundle used by Lovable hosting.
// vite.config.ts is left untouched so Lovable publishing keeps working.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

export default defineConfig({
  tanstackStart: {
    server: { entry: "server" },
  },
  nitro: {
    preset: "node-server",
  },
});
