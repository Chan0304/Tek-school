## Scope

Three big features on top of the existing TekSchool site. I'll build them in this order and ship as one batch.

### 1. Dashboard CTAs → real modals + login welcome alert

- Add a `DashboardModal` primitive (centered card, navy accents, scale-in, ESC/overlay close, focus trap, reduced-motion respect) reused by every CTA.
- Wire every currently-inert button across the dashboard subroutes:
  - Overview: "Join class", "Download recording", "Upgrade cohort", reward chips, missed-session download, next-class card, placement-update row.
  - Classes: "Join", "Watch recording", "Add to calendar".
  - Assignments: "Submit", "View feedback", "Resubmit".
  - Placements: "Apply", "View job", pipeline card click.
  - Community: "Message mentor", "Say hi", "Open thread".
  - Resources: "Open PDF", "Download", "Launch tool".
  - Settings: "Save changes", "Change password", "Manage notifications".
- Each opens a modal that reflects the action (e.g. Join = pre-join checklist with a green "Open live room" button that closes with a toast; Submit = repo URL / file upload mock; Apply = confirmation with resume attach; etc.). No dead buttons.
- On first dashboard load per session (once per session, guarded by `sessionStorage`), show a **Welcome Briefing modal** listing the student's next live class, next assignment due, and any active placement stage — pulled from `dashboard-data.ts`. Warm copy, mentor name called out, single primary CTA "Take me there" that deep-links to the relevant subroute.

### 2. Seasonal Offer Popup system (marketing pages only)

- New `src/lib/campaigns.ts` — date-range map: `monsoon` (Jun–Sep), `diwali` (Oct–Nov), `yearEnd` (Dec), `default` (neutral demo). Each campaign carries `{ id, badge, headline, sub, code, endsAt?, cta, whatsappHref, theme }`.
- New `src/components/SeasonalPopup.tsx`:
  - Trigger: 5s delay OR 45% scroll, whichever first. Once per session via `sessionStorage("tek-campaign-dismissed-<id>")`. Skip on `/dashboard/*`, `/welcome`, and while any other modal (`document.querySelector("[data-modal-open]")`) is open — queue via `MutationObserver` for after it closes.
  - Shell: centered card desktop, bottom-sheet + swipe-down on mobile (`<640px`), dark overlay, scale-in + fade, seasonal ambient layer (SVG rain streaks / gold sparkles / snowflakes) throttled and `prefers-reduced-motion` aware.
  - Content: badge icon, headline, one supporting line, live countdown (if `endsAt`), primary CTA → prefilled `/contact?offer=<code>` + WhatsApp deep link, soft "Maybe later" dismiss.
- Mount in `Shell.tsx` but the component itself gates by pathname (renders null on dashboard/welcome/sign-in).

### 3. Admin Dashboard (full product)

- Route tree under `src/routes/admin.*` (mirrors student dashboard pattern):
  - `admin.tsx` (layout: dense navy sidebar + top bar, role switcher chip, audit trail button)
  - `admin.index.tsx` — KPI row, Needs-attention feed, enrollment/track/funnel charts (SVG, no chart lib — small bars/lines/funnel drawn manually to keep bundle lean)
  - `admin.students.tsx` — searchable/filterable/sortable table, CSV export, row → drawer with activity log + notes + "Flag at-risk" + "Message"
  - `admin.cohorts.tsx` — cohort list + class scheduler modal + calendar grid
  - `admin.assignments.tsx` — grading queue with bulk actions + feedback templates + exam settings tab
  - `admin.placements.tsx` — reusable `<PipelineBoard>` kanban + job posts table + hiring-partner CRM cards
  - `admin.content.tsx` — syllabus editor (module list, drag-order-lite), brochure upload mock, single-source mentor bio table
  - `admin.enquiries.tsx` — reuses `<PipelineBoard>` with enquiry stages (New → Contacted → Demo → Enrolled → Lost)
  - `admin.instructors.tsx` — roster with rating, cohorts, upcoming sessions
  - `admin.finance.tsx` — revenue by track/cohort, EMI tracker, dues, refund queue
  - `admin.marketing.tsx` — campaign manager wired to `campaigns.ts` (toggle active, edit copy/code/range, CTR/conversion mock stats)
  - `admin.settings.tsx` — role matrix (super admin / admissions / instructor / finance), audit log table
- New data module `src/lib/admin-data.ts` — realistic seed: 40 students with Indian names + cohorts (Jan '26 AI-01, Mar '26 AI-02, Feb '26 Cloud-01, etc.), 6 cohorts, 30 enquiries, 20 job posts, 12 hiring partners, 10 instructors with ratings, finance rows, campaign stats.
- Shared components: `AdminTable` (search + column filter + sort + CSV export via Blob), `PipelineBoard` (columns from prop, drag-to-move updates local state), `StatTile` (compact trend), `Drawer` (right-side detail panel).
- Access: no real auth — a top-bar role dropdown that hides sidebar items based on selected role, purely front-end. Reachable at `/admin`; add a discreet "Admin" link in the site footer (not in main nav).
- Design: same navy/blue/coral/lavender tokens but denser — smaller radii on tables (12–14px), tighter row heights, minimal motion, no doodles inside admin pages, no marquee/hero flourishes.

## Technical notes

- All modals share one primitive (`src/components/Modal.tsx`) that sets `data-modal-open` on the root while open so the seasonal popup's queue observer works.
- CSV export: build `Blob([...])` client-side, no server function needed.
- Charts: small hand-rolled SVG components in `src/components/admin/Charts.tsx` (LineTrend, BarCompare, Funnel). No new deps.
- Countdown timer: `useEffect` + `setInterval(1s)`, cleared on unmount.
- Seasonal ambient SVGs live inline in `SeasonalPopup.tsx` so no new assets.
- No changes to existing marketing pages beyond mounting the popup once in `Shell.tsx`.

## Out of scope (say so up front)

- No backend / persistence — everything is in-memory + `sessionStorage` / `localStorage`. Admin edits reset on reload. If you want persistence, that's a follow-up (Lovable Cloud + tables).
- No real role auth — role switcher is UI-only.
- No real CSV parsing on import; export only.

Reply "go" and I'll build all three in one batch.
